# Everthread — Architecture & Techniques

## Core ownership model

Everthread has one authoritative `GameState`. Preferred direction remains UI → `GameEngine` / system API → controlled state mutation → autosave / Age Up processing → UI render. React screens display state and request actions; they do not directly mutate critical simulation state.

The test-only AI interaction layer follows the same ownership direction: semantic command → `GameEngine` → controlled system mutation → semantic observation. It must never become a second gameplay engine.

## Persistent consequence ownership

Phase 7A extends the existing delayed-event authority rather than creating a parallel narrative queue. `state.delayedEvents` remains the one active consequence queue. `ConsequenceSystem` owns scheduling, deterministic priority/order, due windows, exact target validity/cancellation, dedupe, exact event cooldown ages, bounded completion/cancellation history, and schema-13 normalization. Feature systems request consequences; they do not arbitrate `pendingEvent`. `pendingEvent` remains the one unresolved player-facing gate. Read-only eligibility/projections must not normalize or mutate scheduler state.

Phase 7B1 follows that boundary with a stateless `SystemicStorySystem` request bridge. It translates already-authoritative relationship/school actions into scheduler requests but stores no story ledger and never decides pending-event priority. Probability-zero systemic definitions live outside the ordinary random pool; exact NPC or SocialWorld refs remain the scheduler's targets, and the owning domain remains the only place durable relationship/school truth is mutated.

## Determinism, saves, and yearly processors

Core simulation uses seeded RNG, state-scoped `makeStateId`, and no `Math.random()` for simulation state. Yearly processors that can award money, advance contracts, resolve projects/seasons, or create incidents must be idempotent per age. Current **certified** save schema is **17** on gameplay/source Run #183 / expanded source `ecd7e58c32a3145e8354f7397b70fc14d1feaf64`. Historical schema-14 Phase 7C owns bounded durable world-condition lifecycle state; Phase 7 remains closed. Phase 7A introduced durable consequence-scheduler cooldown/history authority through shared `CURRENT_SAVE_VERSION` and is certified/deployed. Phase 6A advanced to schema 11 for durable revolving-credit account/history authority; Phase 6B3 advanced to schema 12 for durable auto-pay, card past-due, and secured paid-ahead payment state. Schema increments are justified by new durable authority, not by presentation-only projections or bounded primitive flags.

Real player saves are diagnostic evidence only. Generalize the failure shape into fabricated deterministic regression fixtures; never ship a tester's seed, IDs, NPCs, or history.

## Period accrual before end-state transitions

When an Age Up represents completed work, settle what was earned before changing end-of-period status. Sports and racing stamp final-period earnings before renewal/release/retirement. The stress consequence processor runs after annual finance settlement so a dismissal caused by that year's strain does not retroactively erase already-earned wages.

Residual economics are different from active employment. A completed music catalog may continue its bounded stream/royalty tail after the player steps away or retires. That passive income must not reactivate a Career World, advance active career years, or apply active manager/stress consequences. Existing signed distribution share/reach terms continue to govern those royalties.

## Character Visual and NPC portrait ownership

Character Visual is an identity/presentation layer over existing person and relationship authorities, not a second character database. `Character.appearance` owns the playable character portrait. For NPCs, optional `Npc.appearance` owns the exact stable modular identity only once that NPC is relevant enough to persist visually; background-only/unrevealed NPCs may remain visually lazy. Current-protagonist knowledge that an otherwise-transient acquaintance face has been learned belongs on the existing Relationship as optional `portraitRevealed`. Close-family and established-romantic relationship types already imply familiarity and do not need redundant reveal flags.

`NpcVisualSystem` is deterministic and uses isolated seed material derived from the game seed + exact NPC id. Read-only portrait projection, current-schema normalization, migration repair, and browsing must consume no gameplay RNG and allocate no runtime IDs. Runtime invariants should not rebuild/stringify every stable portrait after every action; normalize only missing newly revealed identities, while save-load repair may do one complete idempotent pass. People/Threadspace renders the same identity through `CharacterPortrait`; it must not copy facial traits into UI state. Descendant continuation preserves the successor NPC's existing portrait exactly, and converting the prior protagonist into a historical NPC preserves the protagonist portrait.

Run #176 extends this authority with optional `Npc.appearanceParentIds`, which records only biological **visual provenance** at the child-creation seam. It is not a second family tree: `parentIds` / `childIds` and Family Topology remain the sole legal/family relationship authority. Adopted children must not receive biological visual provenance, and old saves must not infer it from ambiguous historical parent links. Inheritance may project nine structural/color fields (face, eyes, brows, nose, mouth, ears, skin palette, hair-color palette, iris palette); personal style/presentation fields remain individual. Sibling resemblance is deterministic but child-specific, one-known-parent cases mix with the child's deterministic base, and multi-generation resemblance flows through each parent's actual stored/projected visual identity rather than direct grandparent lookup. Background descendants may retain provenance without materializing `Npc.appearance`; once appearance materializes it is permanent and parent later-life styling must not rewrite the child. Do not add a genetics ledger, hidden allele simulation, family-style database, or gameplay RNG consumption to extend this model.

Run #183 adds richer age presentation without changing identity ownership. `characterAgePresentation(visual, age)` is a pure read-only projection: person age remains authoritative and the stable stored `CharacterVisualIdentity` is never rewritten merely because a birthday crosses a visual stage. The projection may choose age-appropriate visible clothing/facial-hair detail, layer mature/elder facial details, and derive deterministic natural-hair graying from stable structural identity. Natural-hair aging must not consume gameplay RNG, allocate runtime IDs, require migration, or overwrite stylized/dyed/silver/white authored palettes. `CharacterPortrait`, palette tokens, and Player Profile copy should consume the same projection so visual and descriptive surfaces cannot disagree. Any future stage-specific authored art—including additional Yuki PNG families—must map from authoritative age into presentation rather than persisting a second `visualAge` or alternate identity.

## Authored secret-NPC surfaces and Hidden Threadroom routing

A special presentation surface must never become a second simulation for the person it displays. Run #178 establishes this contract for the secret-origin Yuki NPC.

- The secret NPC remains one ordinary `Npc` plus one ordinary `Relationship` inside authoritative `GameState`. Age, memories, romance, marriage, family, work links, housing, health, death, inheritance, and consequences continue through their existing owners.
- Durable special identity is provenance, not a name check. Yuki is recognized by the permanent `secret_yuki_9426` origin memory created by the owning secret-code action. An unrelated NPC named Yuki or copied visual fields must not gain special routing.
- `SecretCodeSystem` owns the authored Yuki appearance and the narrow deterministic repair for pre-curation saves. That repair is the intentional exception to ordinary "materialized portraits never change" because the historical randomized face predated the authored secret identity. Repair must be idempotent, gameplay-RNG neutral, runtime-ID neutral, and must preserve the exact NPC/Relationship/history rather than respawning a replacement.
- `YukiThreadroomSystem` owns only read-only routing/copy projections such as `peopleSurfaceForNpc`, greeting/status, and conversation-topic lines. It stores no affection score, conversation ledger, alternate relationship graph, or room-specific simulation state.
- `YukiThreadroom` is UI over existing authorities. Read-only conversation topics do not mutate `GameState`; actual interactions call `GameEngine` and remain subject to the central action economy. Dates, gifts, milestones, family planning, residential experiences, and other mature actions stay owned by their existing systems and remain reachable rather than being reimplemented inside the room.
- Age and relationship safety gates remain authoritative. A special surface may adapt copy for childhood or relationship state but must never bypass dating, reproduction, commitment, or action-economy rules.
- Run #180 adds a reactive painted presentation layer only. Day/evening room art, seated PNGs, face patches, icon state, blink/speech/reaction timers, and reduced-motion behavior belong to UI presentation and must not be serialized into `GameState`, consume gameplay RNG, or become a parallel emotion/affection authority.
- The currently authored painted Yuki asset family represents the adult stage and is restricted to ages **18–44**. Other ages remain in the same special surface but render through the canonical age-aware modular portrait. Future authored age-stage asset families should extend this presentation mapping rather than adding age state.
- Run #181 portals the full-screen Threadroom root to `document.body` so it can escape Threadspace's stacking context. Full-screen special surfaces must not assume a child component's high `z-index` can outrank parent stacking contexts; ordinary app chrome stays below the room, while truly global critical overlays may remain above it.
- Non-painted fallback portraits use their own compact square geometry rather than inheriting the seated-adult stage. Mobile layout must reserve dialogue/action-sheet clearance at 320/360/390/412/430px widths.
- Future bespoke NPC surfaces should follow this same pattern only when explicitly justified: provenance-based routing, one underlying person, read-only presentation where possible, controlled engine actions for mutation, and dedicated regressions proving decoy/name collisions cannot trigger the special surface.

## Social worlds and affiliation history

`SocialWorld` owns school/work/career affiliation history. NPC objects own people; `Relationship` owns the current personal bond. Archive worlds/memberships rather than deleting them. Current affiliations sort above muted former affiliations in People, but former NPCs/history remain reachable.

## Commitment capacity and explicit exit state

`CommitmentSystem.ts` owns active special-career capacity, enrollment compatibility, work/school restrictions, and player-facing same-age re-entry gating. Outside school the limit is two established special paths; during active enrollment it is one.

Historical professional evidence and current commitment are different facts. A career may have credits/releases/bookings/seasons forever without remaining an active commitment forever. `SpecialCareerExitSystem.ts` therefore uses an explicit flat `leftPath` marker. Completed history is preserved, `leftPath=true` overrides historical evidence for active-capacity calculations, and successful professional re-entry clears the marker. Do not clear historical counters to make a slot available.

## Unified deep-career lifecycle

`SpecialCareerLifecycleSystem.ts` is a normalized view/transition layer over existing path-specific state; it is not another source of truth. Acting, music, sports, modeling, racing, and directing can project developing, between work, project/season active, offer pending, contracted, free agent, stepped away, or retired states.

- `leftPath` is reversible voluntary step-away.
- Formal retirement is distinct from Leave Path.
- Acting, music, modeling, and directing may attempt a later-age comeback.
- Professional sports and motorsport retirement are final for that life.
- Same-age return after leaving/retiring is blocked to prevent lifecycle toggling from becoming a reroll/path-swap exploit.
- `careerPauseYears` accumulates inactive gaps on re-entry so career-year accounting can exclude retired/stepped-away years.
- Path-specific lifecycle owners remain authoritative when they already have richer retirement logic; player-facing motorsport retirement routes through `RacingCareerCycleSystem`.

## Voluntary exit vs involuntary end state

Leaving by player choice is not the same operation as retirement, release, dismissal, or institutional removal. Voluntary Leave Path/retirement can be blocked by a live binding commitment. Involuntary end states remain allowed to supersede those restrictions when the owning lifecycle requires it. A contract must not become immunity from consequences.

## Special-career story-chain ownership

`SpecialCareerStorySystem.ts` is a scheduler over existing state, not a new narrative-state authority.

- A new chain must originate from a real current or just-completed Career World and an exact persistent NPC selected from existing leader/rival influence state.
- The system stores only bounded scan/cooldown counters plus ordinary `DelayedEvent` entries. It does not add a second story graph to `GameState`.
- The opening beat is queued only after the age's career worlds/projects/contracts have processed, so story eligibility reflects the career state that actually survived the year.
- Story scanning uses a dedicated deterministic substream and does not advance the global `rngCounter`.
- `specialCareerStoryScanAge` makes the annual scan idempotent even when no story starts.
- At most one new career story starts per age, with a hard cap on queued special-career story beats before another opening can be added.
- Follow-up choices use the existing delayed-event scheduler with `npcSelector:'payload'`, which preserves the exact NPC across years. Required relationship-type metadata is used primarily as a living/connected-target validity contract.
- Social World history remains the affiliation record. A career NPC may later become a friend, enemy, romantic partner, spouse, ex, or other relationship type without losing the historical career connection.
- Follow-ups may occur after the original Career World is archived, but they must never reactivate that world merely to tell a story.
- Dead/invalid exact targets cancel the due follow-up instead of substituting another NPC.
- Story choices should preferentially feed systems already present—relationship/hidden opinion, NPC memory, stress, confidence, fame/reputation, finances, lifecycle gates, offers, or delayed consequences—rather than inventing isolated story-only stats.
- Story systems do not independently fire/release the player. Formal career end states remain with lifecycle/stress/path-specific owners.

## AI interaction testbench isolation

`src/tests/aiInteractionTestbench.ts` is a regression-only semantic interface, not a player feature.

- It is reachable only from test modules and the regression runner. `App.tsx`, `main.tsx`, player screens, and production systems do not import it.
- A supplied fixture is cloned before use. The caller-owned object is never the engine's mutable state.
- The clone is reassigned to an `ai-test-*` slot id so even a forced GameEngine save cannot use a player slot key.
- During the harness lifetime, `indexedDB` is disabled and `localStorage` is replaced with a private in-memory `Storage` implementation. The engine therefore exercises its ordinary save path while all writes remain disposable test-process memory.
- The harness flushes the engine save queue before restoring global persistence objects. Never restore persistence while a queued test save can still run.
- Testbench-only metadata—selected semantic screen, observations, diffs, transcripts, and invariant reports—must stay outside `GameState` and therefore outside save schema/migrations.
- Semantic actions use stable IDs and entity IDs, never screen coordinates or CSS selectors.
- Commands call public `GameEngine` methods. Do not reproduce the underlying outcome logic inside the harness.
- Availability reuses existing read-only gates/projections whenever practical. Relationship actions use the RelationshipSystem availability helpers; deep-career actions use commitment/exit/lifecycle gates.
- Pending required events impose an interface-level action lock so the semantic surface matches the real modal player flow.
- Private test setup commands may force deterministic fixtures/events, but they are not advertised as player actions and must not become production UI.
- Every executed command should immediately run state validation/invariant watches and emit a compact before/after diff so the exact corrupting interaction can be identified.
- Deterministic scenario transcripts should omit wall-clock persistence metadata such as `lastSavedAt` from their semantic comparison surface.

The testbench should grow alongside future player features. When a new player interaction matters to regression coverage, add a semantic command that routes to the same engine API rather than inventing a special testing mutation shortcut.

## Decision-based contract renewal

Offers create decisions, not silent buffs. Professional sports follows the established racing/modeling philosophy at term end: complete the final period and stamp salary first; end the old contract; persist exact renewal terms when offered; keep the exact team world coherent while a decision is pending; acceptance restores the contract; decline/expiry archives the former team and enters free agency.

A missing/corrupt team world must not consume the player's renewal action or silently destroy a pending offer.

## Stress is a risk pressure, not a deterministic punishment

`StressConsequenceSystem.ts` owns the cross-system high-strain framework. Below 90 stress there is no new high-strain incident modifier; from 90–100 incident probability rises but remains capped below certainty. At most one new stress incident is generated per age. Temporary fictionalized strain states can increase risk and decay with recovery. Three incidents make formal review possible; they do not guarantee dismissal.

Recovery remains systemic player agency through bounded wellness/therapy and qualifying successful relationship time.

## Procedural event target-role contracts

Event category alone is not enough to prove a story makes sense. Eligibility and target selection must operate over the same plausible NPC candidate set. Reusable `target:*` tags can constrain age, adult/minor role, relationship subtype, or care-needs context. If a relationship story cannot resolve a plausible target, it is ineligible rather than rendered with a generic or unrelated person.

Delayed chains with an exact payload target must preserve that exact target across future beats. A future story should cancel when its required target is no longer valid rather than silently rerolling to another NPC.

## Central action economy

Every meaningful repeatable outcome-generating action remains classified through `src/core/actionEconomy.ts`. UI disabled states should mirror system gates, while system/engine enforcement remains authoritative. Controlled lifecycle transitions such as Leave Path/Retire are system actions even when they do not consume a random-outcome opportunity. Required Age Up story events are consequences, not repeatable tap actions, so they do not need a separate action-economy policy.

## Contextual-information UI rule

Developer/system explanation copy belongs in the relevant fixed header `ⓘ` press-and-hold preview instead of being repeated inside gameplay cards unless the player needs the text to make an immediate decision.

- The header info button remains fixed while the floating preview follows the active press/pointer.
- The preview closes immediately on release/cancel/lost pointer capture.
- It is read-only and never consumes actions, advances RNG, autosaves an outcome, or mutates state.
- It measures rendered content and automatically reduces text scale to keep the complete explanation visible within available viewport space instead of becoming a scrolling mini-document.
- Immediate gameplay gating reasons may remain beside/under the relevant disabled action because the player needs them to make a decision.

4D8 story events themselves are gameplay content and therefore appear through the normal event-decision surface; they do not require explanatory paragraphs in Career cards.

## Additional special-career world technique

The six-deep `SpecialCareerWorldKind` is a lifecycle/story configuration type, not a requirement that every persistent special-career organization must join that union. For paths such as combat sports, prefer the existing generic `SocialWorld` + `Npc` + Relationship ownership model with a stable `special-<path>-*` ID namespace when doing so avoids widening unrelated deep-career maps.

- NPC identity/life history remains in ordinary `Npc` records.
- Organization membership/roles/groups/history remains in `SocialWorld`.
- Personal relationship type/score remains in RelationshipSystem state.
- The special-career track stores bounded metrics and exact recent IDs only; do not create a second roster or professional-relationship graph.
- Leave/retirement transitions archive current affiliation rather than deleting people/history.
- Read-only Career Identity projection may override an unrelated autonomous standard occupation while an NPC has an active special-career affiliation, but it must not mutate `NpcLifeSystem` career truth.
- Passive roster maintenance uses a dedicated deterministic substream where possible; outcome-generating player actions continue to consume the authoritative core RNG stream.
- People → Career Worlds should discover generic `special-*` organization affiliation rather than requiring path-specific People UI.
- Promote a path into a broader shared type only when several systems genuinely need the same lifecycle contract; do not broaden a type solely for presentation convenience.

## Player-visible systemic truth and agency

Material protagonist-facing simulation must not live only in hidden state. Everthread may simulate large amounts of background world activity, but when a process substantially changes the player character's life, relationships, wealth, legal status, health, career, family, assets, inheritance, or future options, the player needs an appropriate gameplay surface that explains what happened.

- Visibility and mechanical truth must share the same authority. UI previews/projectors read the owning system; they do not reimplement outcome math in components.
- When the fiction supports meaningful player choice, show enough consequence/context before commitment for that choice to be intentional. Do not silently auto-resolve decisions that are supposed to belong to the protagonist.
- After a major transition, preserve the important consequence in durable player-visible history (timeline/profile/asset/relationship state) so closing a modal does not erase understanding of what just happened.
- Background NPC/world simulation may stay summarized for scale. The moment background activity materially touches the protagonist, surface the relevant result without dumping internal simulation noise.
- Scale presentation with summaries, bounded windows, folders, progressive disclosure, and drill-down rather than deleting authoritative history or mounting every record at once.
- Player-facing copy explains gameplay cause/effect, not implementation internals. Developer diagnostics stay in QA/handoff tooling.
- Regressions for major systems should include parity checks where practical: what the player previewed/saw must match what the authoritative action ultimately applied.

This rule is cross-phase. Credit/debt, crime/legal outcomes, health, careers, fame, relationships, family, estates, businesses, politics, and future systems all inherit it.

### Credit/debt ownership rules

- Cash is owned liquid money. Available credit is unused borrowing capacity. Never merge them into one spendable-wealth or net-worth figure.
- `CreditSystem` is the reusable revolving-credit/creditworthiness authority. Vehicle, mortgage, personal-loan, rental, or future business underwriting should consume its profile/history rather than implement independent credit scores.
- Offer browsing/prequalification is read-only. Formal applications may create bounded inquiries and must expose understandable approval/decline reasoning.
- Signed contract terms shown to the player must come from the same product/quote data that the authoritative liability uses.
- Refundable secured-card deposits remain represented assets while held; revolving balances are liabilities and must participate in net worth, bankruptcy/default handling, and estate settlement.
- Store bounded recent transactions plus compact long-term summaries. Do not preserve decades of redundant monthly rows merely to derive payment history.

## Testing technique

High-value regressions include deterministic state comparisons, same-age idempotence, final-period accrual before status change, exact offer terms, archive-without-delete behavior, explicit exit/re-entry, passive residual income without lifecycle resurrection, pause-aware career-year accounting, plausible event target pools, exact delayed-event target continuity, dead-target cancellation, bounded story queues, old-save compatibility, semantic interaction transcripts, read-only observation, exact-entity inspection, persistence isolation, and per-command invariant watches.

Specialized suites cover core, special-career worlds, music, social affiliation, modeling, racing, coherence, stress/career freedom, event-target role coherence, commitment exclusivity, career/relationship coherence, leader/rival influence, contextual information, unified lifecycle behavior, targeted special-career story chains, combat-career world behavior, and the AI interaction testbench. GitHub Actions remains the final dependency-backed semantic typecheck/build/deploy gate.

The existing workflow already runs `npm test` before production build. Keeping the AI suite inside `runRegression.ts` means a semantic interaction failure stops deployment without changing the mobile upload workflow.

## Phase 7C world-condition architecture

`WorldConditionSystem` is a context authority, not an outcome authority. It owns bounded multi-year condition identity/scope/country/duration/intensity/history/cooldowns and projects modifiers; existing Economy/Career/Investment/Travel/Fame/Finance/Business/Property systems continue to own actual values and outcomes. Country conditions keep exact country identity across emigration; global conditions are location-independent.

Annual condition generation uses an isolated deterministic seed/year/country stream and does not advance `state.rngCounter`. Phase 7C must not create another delayed-event or popup queue; inspectability comes from Life-screen read-only projection plus bounded timeline start/expiry entries. Active condition count and resolved history stay hard-bounded for dynasty-scale saves.


## Mobile-first technique

Primary widths remain 360 / 390 / 412 / 430px. Favor bottom navigation/sheets, 44px+ meaningful touch controls, compact readable cards, safe-area padding, and explanatory disabled states for locked commitments. The growing main application chunk remains a future code-splitting target.

## Phase 7 persistent-consequence architecture

Run #106 was the certified starting point for Phase 7. Phase 7A is now certified and provides one bounded persistent consequence/cooldown authority rather than scattering flags or queue-priority checks across feature systems.

Scheduler responsibilities: stable consequence/chain IDs, origin event/age, exact typed target references, due-age windows, explicit priority, deterministic tie-breaking, cancellation/validity conditions, deduplication, completion/cancellation history, bounded retention, and compatibility normalization for legacy `DelayedEvent` entries. Feature systems schedule consequences; the scheduler alone decides which due consequence may occupy the single unresolved `pendingEvent` slot.

System-owned and dedicated story definitions remain outside the ordinary random-event pool unless intentionally authored as random content. Scheduling/cooldown bookkeeping must not consume the main simulation RNG. Invalid/dead/missing targets cancel through deterministic validation rather than silently retargeting to a different entity.

Phase 7A moved save schema 12 → 13 with deterministic, RNG-neutral, idempotent scheduler migration. Phase 7C legitimately advanced schema 13 → 14 for bounded durable world-condition lifecycle state. Its migration creates empty condition state for old saves without retroactive history and consumes no gameplay RNG or runtime IDs. New-game save-version initialization remains synchronized with the shared SaveSystem authority.

