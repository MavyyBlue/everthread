# Everthread Changelog

## Post-6B3 Credit History Reactivity correction candidate — 2026-09-12

### Fixed

- Credit & Banking History now derives current/prior transaction lists fresh on every game-state render instead of memoizing against the mutable credit-transaction array reference. Payments, charges, fees, deposits, and other posted credit transactions can therefore appear immediately while the banking sheet remains open.
- Added regression protection in Payment & Asset Management proving the read-only History projection immediately reflects a newly posted in-place credit transaction.

### Baseline

- Built only on certified Run #102 expanded source `8b2a49fe76c5429cf55228a00a15b6103211a25b`, package `0.12.0`, save schema 12. Phase 6B3 itself is CI Green.
- This is a presentation-reactivity correction only: it adds no debt authority, no save fields, no RNG use, and no content definitions. Phase 6C remains gated until this correction is CI Green.

### Local validation

- Engine TypeScript and test TypeScript pass. The complete regression wall passes with Payment & Asset Management **81/81** (up from 79/79 through two reactivity checks), Core 82/82, Credit & Banking 74/74, Asset Financing 77/77, Asset Delinquency 82/82, Integrated Long-Life 105/105, and every established suite green.
- Standalone production build passes at 153 transformed modules. The local all-in-one preflight wrapper was interrupted by the host execution ceiling during its repeated Vite transform after both TypeScript gates and the complete wall had already passed; GitHub Actions remains the final integrated preflight authority.

## Phase 6B3 — Payments & Asset Management UX — CI Green Run #102 — 2026-09-12

### Added

- Added a centralized `PaymentSystem` projection/action layer for real credit-card minimums and secured vehicle/home financing obligations. CreditSystem and FinanceSystem remain the balance authorities; the UI no longer needs to invent bill math.
- Added **Credit & Banking → Bills & Payments** from Overview. It itemizes current/past-due obligations, shows Cash, total due, past due, and annual auto-pay status, supports Cash payment of the real bill, and exposes per-obligation auto-pay switches.
- Added persistent annual auto-pay preferences. New cards and new asset-financing contracts default ON; schema-11 saves migrate safely to ON so old saves preserve their established automatic-servicing behavior. Card auto-pay covers the required minimum only, never the whole balance.
- Added manual secured annual-bill payment with a paid-ahead marker so paying before Age Up cannot double-charge the same contractual year. Existing delinquent secured bills continue through the 6B2 cure authority.
- Added vehicle sale quotes and real vehicle selling, including selling costs, lender payoff, equity proceeds, underwater deficiency conversion to unsecured debt, durable history, and confirmation before mutation.
- Added `AssetSaleSheet` and `paymentAssetManagementRegression.ts` with 79 targeted checks across migration, projection purity, auto-pay on/off, card minimums, secured prepayment, delinquency cure, financed contract defaults, vehicle/home sale accounting, save round trips, and invariants.

### Changed

- Credit & Banking Overview replaces the duplicated historical block with the compact Bills & Payments entry; major derogatory history now lives under the existing History tab. Individual card Accounts still support extra/full revolving-balance payments.
- Assets → Property now contains both homes and vehicles with a compact **Browse | Owned** toggle. Browse covers home + vehicle markets; Owned shows homes + vehicles together with contextual financing status and asset actions. Vehicles are no longer hidden under More.
- Payment controls are centralized in Credit & Banking instead of being scattered across asset cards. The Money liabilities view remains an accounting/status view and points players to Bills & Payments.
- Save schema advances from 11 to **12** for durable auto-pay, credit-card past-due, and secured paid-ahead payment state. Migration is deterministic, RNG-neutral, and defaults old obligations to the prior automatic-payment behavior.

### CI validation

- Built from exact certified Run #101 expanded source `c498753acb67bbb0aa930e5f8bdb7b411b1e874c` and its certified Node dependency artifact.
- GitHub Actions Run #102 (`34707368374`) imported the overlay into expanded source `8b2a49fe76c5429cf55228a00a15b6103211a25b` and reproduced both TypeScript gates, Core 82/82, Credit & Banking 74/74, Asset Financing 77/77, Asset Delinquency 82/82, Payment & Asset Management 79/79, Integrated Long-Life 105/105, every established suite, and the 153-module production build.
- Canonical preflight reported **GREEN 4/4**, certified artifact `10302905490` was uploaded, and GitHub Pages deployment succeeded. The existing >700 kB main-chunk warning remains nonblocking.

## Phase 6B2 — Secured Delinquency & Collateral Consequences — CI Green Run #101 — 2026-09-12

### Added

- Added persistent, save-safe secured-loan delinquency state on existing `Loan` records: status, arrears, missed-payment count, and the age of the unresolved miss. Pre-6B2 schema-11 loans derive as current without mutation, so no save-schema bump is required.
- Added explicit player curing for delinquent car loans and mortgages. Assets → Money shows the collateral, past-due amount, next-Age-Up consequence, and a touch-friendly **Cure** action that uses Cash only.
- Added vehicle repossession for uncured financed cars and strengthened mortgage foreclosure to use the same loan/collateral/credit authorities. Missed secured payments create durable timeline warnings and existing CreditSystem derogatories; repossession creates a credit default and foreclosure preserves the established foreclosure history.
- Added `assetDelinquencyRegression.ts` with 82 targeted checks covering current servicing, missed-payment accounting, cure success/failure, cure payoff, car repossession, foreclosure, deficiencies/surplus recovery, secured-payment priority, voluntary underwater sales, net-worth accounting, and schema-11 round trips.

### Changed

- Annual finance no longer reduces a secured-loan balance when the year cannot actually fund that payment. The skipped payment becomes arrears, the contractual term is not falsely consumed, and the player gets until the next Age Up to cure it.
- Same-year secured shortfall allocation protects housing by allowing a vehicle payment to fail before a mortgage when one skipped payment is enough to close the cash gap. Deeper insolvency can make both obligations delinquent.
- Unrecovered collateral balances become ordinary unsecured deficiency debt instead of disappearing. Involuntary foreclosure equity first reconciles existing unsecured shortfall debt before any remainder returns as cash.
- Voluntarily selling an underwater financed home now preserves the unpaid deficiency as unsecured debt, closing the prior debt-erasure exploit.
- Financed home/vehicle cards expose outstanding financed balance and at-risk state directly on the owned asset.

### Candidate validation

- Local canonical preflight from the certified Run #100 source/dependency artifact passes **4/4**: engine TypeScript, test TypeScript, complete regression wall, and production build.
- Core remains 82/82; Credit & Banking 74/74; Asset Financing 77/77; new Asset Delinquency 82/82; Dynasty Transition 63/63; Family Topology 40/40; NPC Asset Ownership 82/82; Timeline Scaling 11/11; Action VFX 46/46; Integrated Long-Life 105/105; every established dedicated suite is green locally.
- Production build succeeds at 151 transformed modules. The existing >700 kB main-chunk warning remains nonblocking.
- GitHub Actions Run #101 reproduced Asset Delinquency 82/82, every established regression, both TypeScript gates, the 151-module production build, certified-baseline artifact creation, and Pages deployment. Expanded certified source is `c498753acb67bbb0aa930e5f8bdb7b411b1e874c`; Phase 6B2 is CI Green.

## Phase 6B1 — Asset Financing Foundation — CI Green Run #100 — 2026-09-12

### Added

- Added a reusable, data-driven `AssetFinancingSystem` plus six fictional vehicle/home lender programs. Asset underwriting consumes `CreditSystem.getCreditUnderwritingSnapshot()` for the existing derived credit profile, real income, installment/revolving payment burden, inquiries, and bankruptcy recovery instead of inventing a second score model.
- Added deterministic, read-only lender quotes for appropriate vehicles and homes with visible APR, term, down payment, amount financed, annual payment, monthly equivalent, finance charge, full-term total cost, projected payment burden, and human-readable approval/decline reasons.
- Added a mobile **Buy Outright | Finance** purchase sheet for property and vehicles. Browsing does not create an inquiry; signing re-underwrites current state and then records the approved financing inquiry.
- Added persistent `car` and `mortgage` liabilities using the existing `Loan` authority, including collateral `assetId` links, annual-finance servicing, net-worth accounting, estate debt treatment, schema-11 save persistence, and durable timeline/history context.
- Added `assetFinancingRegression.ts` with 77 targeted checks covering deterministic browsing, lender requirements, down-payment effects, stale-quote revalidation, preview→signed parity, shared application limits, cash-vs-credit separation, vehicle/home outright and finance paths, accounting identity, annual servicing, estates, saves, and CreditSystem authority reuse.

### Changed

- Replaced the legacy hard-coded home-mortgage approval math inside `PropertySystem` with the shared financing authority. Vehicle financing now uses that same authority; asset screens contain no independent creditworthiness calculation.
- Asset liabilities now show APR, authoritative annual payment, and remaining years. Credit & Banking history resolves asset-financing inquiries to their lender/program names.
- Outright vehicle purchases now create a durable asset timeline entry so a material life purchase is not invisible. Credit Available remains revolving borrowing capacity only and is never treated as purchase cash or wealth.

### CI validation

- GitHub Actions Run #100 reproduced both TypeScript gates, Core 82/82, Asset Financing 77/77, Credit & Banking 74/74, every established dedicated regression, Integrated Long-Life 105/105, and the production build.
- The canonical preflight reported GREEN 4/4, the certified baseline artifact was uploaded, and GitHub Pages deployed successfully.
- Expanded certified source is `819d223aa9a0d5f9109c705f16213c43ddcaeb31`; Phase 6B1 is CI Green.

## Phase 6A — Credit & Banking Foundation — CI Green Run #99 — 2026-09-12

### Added

- Added bounded schema-11 player credit state plus `CreditSystem` for revolving accounts, available credit, refundable secured deposits, statement/minimum/payment history, interest/fees, formal inquiries, derogatories, deterministic creditworthiness, account closure, bankruptcy discharge, and bounded history repair.
- Added six original fictional banking institutions/products spanning age-16 secured starter cards through established/premium unsecured offers. Browsing is read-only; formal applications are bounded and record understandable approval/decline reasons.
- Added Life-page **Cash** + **Credit Available** presentation and a mobile **Credit & Banking** hub with Overview, Accounts, Offers/contracts, and History. Contract review exposes line, APR, annual fee, late fee, deposit, and minimum-payment terms before acceptance.
- Added manual card payments, representative card purchases, secured-deposit refunds, current-year/recent transaction history, and durable timeline consequences for material credit events.
- Added `creditBankingRegression.ts`, now 74/74.

### Changed

- Net worth/wealth breakdown now treats secured deposits as represented assets and revolving balances as liabilities; Credit Available never counts as cash or wealth.
- Estate obligations include revolving debt while refundable secured deposits remain estate value. Existing insolvency/bankruptcy now discharges active cards through the credit authority and persists default/bankruptcy credit history.
- Descendant continuation initializes the newly controlled protagonist's player credit state without inventing an unsupported NPC consumer-credit history.
- Save schema advances from 10 to 11 with deterministic, RNG-neutral, idempotent migration.

### Predeployment validation

- Credit & Banking 74/74; Core 82/82; Dynasty Transition 63/63; Family Topology 40/40; NPC Asset Ownership 82/82; Timeline Scaling 11/11; Action VFX 46/46; Integrated Long-Life 105/105; every established dedicated regression remains green.
- Both TypeScript gates pass. Production build passes at 148 transformed modules; existing >700 kB main-chunk warning remains nonblocking.
- 80-year direct card-use benchmark completed in ~5 ms in the hosted workspace, retained 20 recent transactions after bounded pruning, serialized the full fixture at ~18 KB, and returned zero invariant errors.
- GitHub Actions Run #99 reproduced the Phase 6A regression wall and certified expanded source `6eb2b7876203d47dcc1ad5c48f1098bf359182cd`; Phase 6A is CI Green.

## Phase 5E — Dynasty Transition / End-of-Life Agency — CI Green Run #98 — 2026-09-12

### Added

- Added read-only `DynastyTransitionSystem` projection over the existing EstateSystem and NPC biography/asset authorities. The death UI no longer performs or mirrors inheritance math independently.
- Rebuilt the death flow into an intentional mobile sequence: completed-life review → estate outcome → successor selection → detailed successor inspection → explicit continuation confirmation.
- Successor inspection now surfaces existing education/career, partner/children, health/happiness, fame/reputation, debt, own net worth, own property/businesses, projected inheritance, inherited named assets, and protected-minor trust timing.
- Estate review now names forced-sale assets and explains whether each sale was caused by estate obligations or by fair division among heirs.
- Added durable post-handoff timeline entries for estate obligations/forced sales, inherited named assets/trusts, and the value distributed to other family heirs.
- Added `dynastyTransitionRegression.ts`, currently 63/63.

### Changed

- A descendant card no longer immediately switches protagonists. Selecting a child is read-only; a separate confirmation button performs the real `continueAsChild()` action.
- Protagonist-switch confirmation explicitly disables ordinary delta-derived action VFX so cash/stress/relationship differences between two different people are not misrepresented as an action consequence.
- Heir, successor, and forced-sale lists use 24-row progressive disclosure to keep extreme dynasty death screens bounded without deleting authoritative data.
- Added the cross-phase architecture rule that material protagonist-facing consequences must be visible/understandable through gameplay surfaces and, where meaningful agency exists, presented before commitment from the same authoritative system that applies the result.
- Save schema remains 10; no transition snapshot or second estate database was introduced.

### Predeployment validation

- Dynasty Transition: 63/63. Core 82/82; Estate Planning 46/46; Estate Administration 63/63; NPC Asset Ownership 82/82; Family Topology 40/40; Action VFX 46/46; Integrated Long-Life 105/105; every established dedicated regression remains green.
- Both TypeScript gates pass. Production build passes at 145 transformed modules; existing >700 kB main-chunk warning remains nonblocking.
- Twelve sequential reviewed handoffs with hundreds of background NPCs preserve 7,212 archived life-history entries, unique completed-life IDs, state invariants, and bounded linear historical-cast growth.
- GitHub Actions Run #98 reproduced canonical preflight 4/4, Dynasty Transition 63/63, every established regression, the 145-module production build, certified artifact creation, and Pages deployment on expanded source `5aa1c4338be4edc934b867f4e5a710d0e116aaa2`; Phase 5 is closed.

## Phase 5D — Broader Family Topology — CI Green Run #97 — 2026-09-11

### Added

- Added indexed `FamilyTopologySystem` derivation for aunt/uncle and cousin relationships plus reconciliation of the existing close-family taxonomy from authoritative parent/child/partner graph truth.
- Integrated expanded kinship into People/Threadspace labels and folders, generic family event targeting, delayed family-favor continuity, relevant special-career family targeting, save-load backfill, and descendant continuation.
- Added `familyTopologyRegression.ts`, now 40/40, including deterministic/idempotent derivation, no synthetic NPC creation, RNG/ID neutrality, extended-family simulation-tier bounds, event eligibility, generation handoff, migration/backfill, romantic-history preservation, UI labels, and a hundreds-relative scale fixture.

### Changed

- Extended kin stay background-tier unless individually meaningful; aunt/uncle/cousin births do not automatically become full-simulation branches or guaranteed player timeline entries.
- Save load now repairs state invariants before final family-topology synchronization so derived stepfamily/kinship uses repaired authoritative pointers.
- Threadspace person cards use the shared human-readable relationship label formatter (`aunt / uncle`, `niece / nephew`).
- Save schema remains 10; no new persisted family database was introduced.

### Predeployment validation

- Family Topology: 40/40. Core 82/82; Action VFX 46/46; Timeline Scaling 11/11; NPC Asset Ownership 82/82; Integrated Long-Life 105/105; every established dedicated regression remains green.
- Both TypeScript gates pass and production build passes at 144 transformed modules. Existing >700 kB main-chunk warning remains nonblocking.
- Explicit large-dynasty benchmark: 1,082 starting NPCs arranged as 180 aunts/uncles + 900 cousins synchronized in ~4.5 ms locally; six simulated years completed in ~362 ms, normal autonomy grew the cast to 1,182, no extended relative was forced full-tier, and validation produced zero errors.
- GitHub Actions Run #97 reproduced canonical preflight 4/4, Family Topology 40/40, every established regression, the 144-module production build, certified artifact creation, and Pages deployment on expanded source `8e5394d0488d1c760072590ffa5c06eadfdac9f6`.

## Post-Run95 playtest hotfix — CI Green Run #96 — 2026-09-11

- Fixed Life → Your Story failing to show Age Up timeline entries until navigation/refresh. Root cause was `Timeline` memoizing a bounded window by an array reference that Everthread intentionally mutates in place; the bounded window now recomputes on each render.
- Fixed Threadspace NPC interaction VFX disappearing at relationship score caps. Action VFX snapshots now record timeline length and derive semantic relationship gain/loss from only the new `relationshipDelta` entries created by the current action when before/after stored scores cannot move past 0/100.
- Added real capped positive/adverse `interactWithNpc()` regression coverage and same-reference timeline append coverage. Action VFX is now 46/46; Timeline Scaling is 11/11 locally.
- GitHub Actions Run #96 reproduced canonical preflight 4/4, Action VFX 46/46, Timeline Scaling 11/11, every established regression, the 142-module production build, certified artifact creation, and Pages deployment on expanded source `3b58f04827ddc88a33c61b3cdf0d50f1e7584161`.

## Phase 5C — Persistent NPC Asset Ownership — CI Green Run #95 — 2026-09-10

### Added

- Save schema v10 with lean persisted NPC property/business portfolios. Existing v9 aggregate NPC property migrates deterministically into stable explicit ownership without consuming the player RNG stream.
- Bounded NPC asset rules and a dedicated asset progression substream. Meaningful NPCs can own and modestly grow property/business interests; background-tier NPCs retain cheaper simulation, do not seed new explicit property at creation, and do not organically accumulate new portfolios.
- Explicit NPC estate settlement for retained property/business inheritance, adult/minor NPC heirs, player heirs, protected trusts, mortgage carryover, and idempotent source-estate clearing.
- Descendant continuation now converts the selected NPC's own property/business holdings into playable assets and separates mortgage debt from unsecured personal debt.
- People detail sheets now show NPC liquid wealth, property, businesses, debt, estimated net worth, and named holdings.
- Dedicated `npcAssetOwnershipRegression.ts` with 82/82 checks, including protected-trust caps/overflow reconciliation and a 600-background-NPC + 3,000-entry 12-year scale fixture.
- `timelineWindow.ts` plus a 10/10 Timeline Scaling regression: the authoritative timeline remains complete while the Life page initially renders the newest 120 entries and reveals older history in 120-entry increments.

### Changed

- `NpcLifeState.finance.propertyValue` is now a projection of explicit NPC property holdings instead of a second independent property-value authority. `npc.wealth` remains liquid wealth.
- NPC annual finance incorporates explicit business profit/loss and mortgage progression while keeping asset growth bounded and deterministic.
- Player estate settlement gives offscreen heirs retained property/businesses as real holdings instead of converting the full allocation into aggregate wealth. Minor NPC heirs retain those assets in trust until adulthood.
- NPC-parent inheritance can pass retained assets directly to the player; minor player inheritance remains protected until age 18 and is counted once when released.
- Adult NPC portfolios and minor NPC inheritance trusts share hard 6-property / 4-business caps. Overflow liquidates to equity/value rather than disappearing or growing the save without bound.
- NPC asset definition lookups now use precomputed maps and legacy property migration chooses the nearest definition in a linear scan instead of sorting a copied catalog for each migration.

### Predeployment validation

- Engine TypeScript and test TypeScript gates pass.
- NPC Asset Ownership: 82/82.
- Timeline Scaling: 10/10.
- Core 82/82; Estate Planning 46/46; Estate Administration 63/63; Action VFX 42/42; Integrated Long-Life 105/105; every established dedicated regression remains green in bounded local batches.
- Content audit remains unchanged and clean.
- Earlier 50-life family-policy bulk sanity: zero anomalies, zero forced terminal deaths, max NPC peak 443.
- Scale fixture: 600 starting background NPCs + 3,000 timeline entries advanced 12 years with full history preserved, portfolio caps respected, zero organic explicit background holdings, and clean state validation.
- Ad-hoc hosted-sandbox benchmark: 1,000 starting background NPCs + 5,000 timeline entries advanced 20 years in ~1.1 s; world grew to ~1,200 NPCs through ordinary autonomy with zero organic explicit background holdings and zero validation errors.
- Production build passes with 142 transformed modules; main chunk ~981.03 kB minified / 278.92 kB gzip. Existing chunk-size warning remains nonblocking.
- GitHub Actions Run #95 reproduced canonical preflight, certified artifact creation, and Pages deployment on expanded source `62e28aafb190f8b46d10b73fb6dd00985beb724d`; Phase 5C is CI Green.

## Universal derived action VFX candidate — 2026-09-10

### Changed

- Derived consequence VFX are now enabled by default for every gameplay button result that reaches the shared `App.onResult` authority. A real cash decrease therefore emits Money Loss automatically without each screen opting in with `derive:true`; stress, follower, and relationship deltas receive the same systemic treatment.
- `derive:false` remains an explicit escape hatch for exceptional presentation-only cases, but there are currently no production call sites using it.
- Generic special-career Path buttons no longer turn derivation off when a path has no primary domain icon, closing the remaining Politics, Military, Royalty, and Film Directing coverage hole while preserving primary icons for Acting, Music, Sports, Combat, Modeling, Motorsport, and Organized Crime.

### Validation

- Action VFX regression expanded from 38/38 to 42/42, including plain successful spending, failed-but-executed spending, primary-only requests with automatic derived consequences, and explicit opt-out behavior.
- Engine TypeScript and test TypeScript gates pass.
- Core 82/82; every established dedicated regression remains green; Integrated Long-Life 105/105.
- Production build passes with 138 transformed modules. The hosted sandbox cannot finish the monolithic preflight wrapper before its command ceiling, so the same underlying preflight stages were executed in bounded chunks without removing or weakening any suite. GitHub CI remains the independent final authority.

## Visual feedback asset integration — CI Green Run #93 — 2026-09-10

### Added

- Mavyy-supplied Everthread action-feedback artwork is now integrated as a reusable mobile VFX system. Successful acting, music, professional sports, combat sports, modeling, motorsport, organized-crime, chemistry, follower, relationship, and stress-reduction outcomes can emit their matching icon from the actual press location.
- Adverse outcomes can emit supplied stress-increase, money-loss, and relationship-loss artwork from the same press-origin particle layer. Multiple real side effects may share one bounded burst.
- A supplied cash icon now sits beside Current Cash on the Life screen, and the supplied DECEASED stamp overlays dead NPC nodes in People Threadspace without blocking node interaction.
- Dedicated Action VFX regression coverage verifies career-to-icon mapping, supplied asset paths, static icon paths, state-delta derivation, failed-but-executed adverse feedback, success-only primary feedback, deduplication, and chemistry-specific suppression of a redundant relationship-gain icon.

### Changed

- `App` now owns one presentation-only action-feedback controller. Pointer presses capture their viewport origin before engine execution; keyboard activation falls back to the button center. The layer never mutates game state, save data, action economy, or simulation RNG.
- Reduced-motion users receive a short stationary fade/scale rather than the upward confetti motion. Particle counts and lifetime are bounded for mobile performance.
- Supplied artwork is stored as transparent, cropped, mobile-sized runtime derivatives; the heavier action VFX set is lazy/runtime cached while only the small Life cash icon joins the PWA shell precache. Service-worker cache generation advances to `everthread-shell-v8`.
- Build Chemistry uses the supplied person-plus artwork as its explicit primary feedback and suppresses a duplicate heart-plus burst; follower gains reuse the same person-plus artwork.

### Predeployment validation

- Engine TypeScript and test TypeScript gates pass.
- Action VFX regression: 38/38.
- Core: 82/82; every established dedicated regression remained green, including Estate Planning 46/46, Estate Administration 63/63, AI Interaction Testbench 41/41, and Integrated Long-Life 105/105.
- GitHub Actions Run #93 reproduced canonical preflight 4/4 on Node 22.23.2/Linux x64, built 138 modules, published the supplied runtime assets, created the certified preflight baseline, and deployed Pages successfully.
- CI-Green source commit: `de8f9af6a0212a0d90acecf9008afa77b042ac42`.

## Phase 5B — 2026-09-10 — Estate Administration & Settlement

### Added

- Fictional country-sensitive estate administration profiles derived from Everthread's simplified gameplay fiscal context, with protected administration allowances, capped administration costs, levy allowances, and modest settlement-levy rates. These values are explicitly game balance rules, not real-world tax/legal guidance.
- Estate preview breakdown for gross estate, debts, administration, settlement levy, eligible heirs, forced-sale pressure, and the active fictional rule profile.
- Dedicated Phase 5 estate-administration regression with country-rule coverage, read-only/RNG-neutral preview checks, debt-before-levy math, named-bequest protection, investment-before-protected-bequest liquidation, trusts, descendant continuation, and five-generation no-income anti-duplication stress.

### Changed

- Estate obligations now flow through one settlement authority: unsecured debt, administration, and levy are paid before heir allocation. Unassigned indivisible assets may be sold first; liquid investments are used before a specifically named bequest must be sacrificed.
- Smaller estates receive a protected administration allowance so modest specific bequests are not sold solely to fund trivial settlement overhead.
- Descendant-continuation history records settlement administration/levy costs when present. Save schema remains 9 because the new rules are computed rather than persisted.

### Predeployment validation

- Existing Estate Planning: 46/46.
- New Estate Administration: 63/63.
- Family Continuity: 18/18.
- Core: 82/82; AI Interaction Testbench: 41/41; Integrated Long-Life: 105/105; all established dedicated suites passed locally.
- Mixed 100-life bulk sanity: zero anomalies / zero forced terminal deaths, max NPC peak 480.
- Family-biased 100-life bulk sanity: zero anomalies / zero forced terminal deaths, max NPC peak 474.
- GitHub Actions Run #92 reproduced canonical preflight 4/4, all estate and legacy suites, production build, certified preflight artifact creation, and Pages deployment. Phase 5B is CI Green at `926da2fa3c74bac021776d9f1b4825a7a3e39797`.

## 0.12.0 — 2026-09-05 — Full NPC Life Simulation

### Added

- Save schema v9 with persistent `NpcLifeState` biographies covering education, career history, household/finance state, health conditions, legal incidents/custody, public life, housing/moves, and simulation cadence. Existing v8 NPCs initialize deterministically without consuming the player RNG stream.
- Dedicated `NpcLifeSystem` ownership for autonomous NPC education, careers, finance, health, legal status, fame, households, family formation, and death. `RelationshipSystem` retains player↔NPC interactions and relationship milestones instead of accumulating unrelated autonomy logic.
- Autonomous NPC education/credentials, career history, job loss/promotion/retirement, household cash flow, debt servicing, bounded home ownership/appreciation, health histories, legal incidents/imprisonment/release, fame/followers/reputation/scandals, and household relocation.
- Blended-family formation with incoming stepchildren, reciprocal stepfamily links, autonomous adoption for stable low-fertility couples, and bounded family-planning pressure for close-family households.
- Direct adult-descendant handoff of real NPC biography state. Education, career, health, legal, fame, debt/property context, spouse/children, and institutional history survive when an established descendant becomes playable.
- NPC life summaries in People detail sheets, exposing education, career, housing, income, property/debt, health, public/legal history, custody, and household moves.
- Eight-generation dynasty stress coverage plus NPC population metrics in the simulation harness.
- O(1) deterministic Mulberry32 counter jumps. Seeded RNG creation no longer replays every previously consumed random number; regression coverage proves direct jumps match sequential consumption through large counters.
- Deterministic household relocation substreams so considering a move cannot reshuffle unrelated marriage, fertility, health, career, or legal outcomes. Partners and dependent children relocate together.
- Bounded relationship progression for important close-family NPCs so unlucky RNG cannot leave romantic relatives permanently single, dating, or engaged without resolution.
- In-game Reduced Motion now explicitly routes timing minigames to the non-motion sequence mechanic, matching the existing OS reduced-motion behavior.

### Changed

- Background acquaintances retain cheaper autonomy cadence while meaningful family/friend/enemy/romantic relationships automatically receive full simulation, preserving long-life performance without deleting history.
- Memories and hidden opinions influence long-term relationship drift and make emotionally significant persistent NPCs more likely to surface in targeted events.
- NPC-owned housing follows bounded housing-market movement instead of accidental deterministic depreciation; scheduled debt service is included in annual household cash flow before wealth growth.
- Autonomous relocation is household-scoped rather than person-scoped. Current player spouses cannot autonomously move away, and a guardian cannot silently relocate a dependent player without a future player-facing family decision.
- Partner/family progression remains probabilistic in normal years but gains bounded pressure against decades of accidental RNG limbo.
- Simulation reporting now includes average/max lifetime NPC cast so future social systems can be held to a population-growth budget.

### Validation

- Engine TypeScript check passes.
- Test/harness TypeScript check passes.
- 82/82 regression cases pass.
- Eight-generation continuation stress test passes with valid lineage/history and bounded cast growth.
- Neutral 1,000-life bulk population: zero anomalies, zero forced terminal deaths, average/max lifetime NPC cast 116.2 / 176, average lifetime inheritance 125,559.
- Mixed-policy 1,000-life bulk population: zero anomalies, zero forced terminal deaths, average/max lifetime NPC cast 116.3 / 176, average lifetime inheritance 123,442.
- Identical 250-life benchmark improved from roughly 30.0 seconds to 8.3 seconds after deterministic RNG jump optimization with unchanged meaningful aggregate outcomes.
- Dependency-backed React/Vite production build remains the GitHub Actions deployment gate.

## 0.11.0 — 2026-09-04 — Persistent Workplaces

### Added

- Save schema v8 with persisted workplace-specific Social World state and real active/historical part-time employment records. Existing v7 careers reconstruct compatible workplace worlds during migration.
- Persistent full-time workplace rosters with managers, coworkers, departments, team groups, workplace morale/culture/tension/reputation, bounded turnover, and senior-character direct reports.
- Workplace actions for collaboration, networking, manager feedback, and formal coworker concerns, all classified through the central action-economy ledger.
- Real part-time jobs with age requirements, hourly pay, hours/week, performance, small persistent workplace rosters, annual income/tax integration, and shared weekly hour capacity around school/full-time commitments.
- Target-aware work events for credit disputes, manager reviews, rumors, team feuds, after-hours connection, formal workplace claims, and bonus pools.
- Regression coverage for employer archival, workplace migration, action limits, part-time capacity/income, evolving coworker relationships, targeted work events, and generation-safe social-world rebuilding.

### Changed

- Promotions within one employer preserve its workplace world; changing employers, resigning, being fired/laid off, or retiring archives the old workplace without deleting former coworkers.
- Work affiliation is independent from `Relationship.type`, so coworkers remain in People → Work after becoming friends, enemies, or romantic connections.
- Standard-career annual performance now responds to workplace morale/reputation/tension and manager relationship; low performance can demote before termination, while eligible performance can produce bonuses.
- Layoffs are distinct from performance firing and respond to employer morale and broader business-demand conditions.
- Retirement closes both full-time and active part-time employment and archives the associated workplaces.
- Generational continuation clears the former protagonist's institutional worlds and reconstructs only the newly controlled descendant's relevant worlds, preventing social-world leakage across generations.
- Work events may treat active part-time employment as valid employment and bind exact affiliated NPC/world payloads.

### Validation

- Engine TypeScript check passes.
- Test/harness TypeScript check passes.
- 71/71 regression cases pass.
- Content audit: 691 events total, including 90 work/career events.
- Neutral 1,000-life bulk population: zero anomalies and zero forced terminal deaths.
- Mixed-policy 1,000-life bulk population: zero anomalies and zero forced terminal deaths.
- Long-process profiling reached 1,000 sequential lives with bounded memory and stable per-life runtime.
- Dependency-backed React/Vite production build remains the GitHub Actions deployment gate.

## 0.10.0 — 2026-09-04 — Persistent School Social Worlds

### Added

- Save schema v7 with a persisted generic `SocialWorld` layer for schools now and workplaces/organizations later. Existing v6 education history reconstructs compatible archived/current school contexts during migration.
- Country-profile school progression with varied stage start/transition ages and simplified minimum school-leaving ages while preserving the established primary/middle/secondary education record taxonomy.
- Persistent school rosters with classmates, teachers, coaches, and school leadership stored as ordinary NPCs with memories, relationship state, aging, careers, and later-life continuity.
- School clubs, teams, service groups, arts, academic organizations, social groups, and leadership paths tied to recurring roster NPCs.
- Persistent attendance, conduct, social standing, honors, disciplinary history, academic-shortcut consequences, and school volunteering.
- Admissions profiles that combine academics, intelligence, discipline, conduct, involvement, reputation, school standing, and honors; scholarships can cover different proportions of tuition.
- Target-aware school events for recurring classmates and school authorities. Event effects and memories bind to the same NPC shown in the event copy.
- Shared-world history in People sheets so former classmates remain identifiable by the institution/role through which the player knew them.
- Background NPC simulation tier for ordinary school acquaintances; meaningful friends, rivals, romantic relationships, and family automatically receive the full annual autonomy pass.
- Explicit simulation seed prefixes for independent population batches plus streaming simulation aggregation to avoid retaining complete result objects for every finished life.
- Regression coverage for school-world migration, country school profiles, persistent rosters, bounded group activity, conduct/attendance, admissions weighting, compulsory-school leaving rules, and school-friend romance age safety.

### Changed

- School affiliation is no longer encoded solely by `Relationship.type`. A former classmate can become a friend, enemy, partner, or spouse and still remain discoverable in People → School through persisted institutional membership.
- Childhood education transitions are profile-driven rather than one global 5→11→14→18 schedule.
- Compulsory school cannot be dropped before the profile's minimum leaving age; post-secondary programs remain voluntarily leaveable.
- Teen/adult relationship milestone validation now applies to existing school friends too, closing a path that could bypass the normal dating-age rules.
- School activity effort uses the centralized action ledger, preventing join/participation/academic-risk reroll spam.

### Validation

- Engine TypeScript check passes.
- Test/harness TypeScript check passes.
- 64/64 regression cases pass.
- 72 TS/TSX source files pass syntax transpilation in the dependency-limited workspace.
- Two distinct 500-life neutral batches (1,000 unique lives total): zero anomalies and zero forced terminal deaths.
- Two distinct 500-life mixed-policy batches (1,000 unique lives total): zero anomalies and zero forced terminal deaths.
- Additional final 500-life mixed-policy sanity batch after age-boundary fixes: zero anomalies and zero forced terminal deaths.
- Dependency-backed React/Vite production build remains the GitHub Actions deployment gate.

## 0.9.9 — 2026-09-04 — Life Saves & Dynamic Family Legacy

### Added

- Real multi-slot life saves backed by the existing IndexedDB/local fallback store. Independent new lives no longer overwrite `slot-1`.
- Account-level active-save tracking so Everthread reopens the last selected life and safely falls back to another surviving slot when needed.
- `Life Saves` tab with an expandable Ongoing Lives folder for switching between independent lives and deleting saved lineages, plus an account-level Past Lives folder aggregated from surviving saves.
- Dynamic Family Legacy showcase that ranks living and completed lives using a bounded legacy score across longevity, primary stats, logarithmic wealth, fame, family, career, and major milestones.
- Completed-life generation metadata for new deaths, with index-based generation inference for older saves.
- Regression coverage for collision-free slot allocation, earlier-generation legacy selection, and automatic best-life fallback when the featured save is removed.

### Changed

- The former `Past Lives` meta tab is now `Life Saves`.
- Creating a custom or random independent life allocates a separate save slot and preserves account-level settings.
- Switching saves flushes pending writes and saves the current life before loading the target slot.
- Imported JSON is installed as a new independent life save instead of silently overwriting an existing slot ID.
- Deleting the only remaining life save is blocked; create another life first so the runtime always retains one authoritative state.
- The Family Legacy card keeps its existing visual role but can feature any surviving generation, including an earlier completed generation when that life scores better than the current protagonist.

### Validation

- Engine TypeScript check passes.
- Test/harness TypeScript check passes.
- 57/57 regression cases pass.
- Neutral 1,000-life bulk run: median lifespan 81, median net worth 637,451, millionaire rate 40.5%, zero anomalies and zero forced terminal deaths.
- Mixed-policy 1,000-life bulk run: median lifespan 82, median net worth 840,742, millionaire rate 45.3%, zero anomalies and zero forced terminal deaths.
- Dependency-backed React/Vite production build remains the GitHub Actions deployment gate.

Everthread is pre-release. Versions below are development milestones, not public release promises.

## 0.9.8 — 2026-09-04 — Relationship Trees & First Playable Minigames

### Added

- Relationship folders in the People tab: Player Family, Relatives, Friends & Social, Romantic History, School, and Work.
- Mobile relationship-tree view rooted on the player, with persisted NPC parent/child/partner edges and direct fallback edges only when a folder member would otherwise be disconnected.
- Known connection details in NPC sheets so parent, child, and partner links are visible outside the tree.
- Reusable full-screen minigame overlay with timing, sequence-memory, grid-memory, and decision challenge mechanics.
- Interactive minigame integration for acting auditions, professional-sports attempts, combat bouts, motorsport races, and prison escape.
- Character-skill accessibility resolution for minigames and license tests when the minigame preference is disabled.
- Regression coverage for folder classification, non-invented NPC graph edges, extended-family tree linkage, minigame outcome direction, and seeded accessibility resolution.

### Changed

- People search remains global, while the default People surface now prioritizes relationship folders over one long flat list.
- Minigame scores are bounded modifiers to existing simulation formulas; character skill, circumstances, and seeded RNG still resolve final outcomes.
- Timing challenges fall back to sequence-memory play when the device reports a reduced-motion preference.
- Career-screen job/program derivation is recalculated on each engine render instead of being memoized against mutable `GameState` identity.

### Validation

- Engine TypeScript check passes.
- Test/harness TypeScript check passes.
- 55/55 regression cases pass.
- React/TSX source passes a shimmed TypeScript UI compile in the dependency-limited workspace; the dependency-backed Vite production build remains the GitHub Actions deployment gate.
- Neutral 1,000-life bulk run: median lifespan 81, median net worth 637,451, millionaire rate 40.5%, zero anomalies and zero forced terminal deaths.
- Mixed-policy 1,000-life bulk run: median lifespan 82, median net worth 840,742, millionaire rate 45.3%, zero anomalies and zero forced terminal deaths.

## 0.9.7 — 2026-09-04 — Childhood Eligibility & Dependent Finances

### Added

- Explicit age eligibility for investment trading, travel, structured wellness, pet adoption, and collectible-market purchases at both engine and mobile-UI layers.
- Childhood wellness unlocks by activity: walking at 3, running at 5, martial arts/meditation at 6, intentional diet activity at 10, and gym at 13.
- Regression coverage for newborn investment/travel blocking, age-staged wellness unlocks, dependent-minor finance, and guardian-supported shortfalls.

### Changed

- Investment buying and selling now require age 18. Pet adoption unlocks at age 5, and collectible-market purchases at age 12.
- Independent vacations now require age 18. Family trips become available at age 5, require a living parent/stepparent/grandparent while under 18, and draw the trip cost from the guardian's simulated household wealth rather than the child's personal cash.
- Dependent minors no longer pay ordinary baseline living, lifestyle, child, pet, property, vehicle, or debt-service costs from personal cash. Taxes still apply to actual taxable teen income.
- Negative cash while under 18 is normalized through tracked guardian support instead of being converted into an unsecured personal loan.
- Student or other explicit liabilities can still exist in state, but ordinary annual debt payments do not begin while the player is a dependent minor.

### Fixed

- Newborn characters could buy and sell securities.
- Newborn characters could initiate vacations and family trips.
- Newborns could use gym/running/walking/meditation/diet/martial-arts actions before any age eligibility existed.
- Newborns could also initiate pet adoption and collectible-market purchases if starting household cash happened to be high enough.
- A dependent child could reach adulthood already carrying ordinary personal insolvency debt because year-end shortfall handling treated minors like independent adults.

### Validation

- Engine TypeScript check passes.
- Test/harness TypeScript check passes.
- 51/51 regression cases pass.
- Neutral 1,000-life bulk run: median lifespan 81, median net worth 637,451, millionaire rate 40.5%, zero anomalies and zero forced terminal deaths.
- Mixed-policy 1,000-life bulk run: median lifespan 82, median net worth 840,742, millionaire rate 45.3%, zero anomalies and zero forced terminal deaths.

## 0.9.6 — 2026-09-04 — Action Economy & Exploit Hardening

### Added

- Central persisted action ledger with data-defined per-age limits and multi-year cooldowns. A single action can claim multiple limits atomically, such as both a yearly application budget and a one-attempt-per-listing rule.
- Save schema v6 with v5→v6 migration. Existing annual career/family action markers are preserved in the new ledger so updating a save cannot refresh already-used attempts.
- Read-only action-gate queries for React so mobile buttons can disable when their meaningful yearly opportunity has been spent, while the engine remains the authoritative enforcement layer.
- Anti-reroll regression coverage for job applications, wellness/stat grinding, NPC interaction grinding, publicity income, business launches/products, property renovation, collectible hunting, action-ledger migration, and failed-outcome engine notifications.

### Changed

- Job applications are limited to five serious attempts per age and one attempt per exact listing; a failed interview consumes the attempt instead of allowing infinite RNG retries.
- Freelance work, school effort, enrollment, wellness, treatment, rehab, risky habits, meeting people, NPC interactions, relationship milestones, fame posts/opportunities, travel, licenses, crime/prison actions, pet care, collectible hunting, business founding/product launches, and major special-career actions now use explicit yearly opportunity budgets or cooldowns.
- Time-intensive special-career actions now model annual opportunity cost: training, auditions, music releases/tours, pro-contract attempts, fights, campaigns, political moves, royal duties, modeling work, races, films, criminal-organization work, and specialized-organization decisions are bounded at the simulation layer.
- Major property renovations now have a two-age cooldown and improve condition without creating guaranteed immediate net-worth arbitrage.
- Business founding is limited to one company per age and each business can complete one major product launch per age.
- Collectible hunting is limited to four major acquisitions per age and one attempt per exact collectible definition.
- Relationship marriage/reconciliation milestone counters now live in `RelationshipSystem`, not the UI-facing engine wrapper, so headless/system callers cannot bypass them.
- Acting lessons now check adult affordability before consuming the yearly training opportunity; already-represented actors and already-committed sports paths reject duplicate setup actions.
- GameEngine now emits/autosaves failed outcomes when RNG, deterministic IDs, or the action ledger changed. A rejection, loss, failed audition, failed crime, or other consumed attempt therefore persists instead of silently becoming rerollable after a render/save boundary.
- React external-store subscriptions now use a private engine revision snapshot instead of mutable `GameState` object identity, so engine emissions reliably trigger UI updates even without an unrelated local React state change.
- Career, education, People, Activities, Assets, pet, business, collectible, and special-career mobile controls visually disable when the central engine policy says their opportunity is exhausted.

### Validation

- Engine TypeScript check passes.
- Test/harness TypeScript check passes.
- 47/47 regression cases pass.
- All 66 TypeScript/TSX source files pass a TypeScript syntax/transpile parse; the dependency-backed React/Vite build remains a GitHub Actions deployment gate.
- Neutral 1,000-life bulk run: median lifespan 81, median net worth 655,640, millionaire rate 40.7%, zero anomalies and zero forced terminal deaths.
- Mixed-policy 1,000-life bulk run: median lifespan 82, median net worth 823,294, millionaire rate 44.5%, zero anomalies and zero forced terminal deaths.

## 0.9.5 — 2026-09-04 — First Mobile Playtest Hardening

### Added

- Save schema v5 with migration support for family-planning state and targeted repair of the pre-0.9.5 runaway salary exploit.
- One-year pregnancy state for biological parenting; successful conception resolves into birth after the next Age Up rather than creating a child instantly.
- Compact mobile money formatting for million, billion, trillion and quadrillion-scale values.
- Regression coverage for senior-career experience gates, annual career-action limits, pregnancy timing, v4 exploit-save repair and extreme mobile money formatting.

### Changed

- Higher-level standard jobs now require actual relevant industry experience before they appear as qualified listings.
- A successful new hire prevents another job start in the same age.
- `Work harder` and `Ask for raise` are each annual-focus actions and cannot be spammed repeatedly within one age.
- Standard-career salary growth and raises respect a role-market ceiling instead of compounding without bound.
- Sibling first names avoid duplicates while unused regional names are available.
- PWA navigation uses network-first loading with cached offline fallback; service-worker registration explicitly checks for updates.

### Fixed

- Players can no longer become level-six executives at age 18–20 with no relevant work history simply by passing a difficult interview.
- Repeated same-year raise requests can no longer turn ordinary salaries into trillion/quadrillion-scale compensation.
- Repeated same-year `Work harder` actions can no longer instantly max performance/stress.
- Repeated family taps can no longer generate many independent births in the same year.
- Existing v4 saves that clearly match the runaway-compensation exploit are repaired on load: salary and impossible role level are normalized and the identifiable exploit-year net cash windfall is reverted. Existing children are never deleted by migration.
- Extreme money values no longer overflow the Life, Career and Assets mobile cards.

### Validation

- Engine TypeScript check passes.
- Test/harness TypeScript check passes.
- 37/37 regression cases pass.
- Neutral 1,000-life bulk run: median lifespan 81, median net worth 651,017, millionaire rate 40.7%, zero anomalies and zero forced terminal deaths.
- Mixed-policy 1,000-life bulk run: median lifespan 82, median net worth 819,767, millionaire rate 44.6%, zero anomalies and zero forced terminal deaths.

## 0.9.4 — 2026-09-04 — Estate Threads & Economic Calibration

### Added

- Multi-heir estate settlement with normalized living beneficiary shares, non-mortgage debt settlement, proportional investment division, deterministic retained-asset allocation, and fairness-driven liquidation of indivisible assets when necessary.
- Offscreen sibling inheritance accounting so NPC heirs receive their share instead of the controlled descendant inheriting every retained asset.
- Player inheritance from wealthy NPC parents, including lifetime inheritance and inheritance-count tracking.
- Continued-descendant preservation for established standard careers, spouses/partners, children and deeper derived family relationships such as grandparents and grandchildren.
- Wealth-source diagnostics for cash, property equity, investments, businesses, vehicles, collectibles and debt.
- Investment diagnostics for lifetime contributions, withdrawals, held cost basis and held market gain.
- Three-generation continuation regression and exact wealth-source reconciliation regression.

### Changed

- Fictional security long-run drifts and market-regime central tendency were reduced to fit Everthread's bounded relative economy. Volatility, bubbles and crashes remain intentionally meaningful.
- Annual finance processing now includes modest after-tax-income-scaled discretionary lifestyle spending for ordinary recurring consumption not represented by explicit purchases.
- Underwater property equity is reported as negative equity instead of being hidden at zero in balance diagnostics.
- A deceased player's NPC record now preserves its own parent links, allowing the next protagonist to derive grandparents after a generation handoff.

### Fixed

- Selected descendants no longer receive 100% of retained investments, properties, businesses and collectibles while siblings divide only cash.
- Wealthy NPC parents no longer skip the player when distributing inheritance simply because the player is not stored inside the NPC map.
- Adult descendants no longer lose an existing standard career when control passes to them.
- Generation handoffs no longer flatten deeper supported family relationships out of the playable relationship view.

### Validation

- Engine TypeScript check passes.
- Test/harness TypeScript check passes.
- 32/32 regression cases pass.
- Three sequential generation handoffs preserve lineage and pass state invariants in regression.
- Neutral 1,000-life bulk run: median lifespan 82, median net worth 686,454, millionaire rate 41.1%, zero anomalies and zero forced terminal deaths.
- Mixed-policy 1,000-life bulk run: median lifespan 82, median net worth 853,976, millionaire rate 45.6%, zero anomalies and zero forced terminal deaths.
- On the same neutral seeds, average held investment gain fell from roughly 1.54M before market calibration to roughly 257k after calibration; average lifetime inheritance is roughly 133k, confirming inheritance was not the primary wealth distortion.

## 0.9.3 — 2026-09-04 — Deterministic Replay & Balance Policies

### Added

- Save-persisted state-scoped runtime ID generation keyed by the life seed and a monotonic `idCounter`.
- Save schema v4 with explicit v3→v4 migration for deterministic ID state.
- Legacy rewind snapshots are migrated before restoration, including the new ID counter.
- Exact-history replay regression: two independent 50-year runs with the same seed/actions must serialize identically, including generated IDs and NPC/event history.
- Runtime-ID uniqueness regression across long generated lives.
- Six independent simulation decision policies: neutral, conservative, reckless, social, family-focused, and career-focused.
- Mixed-policy population simulation separate from life aspiration profiles such as academic, creative, athletic, entrepreneurial, and criminal.
- Wealth percentile reporting at p10/p25/p75/p90/p99.

### Changed

- Replaced all 71 wall-clock runtime ID creation sites in simulation systems with deterministic state-scoped IDs.
- Neutral simulation job selection no longer sorts primarily by maximum salary; career-focused policy retains deliberate salary optimization while conservative policy favors lower stress/risk.
- Investment, property, education, relationship, wellness, event-choice, and family behavior now vary by simulation policy.

### Validation

- Engine TypeScript check passes.
- Test/harness TypeScript check passes.
- 27/27 regression cases pass.
- Replay-safe 1,000-life bulk run completes with zero anomalies and identical aggregate results to the pre-ID migration baseline.
- Neutral 1,000-life run: median lifespan 83, median net worth 865,919, millionaire rate 46.6%, marriage rate 52.2%, zero anomalies.
- Mixed-policy 1,000-life run: median lifespan 82, median net worth 1,094,138, millionaire rate 52.6%, marriage rate 54.5%, zero anomalies.

## 0.9.2 — 2026-09-04 — Living World & Delayed Consequences

### Added

- Autonomous close-family NPC career selection using real job IDs, promotion/loss/retirement progression, wealth drift, linked partners, marriage/divorce/widowhood, bounded child generation, and inheritance to living children.
- Family-tree derivation for autonomous births, including niece/nephew and grandchild relationships where applicable.
- Bidirectional NPC-partner invariant checks and repair; player romantic partners are excluded from autonomous matchmaking.
- Delayed-event context payloads that can retain a specific NPC target and original decision age across future years.
- Persistent-target text templating for delayed consequences (`{NPC_NAME}`, `{NPC_FIRST}`, `{ORIGIN_AGE}`).
- Five first-class delayed-consequence chains: romantic secrecy, family financial favors, ignored health warnings, workplace shortcuts, and broken confidences.
- Four regression checks covering delayed target fidelity, cancellation when a required relationship disappears, origin-age context, and consequence-chain wiring.

### Changed

- Random/forced target-aware events can bind a persistent romantic, family, or friend NPC before the decision is shown, so prose and effects refer to the same person.
- Timeline entries generated by targeted events retain the affected NPC ID.
- Delayed relationship effects now explicitly resolve against the saved payload target rather than selecting another living relationship.

### Validation

- Engine TypeScript check passes.
- Test/harness TypeScript check passes.
- 24/24 regression cases pass.
- 1,000-life bulk run completed with zero detected structural anomalies and zero forced terminal-age deaths.
- Current audited content count: 679 event definitions, including 199 relationship-focused and 83 work/career events.

## 0.9.1 — 2026-09-03 — Verification & Simulation Hardening

### Added

- Deterministic regression suite with 18 core/integration checks.
- Headless multi-life simulation harness with full and bulk modes.
- 1,000-life bulk validation path and aggregate reporting for lifespan, wealth, education, career, marriage, children, crime, convictions, fame and death causes.
- Executable content audit.
- `DEVELOPMENT.md`, `CONTENT.md`, and `CHANGELOG.md` project continuity files.
- Economy-state fields for last cost/wage/housing index movement.
- Insolvency pressure handling: annual cash shortfalls become structured unsecured debt; sustained hardship can trigger foreclosure and bankruptcy.
- Mortgage affordability underwriting and a five-year post-bankruptcy mortgage restriction.

### Changed

- Event selection now uses category-indexed routine pools plus a small exact-probability rare-event pass instead of evaluating/rolling all 670 definitions every year.
- Economy indices now model bounded relative conditions instead of unbounded century-long nominal inflation.
- Existing standard-career salaries follow wage-index movement so long-held jobs do not become economically frozen.
- Achievement evaluation no longer runs redundantly twice on ordinary no-event age-ups; progress lookup and metric evaluation are cached per pass.
- Bulk simulations may suppress achievement/challenge evaluation and truncate timeline history for performance; full mode remains the correctness reference.

### Fixed

- Adult player dating generation can no longer create a minor potential partner.
- Biological-child action now validates the minimum parenting age of both participants.
- Duplicate active spouses are repaired by state invariants.
- Descendant continuation no longer pays retained asset value again as full liquid inheritance.
- Mortgages on retained inherited properties now remain in the descendant's liabilities.
- Descendant relationship reconstruction preserves parents, siblings, partners/spouses and children instead of flattening most surviving NPCs into friends.
- Annual business owner distributions are not credited a second time in finance processing.
- Death timeline ordering and legacy simulated-year double-counting issues identified in the foundation pass remain corrected.
- Foreclosure equity now offsets a cash shortfall exactly once and preserves any excess residual cash rather than double-consuming proceeds.

### Validation

- Engine TypeScript check passes.
- Test/harness TypeScript check passes.
- 18/18 regression cases pass.
- 1,000-life bulk run completed with zero detected state anomalies and no forced terminal-age deaths.

### Known follow-up

- Simulation policy over-optimizes investments and job selection, so its millionaire/career distributions are not yet neutral balance targets.
- Vehicle repossession, richer creditworthiness, and voluntary bankruptcy UI remain incomplete; engine-level shortfall debt, foreclosure, bankruptcy and mortgage underwriting now function.
- Exact replay is not yet guaranteed because generated object IDs still include wall-clock time.

## 0.9.0 — 2026-09-03 — Foundation Build

- Established Everthread: Life Unwritten branding and mobile application shell.
- Added authoritative `GameState`, seeded RNG, systems architecture, Age Up loop and timeline.
- Added character generation, relationships/family, education, standard careers, finances, health, crime/legal/prison, investments, businesses, property, pets, travel, fame and special-career foundations.
- Added death summaries, completed lives, legacy state and descendant continuation.
- Added IndexedDB persistence, settings persistence, save migration through schema version 3, JSON import/export, autosave and rewind-enabled snapshots.
- Added achievements/challenges, settings/past-life/sandbox sheets, mobile bottom navigation, event/death sheets, theme/accessibility controls and PWA scaffolding.
- Added large original content databases for events, careers, health, crimes, properties, pets, countries, achievements and challenges.
