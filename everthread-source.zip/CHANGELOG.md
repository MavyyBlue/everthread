# Everthread Changelog

## Phase 8A — Everthread Setting Foundation — CI Green Run #125 — 2026-09-13

### Added / changed

- Established **Everthread** as the canonical home setting for player-facing new lives while retaining `countryId/city` as the single physical/legal/economic location authority used by mature systems.
- Added fictional Everthread jurisdiction/city definitions and a shared `locationLabel` projection; executable country definitions increase **32 → 33**.
- Added hidden `namePoolCountryId` to separate cultural procedural naming from physical residence. Character/NPC naming, name-based identity inference, autonomous family naming, and dynasty continuation now preserve this profile independently from travel/emigration.
- Removed the real-country selector from the New Life player UI. Low-level scenario/test country overrides remain supported without becoming player-facing home selection.
- Added `SettingSystem` with safe naming-profile normalization and schema-14 → 15 setting migration. The migration moves only the protagonist's current local simulation context into Everthread, preserves remote/historical state, retains prior travel history, is idempotent, and consumes no gameplay RNG or runtime IDs.
- Active country-scoped world conditions and active SocialWorlds tied to the former local context follow the migration; archived SocialWorlds and resolved world-condition history remain historical. Later schema-15 emigration remains durable on load.
- Everthread uses the established North-American-style school profile as the current education compatibility bridge. Travel copy and initial birth/location copy avoid duplicate `Everthread, Everthread` labels.
- Travel destination UI defaults away from the current location and labels location economics generically.
- Save schema advances **14 → 15**.

### Certification

- Added `phase8ASettingFoundationRegression.ts`: **25/25** checks covering default Everthread residence, separate cultural naming profiles, legacy migration preservation, local-vs-remote NPC/world semantics, active-vs-historical world conditions, travel history, RNG/ID neutrality, idempotence, invariants, and post-migration emigration durability.
- Dynasty transition regression is **64/64** with naming-profile preservation; all established family/estate/credit/asset/NPC/world-condition and other suites remain Green. Base regression suite is **82/82** and Integrated Long-Life remains **105/105**.
- Both TypeScript gates PASS; canonical Everthread preflight PASS **4/4**; production build PASS with Vite 7.3.6 at **171 modules**. The established >700 kB main-chunk warning remains nonblocking technical debt.
- GitHub Actions Run #125 (`34807854189`) certified expanded gameplay/source `2596084575dd4288a0b549dc1a618736280f135b` from upload wrapper `36b8ce0863d8a6ddd69e20a85b99ed6ec216cb2a` on package `0.12.0`, save schema **15**.
- Certified source SHA-256: `46efef3174bb53984b67fcf1c1512fdb8a741a65edb37006654e602b21a8253c`; dependency SHA-256: `7c1e03244499adf494b2bb986797e603270624d047eee8bc52e3c48b68364eab`; package-lock SHA-256: `da0cd3cd1a975e0d7d6a8466d55826bc8277dc35f55e7685be85d7ecf11f2886`.
- Certified preflight artifact ID `10333602478`, digest `6e65d5df2511792614c00b9e50b5db70e2953e2d5f4fc7964e6fc191a880b77d`; Pages artifact ID `10333582525`, digest `f519a783f900fc860dfb70168b7277d0b65b4c77cb83624ef1d83a0a7162cd02`; deployment reported success.
- Post-certification Feedback Inbox sweep still found four total reviewed/resolved reports and no new report rows; stored review checkpoint successfully advanced to `2596084575dd4288a0b549dc1a618736280f135b`.
- **Next slice:** Phase 8B — Town Place Registry & 2D Flat Map.

## Phase 7C — Persistent World Conditions — CI Green Run #122 — 2026-09-13

### Added / changed

- Added one bounded `WorldConditionSystem` authority for persistent national/global conditions. It owns condition identity, exact country/global scope, duration, intensity, durable cooldowns, bounded active/history state, deterministic annual start/expiry, and read-only modifier projection; it owns no cash, jobs, housing, investments, fame, business, travel, or event queue truth.
- Added seven original data-driven conditions outside the 691-event random library: Growth Wave, Economic Slowdown, Cost Surge, Housing Squeeze, Travel Disruption, Media Frenzy, and Market Jitters. Country conditions bind the exact country where they started; global conditions remain globally relevant.
- Existing authorities consume bounded modifiers instead of being bypassed: `EconomySystem` (inflation/salary/housing/business demand), `CareerSystem` (application pressure/layoff risk), `BusinessSystem` through the economy index, `PropertySystem` through housing, `InvestmentSystem` (drift/volatility), `TravelSystem` (trip cost), `FameSystem` (organic growth/scandal/publicity economics), and `FinanceSystem` (ordinary household living-cost pressure).
- Added a compact mobile Life-screen **World around you** card showing only conditions relevant to the player’s current country plus global conditions, including scope, intensity, remaining years, description, and effect summary. Start/expiry also write bounded timeline entries under the new `world` timeline category; no standalone popup queue is introduced.
- Annual condition selection uses an isolated deterministic world-condition RNG stream derived from seed/year/country and does not advance `state.rngCounter`. Existing downstream RNG draw shapes remain unchanged.
- Save schema advances **13 → 14** for durable `worldConditions`. Migration creates empty world-condition state without retroactive history and is deterministic, idempotent, gameplay-RNG neutral, and runtime-ID neutral. Active conditions are capped at 4 and resolved history at 48.

### Certification

- New `phase7CWorldConditionRegression.ts`: **42/42** checks covering content isolation/counts, schema-14 migration, migration idempotence/RNG neutrality, deterministic generation, active/history bounds, multi-year expiry/history, exclusive groups/cooldowns, country/global relevance across emigration/return, UI projection, Economy/Business/Property/Investment/Travel/Fame/Finance integration, save round-trip, queue isolation, exact scope, and global invariants.
- Both TypeScript gates PASS; complete regression wall PASS; Integrated Long-Life 105/105; Phase 7A 36/36; Phase 7B1 33/33; Phase 7B2 35/35; Phase 7B3 36/36; all established career/estate/finance/NPC suites remain green.
- Production build PASS with Vite 7.3.6 at **170 modules**. The established >700 kB main-chunk warning remains nonblocking technical debt.
- GitHub Actions Run #122 (`34797847276`) certified expanded gameplay/source `0770106f52eea3182e86d120fa38c6b90be589e4` from upload wrapper `60e5646c274cd36024a778a93a1b8c1af3a401c5` on package `0.12.0`, save schema **14**.
- Fresh live Feedback Inbox review after certification found **4 total reports, all 4 resolved**. The bookkeeping checkpoint write was blocked by connector safety, so no later checkpoint value is claimed.
- **Phase 7 is closed.** After this closeout synchronization is certified, implementation planning stops until Mavyy and Yuki brainstorm the future direction together.

## Phase 7B3 — Special-Career Long-Tail Echoes — CI Green Run #120 — 2026-09-13

### Added / changed

- Extended Phase 7B into the three persistent special-career ecosystems that were not already served by the older Phase 4D8 annual story scanner: combat sports, military service, and politics.
- Added five action-driven probability-zero echoes: combat training with the exact coach, a sanctioned bout with the exact rival, military training with the current posting/commander when available, a political policy push with the exact office/chief of staff when available, and a press confrontation with the exact office/opposition leader when available.
- Existing `SpecialCareerStorySystem` annual mentor/rival/path scanning is unchanged. Phase 7B3 is requested only by explicit player actions through `SystemicStorySystem` → `ConsequenceSystem`, avoiding a second special-career story generator.
- Added a narrow data-driven `ChoiceEffect.specialCareer` effect for bounded `skill`, `reputation`, and `approval` deltas on the exact `payload.careerKind`. It cannot alter wins/losses, titles, contracts, seasons, elections, terms, ranks, promotions, projects, or other lifecycle-result authority.
- Exact archived SocialWorlds remain valid history; dead/missing exact NPC/world targets cancel deterministically rather than retargeting. Military/politics actions taken before their annual world is created may schedule career-only history without forcing premature world creation.
- Save schema remains **13**. Scheduling consumes no gameplay RNG; the ordinary random-event library remains exactly **691** definitions and the older 18-definition dedicated special-career story registry remains separate.

### Certification

- GitHub Actions Run #120 (`34796052224`) certified expanded source `4dd4378ec8986056fc3348dec5b2c6b1594b236b` from upload wrapper `c74078a41340023ab7760378f1fdfe0f77108643` on package `0.12.0`, save schema **13**.
- `phase7B3SpecialCareerEchoRegression.ts`: **36/36**; Combat 51/51; Military 65/65; Politics 80/80; Special-career Story 37/37; Path-story 68/68; Integrated Long-Life 105/105; Phase 7A 36/36; Phase 7B1 33/33; Phase 7B2 35/35; Progressive Disclosure 25/25; Random-event Coherence 77/77; minigame 19/19; Feedback Reporting 20/20; Feedback Central Inbox 23/23; all established suites remained green.
- Canonical preflight passed Engine TypeScript, Test TypeScript, the complete regression wall, and production build with Vite 7.3.6 at **168 modules**. The established >700 kB main-chunk warning remains nonblocking technical debt.
- Certified source SHA-256: `b742118c6ce2db92abf774f178d1f067551ced5148268cdaf70de1c70e78f539`.
- Certified dependency SHA-256: `657e8c495c687e2f4667000052eb2c42461568c5e5bfe970f48e14290bd071dd`; package-lock SHA-256: `da0cd3cd1a975e0d7d6a8466d55826bc8277dc35f55e7685be85d7ecf11f2886`.
- Certified artifact ID `10329833244`, digest `51b4e4bdc22a9824039f46a20eee603081b66f243e7abd3f70650a7b2df56ef5`; Pages artifact ID `10329833247`, digest `2f00aa0d6b096b3379db5ad80e74b42afbae74a09bf9dfb28544dd99aa2e92a8`. Certified restore smoke and Pages deployment reported success.
- A fresh live Supabase review after Run #120 found **4 total reports and 0 unresolved reports**; the review checkpoint is advanced to `4dd4378ec8986056fc3348dec5b2c6b1594b236b`.

## Phase 7B2 — Ownership & Workplace Echoes — CI Green Run #118 — 2026-09-13

### Added / changed

- Added five action-driven systemic delayed stories for property renovation, business founding, business product launches, manager feedback, and formal coworker concerns.
- All five use the existing `SystemicStorySystem` request bridge and certified `ConsequenceSystem`; no new narrative queue, graph, or save authority is introduced.
- Property stories bind the exact owned property and cancel if it is sold/missing before the due age. Business stories bind the exact existing business. Workplace stories bind the exact persistent workplace world plus the exact manager/coworker and may intentionally surface after the workplace archives; dead/missing people or missing worlds cancel rather than retarget.
- Added data-driven property effects for bounded condition/value-percentage changes and business effects for bounded demand/reputation changes. Event rendering resolves `{PROPERTY_NAME}` / `{BUSINESS_NAME}` / workplace `{WORLD_NAME}` from authoritative state instead of copying names into durable story payloads.
- Property/business consequence resolutions expose exact semantic state-change keys. Asset and business story outcomes write to the matching timeline categories.
- Save schema remains **13**. Scheduling consumes no gameplay RNG and the ordinary random-event library remains exactly **691** definitions.

### Certification

- GitHub Actions Run #118 (`34792171294`) certified expanded source `a4d04523e18128044c00f960f6db5fcd306a8237` from upload wrapper `84f1814b46df253e1e00520ed21c12e2e0608a43` on package `0.12.0`, save schema **13**.
- `phase7B2OwnershipWorkRegression.ts`: **35/35**; Core 82/82; Integrated Long-Life 105/105; Phase 7A 36/36; Phase 7B1 33/33; Progressive Disclosure 25/25; Random-event Coherence 77/77; Activity-specific Minigame 19/19; Feedback Reporting 20/20; Feedback Central Inbox 23/23; all established suites remained green.
- Canonical preflight passed Engine TypeScript, Test TypeScript, the complete regression wall, and production build with Vite 7.3.6 at **168 modules**. The established >700 kB main-chunk warning remains nonblocking technical debt.
- Certified source SHA-256: `bba33e3f10e6d4a81e321acbd9aad5051f9092ac4c68e220e613bb62a4be5075`.
- Certified dependency SHA-256: `e88590934865025dcb26987fa254cefa18c346f022b94e0378933752e076bee1`; package-lock SHA-256: `da0cd3cd1a975e0d7d6a8466d55826bc8277dc35f55e7685be85d7ecf11f2886`.
- Certified artifact ID `10328692946`, digest `3f49ce6df32cedcb03f20b39ed547bb0e2c5420ebd83498c81306109638b8f58`; Pages artifact ID `10328503412`, digest `6eeb415d39319542a382c563b914390a16071e9e1d3d2cf50e724d55325dc86c`. Certified restore smoke and Pages deployment reported success.
- A fresh live Supabase review after Run #118 found **4 total reports and 0 unresolved reports**; the review checkpoint is advanced to `a4d04523e18128044c00f960f6db5fcd306a8237`.

## Feedback UX — age-appropriate progressive disclosure — CI Green Run #117 — 2026-09-13

### Certification

- GitHub Actions Run #117 (`34783290659`) certified expanded source `9822a31df84197ea700ebd890bf0f68cb716637b` on save schema **13**.
- Canonical preflight passed Engine TypeScript, Test TypeScript, the complete regression wall, Progressive Disclosure **25/25**, Integrated Long-Life 105/105, Phase 7A 36/36, Phase 7B1 33/33, Random-event Coherence 77/77, both feedback suites, and production build at **168 modules**.
- Certified source SHA-256: `f2fa8f09e292e46b704e2f2c37a3a1e7b045e28bdfe5a9fcb5e9dcd211213c5f`.
- Certified dependency SHA-256: `856bae49f4e6b469f4e2d85d031f218c38d6dbdc909ef19fc13bcc23244b9579`; package-lock SHA-256: `da0cd3cd1a975e0d7d6a8466d55826bc8277dc35f55e7685be85d7ecf11f2886`.
- Certified artifact ID `10325856281`, digest `7c34b453461c5c6286efc44a8a3959e4601691b077be1fe300b96863aadfce0d`; Pages artifact ID `10325846256`, digest `0bedf7dd068fad6ae217142a9cf69c1d8de2d38e53776f764c743cf696373d99`. Pages deployment reported success.
- Resolved `ET-20260913-BE8649B9` as a deployed suggestion/experience correction against that exact source/run. A fresh Supabase review against Run #117 found **0 unresolved reports**.

### Corrected

- Early-life Activities and Career/Life Paths now hide age-ineligible choices until their owning gameplay systems say the threshold has been reached, while legacy/current records stay visible for save compatibility.
- Engine eligibility remains authoritative; the presentation layer consumes shared owner thresholds rather than maintaining a second set of age rules.

## Phase 7B1 — Family, School & Relationship systemic stories — CI Green Run #115 — 2026-09-13

### Added / changed

- Added five system-owned delayed stories driven by real player actions rather than annual random rolls: time spent with a child, academic misconduct, a serious friend argument, romantic reconciliation, and marriage expectations.
- Added `SystemicStorySystem` as an RNG-neutral request bridge into the already-certified `ConsequenceSystem`. It owns no queue, relationship, NPC, school, or save truth; `state.delayedEvents` remains the sole active consequence queue.
- Added `systemicConsequenceEvents.ts` as a dedicated probability-zero content registry outside the 691-event random pool. Exact NPC/social-world targets, origin age, due age, validity, and dedupe are carried by the certified scheduler.
- Added exact school-world event effects for conduct/social standing/attendance. The first school follow-up can therefore change the persistent school record already consumed by post-secondary admissions rather than applying a detached stat-only outcome.
- Event description rendering now resolves `{WORLD_NAME}` from the referenced `SocialWorld`; relationship stories continue to resolve the exact NPC from payload authority.
- Reconciliation stories cancel if the relationship ends before they mature; marriage stories require the same exact spouse; dead NPCs and missing school worlds cancel deterministically rather than retargeting.
- Updated the integrated long-life test helper to resolve scheduler-required same-age backlog before retrying Age Up, matching certified Phase 7A player-facing gating instead of assuming every Age Up advances immediately.
- Save schema remains **13**; no gameplay RNG is consumed by story scheduling and no new durable authority was introduced.

### Certification

- GitHub Actions Run #115 (`34782061788`) certified expanded source `f417403ff8a091f92f823c074d6a132dd27b90aa`, package `0.12.0`, save schema **13**.
- Upload wrapper: `0a4372ac7f8a9c3474e5b9e50e995abe11dae2f1`. Canonical preflight passed Engine TypeScript, Test TypeScript, the complete regression wall, and production build.
- `phase7BSystemicStoryRegression.ts`: **33/33**; Core 82/82; Integrated Long-Life 105/105; Phase 7A Persistent Consequence 36/36; Random-event Coherence 77/77; Activity-specific Minigame 19/19; Feedback Reporting 20/20; Feedback Central Inbox 23/23.
- Production build PASS with Vite 7.3.6 at **167 modules**. The established >700 kB main-chunk warning remains nonblocking technical debt.
- Certified source SHA-256: `b30483a74c4c674ad3fbb025a3cb7f78d065b6f438fcf43482e3e21ef9c39613`.
- Certified dependency SHA-256: `dfc18617ab0a94454a3cdae218baa0e9800bff1d5628b32262feba193c212827`; package-lock SHA-256: `da0cd3cd1a975e0d7d6a8466d55826bc8277dc35f55e7685be85d7ecf11f2886`.
- Certified artifact ID `10325695174`, digest `a58934b96b90348293cbe7eec09c4734cf74255802e7d406cbd561bb2d7e26fc`; Pages artifact ID `10324654718`, digest `5ffa444fdbdf27c5ec5f630bad39a0be2b336fdaf731b7b78099fcee91059075`. Pages deployment reported success.

## Post-4G random-event narrative-composition correction — CI Green Run #114 — 2026-09-13

### Certification

- GitHub Actions Run #114 (`34780654179`) certified expanded source `60bfa3eaecb574df5a74920cbc64f513055bae46`, package `0.12.0`, save schema **13**.
- Canonical preflight passed both TypeScript gates, the complete regression wall, Random-event Coherence **77/77**, Integrated Long-Life 105/105, Phase 7A Persistent Consequence 36/36, production build, certified artifact restore smoke, and Pages deployment.
- Certified source SHA-256: `21f7ecbeb2f531cff582ed003925def89e555b5842a06e7231e3375ed6f6daf3`.
- Certified dependency SHA-256: `0833b91abb51c9a7518141591e84b936fbfaecb855d75a8f39d7a8143db7969d`; package-lock SHA-256: `da0cd3cd1a975e0d7d6a8466d55826bc8277dc35f55e7685be85d7ecf11f2886`.
- Certified artifact ID `10324957306`, digest `67835c1585a8ee92bb7bc2db8b638145628f28e3b99ab48dc804119e98ada7af`; Pages artifact ID `10324533122`, digest `5bbb65b63f006278d402a60d665c3a898304104432cf83ffcf089f61acbe5f1d`.

### Corrected

- Resolved live feedback report `ET-20260913-0AA876B7`: procedural event choices were coherent, but generic description templates could produce grammatically invalid or contextless scene text.
- Kept EventSystem/coherence ownership unchanged. The correction normalizes scene settings and uses context-safe description frames across all 664 procedural variants.
- Preserved all 691 random-event definitions, 664 procedural variants, 80 dilemma families, event IDs, probabilities, cooldowns, exact targets, choices/effects, save schema 13, and exactly three descriptions per procedural event, preserving description-selection RNG shape.
- Existing saved `pendingEvent.description` text is not rewritten; already-open choices remain compatible.

## Phase 7A — Persistent Consequence Foundation — CI Green Run #112 — 2026-09-13

### Certification

- GitHub Actions Run #112 (`34778449301`) certified expanded source `536c102e10f27694caa89a8b1d9c473953ca6e76` on save schema **13**.
- Canonical preflight passed 4/4: Engine TypeScript, Test TypeScript, complete regression wall, and production build.
- Phase 7A Persistent Consequence passed **36/36**; Integrated Long-Life 105/105; Feedback Reporting 20/20; Feedback Central Inbox 23/23; all established suites remained green.
- Production build passed with Vite 7.3.6 at **165 modules**; Pages deployment succeeded.
- Certified source SHA-256: `1de3ef6b9063b864afb5a4f80165bbd9eedd3db3a9280313ed68236ebd464c17`.
- Certified artifact ID `10324148743`, digest `e71dfa2020932fa856ec15a425530d7310d8b29ac2b083148abba44943513b3f`; Pages artifact ID `10324273336`, digest `dc0ff7b8d199e46c8dad632fdd506830e580f02fb7ca6feb1d89c78aa919ca4b`.

### Handoff synchronization

- Promoted Phase 7A from local candidate to certified/deployed foundation in `CURRENT_STATE`, `ROADMAP`, `PHASE7_PERSISTENT_CONSEQUENCES`, `DEVELOPMENT`, and `PLAYER_FEEDBACK`.
- Marked **Phase 7B1 — Family, Parenting, School & Relationship systemic delayed stories** as the next gameplay slice.
- Corrected stale wording that still described the secure central Feedback Inbox as future work. Supabase central submission, independent-device receipt, and player-visible disposition/status read-back are already live.
- Explicitly marked activity-specific minigame work as historical/established rather than current so a fresh chat cannot incorrectly resume that older slice.

## Phase 7A — Persistent Consequence Foundation candidate — 2026-09-13

### Added / changed

- Added one authoritative bounded `ConsequenceSystem` while retaining `state.delayedEvents` as the sole active consequence queue.
- Added stable consequence/chain/origin identity, exact due windows, priority/tie ordering, exact durable target refs, validity/cancellation requirements, dedupe, bounded completion/cancellation history, and exact event cooldown ages.
- Added shared `CURRENT_SAVE_VERSION` and candidate schema **13** migration. Schema-12 migration is deterministic, RNG-neutral, idempotent, preserves old pending choices and delayed targets, preserves distinct legacy queued entries when no old dedupe authority existed, and reconstructs legacy cooldown ages without consuming gameplay RNG.
- Moved Financial Pressure arbitration out of FinanceSystem; Finance requests a normal-priority consequence and the scheduler owns ordering. Special-career story openings now schedule high-priority exact-target consequences with stable chain/validity metadata.
- Age Up surfaces already-due backlog before advancing, preventing multiple due consequences from silently drifting into later ages. Descendant continuation resets previous-life scheduler state.
- Added `persistentConsequenceRegression.ts`: **36/36** checks covering cooldowns, deterministic order, pending protection, windows, exact targets/cancellation, dedupe, bounds, migration/idempotence, save/rewind, Finance priority, descendants, content count and invariants.
- Ordinary random event definitions remain **691**.

### Local validation

- Engine TypeScript PASS; Test TypeScript PASS; complete established regression wall PASS.
- Phase 7A Persistent Consequence 36/36; Integrated Long-Life 105/105; Feedback Reporting 20/20; Feedback Central Inbox 23/23.
- Production build PASS with Vite 7.3.6 at 165 transformed modules. Canonical GitHub Actions remains final certification authority.

## Player-visible Feedback disposition — CI Green Run #111 — 2026-09-13

### Added

- Added secure player status read-back to the existing Supabase `everthread-feedback` Edge Function. A report can be queried only with its report ID plus the private 32-byte device token already required for withdrawal.
- Added bounded `player_message` reviewer communication while keeping `triage_status` and `resolution_class` as the only authoritative lifecycle/disposition fields.
- Feedback Center now displays central receipt, review lifecycle, disposition, reviewer message, review timestamp, and a manual **Check status** action.
- Automatic feedback synchronization refreshes review state only for the same bounded 10-report batch already used for retry.
- Centrally dispositioned test report `ET-20260913-A527E2A6` as Resolved → Suggestion noted to validate player read-back after deployment.

### Security / architecture

- The public status endpoint does not expose internal triage/resolution notes, cancellation-token hashes, database access, or other players’ reports.
- No simulation/save authority or gameplay RNG changes. Supabase security advisor remains clean after the schema extension.

### CI validation

- GitHub Actions Run #111 (`34774175236`) certified expanded source `576f9402deb854f8d5bd11891610e035cdd6d7ec`.
- Canonical preflight passed 4/4 with Feedback Central Inbox 23/23, Activity Feedback Reporting 20/20, Activity-specific Minigame 19/19, Core 82/82, AI Interaction Testbench 41/41, Integrated Long-Life 105/105, all established suites, and the 163-module production build.
- Certified artifact ID `10323017491`; Pages artifact ID `10322703128`; Pages deployment succeeded.

## Central Feedback Inbox v2 — CI Green Run #110 — 2026-09-13

### Added

- Created a dedicated free Supabase **Everthread** project in `us-east-2` and deployed the `everthread-feedback` Edge Function for central report submission/withdrawal.
- Added RLS-protected central report, rate-limit, and review-checkpoint tables with revoked public grants, explicit deny policies, triage metadata, source-commit indexing, duplicate linkage, and future-Yuki review state.
- Added local-first remote transport in `src/feedback/remoteInbox.ts`: 32-byte device cancellation secrets, hash-only server storage, idempotent submission, secure withdrawal, offline retry, startup/online retry, and bounded retry batches.
- Feedback Center now automatically submits reports when online and displays central delivery state; Share/Copy/JSON export remain fallback/backup options.
- Versioned the applied Supabase migrations and deployed Edge Function under `supabase/`.
- Added Feedback Central Inbox regression: 17/17 locally.

### Security / architecture

- No Supabase secret/service-role credential is present in the public client. Public database roles cannot read or mutate feedback tables.
- Supabase security advisor is clean after setup. Performance advisor findings were reduced to expected unused-index notices on the empty new database.
- Feedback remains entirely outside `GameState`, save schema, rewind, descendants, simulation RNG, and gameplay authorities.

### CI validation

- GitHub Actions Run #110 (`34773384580`) certified expanded source `9980d8c278cb3bb2306d73a07963bf172096fd1e`.
- Canonical preflight passed 4/4 with Feedback Central Inbox 17/17, Activity Feedback Reporting 20/20, Activity-specific Minigame 19/19, Core 82/82, AI Interaction Testbench 41/41, Integrated Long-Life 105/105, all established suites, and the 163-module production build.
- Certified artifact ID `10322692198`; Pages deployment succeeded.

## Player Feedback / Issue Reporting — CI Green Run #109 — 2026-09-13

### Added

- Added Settings → Help & Feedback with interface-specific/action-specific report classification across Life, People, Activities, Career, Assets & Money, Minigames, Progress & Life Saves, Settings, and Other.
- Added Technical issue, Experience issue, and Suggestion report kinds with focused subcategories and bounded free-text context.
- Added optional safe diagnostic capture containing deployed build/source identity, save schema, game seed/RNG position, age/year/generation, current career, bounded system counts, pending-event identity, relevant settings, and recent timeline IDs without exporting the complete save.
- Added a bounded device-local report queue outside `GameState`, plus Share, Copy, structured JSON inbox export, draft cancellation, and queued-report withdrawal.
- Added deterministic production `build-info.json` generation from the actual checked-out Git commit so reports can identify the expanded source used by the deployed bundle.
- Added `PROJECT_HANDOFF/PLAYER_FEEDBACK.md` and a current-state feedback queue snapshot so future Yuki reviews active supplied/exported reports before new work and does not dismiss player-facing defects merely because backend regressions are green.
- Added Activity Feedback Reporting regression: 20/20 locally.

### CI validation

- GitHub Actions Run #109 (`34771397516`) certified expanded source `d73bbfa6fdf8afb430f2604a09c9ac3053d60962`.
- Canonical preflight passed 4/4 with Activity Feedback Reporting 20/20, Activity-specific Minigame 19/19, Core 82/82, AI Interaction Testbench 41/41, Integrated Long-Life 105/105, the complete established wall, and the 162-module production build.
- Certified artifact ID `10321624066`; Pages deployment succeeded.

## Phase 6C — Personal Borrowing / Bankruptcy / Recovery candidate — 2026-09-12

- Built only from certified Run #103 / `7f1f58099fe5e8528dc8ec3c70c0ed340a2e8294`.
- Adds four data-driven personal-loan products through shared CreditSystem underwriting, centralized personal-loan bills/delinquency/cure, and guarded voluntary bankruptcy/recovery without creating a second debt ledger.
- Save schema remains 12; optional personal-liability provenance/lender metadata is normalized deterministically for legacy debt with no RNG use.
- Local TypeScript gates and the complete regression wall pass, including Personal Borrowing & Recovery 31/31 and Integrated Long-Life 105/105. Standalone production build passes at 155 modules. GitHub Actions remains certification authority.

## Post-6B3 Credit History Reactivity correction candidate — 2026-09-12

### Fixed

- Credit & Banking History now derives current/prior transaction lists fresh on every game-state render instead of memoizing against the mutable credit-transaction array reference. Payments, charges, fees, deposits, and other posted credit transactions can therefore appear immediately while the banking sheet remains open.
- Added regression protection in Payment & Asset Management proving the read-only History projection immediately reflects a newly posted in-place credit transaction.

### Baseline

- Built only on certified Run #102 expanded source `8b2a49fe76c5429cf55228a00a15b6103211a25b`, package `0.12.0`, save schema 12. Phase 6B3 itself is CI Green.
- This is a presentation-reactivity correction only: it adds no debt authority, no save fields, no RNG use, and no content definitions. Phase 6C remains gated until this correction is CI Green.

### Local validation

- Engine TypeScript and test TypeScript pass. The complete regression wall passes with Payment & Asset Management **81/81** (up from 79/79 through two reactivity checks), Core 82/82, Credit & Banking 74/74, Asset Financing 77/77, Asset Delinquency 82/82, Integrated Long-Life 105/105, and every established suite green.
- Standalone production build passes at 153 transformed modules. The local all-in-one preflight wrapper was interrupted by the host execution ceiling during its repeated Vite transform after both TypeScript gates and the complete wall had already passed; GitHub Actions remains the final integrated preflight authority.

## Phase 6B3 — Payments & Asset Management UX — CI Green Run #102 — 2026-09-12

### Added

- Added a centralized `PaymentSystem` projection/action layer for real credit-card minimums and secured vehicle/home financing obligations. CreditSystem and FinanceSystem remain the balance authorities; the UI no longer needs to invent bill math.
- Added **Credit & Banking → Bills & Payments** from Overview. It itemizes current/past-due obligations, shows Cash, total due, past due, and annual auto-pay status, supports Cash payment of the real bill, and exposes per-obligation auto-pay switches.
- Added persistent annual auto-pay preferences. New cards and new asset-financing contracts default ON; schema-11 saves migrate safely to ON so old saves preserve their established automatic-servicing behavior. Card auto-pay covers the required minimum only, never the whole balance.
- Added manual secured annual-bill payment with a paid-ahead marker so paying before Age Up cannot double-charge the same contractual year. Existing delinquent secured bills continue through the 6B2 cure authority.
- Added vehicle sale quotes and real vehicle selling, including selling costs, lender payoff, equity proceeds, underwater deficiency conversion to unsecured debt, durable history, and confirmation before mutation.
- Added `AssetSaleSheet` and `paymentAssetManagementRegression.ts` with 79 targeted checks across migration, projection purity, auto-pay on/off, card minimums, secured prepayment, delinquency cure, financed contract defaults, vehicle/home sale accounting, save round trips, and invariants.

### Changed

- Credit & Banking Overview replaces the duplicated historical block with the compact Bills & Payments entry; major derogatory history now lives under the existing History tab. Individual card Accounts still support extra/full revolving-balance payments.
- Assets → Property now contains both homes and vehicles with a compact **Browse | Owned** toggle. Browse covers home + vehicle markets; Owned shows homes + vehicles together with contextual financing status and asset actions. Vehicles are no longer hidden under More.
- Payment controls are centralized in Credit & Banking instead of being scattered across asset cards. The Money liabilities view remains an accounting/status view and points players to Bills & Payments.
- Save schema advances from 11 to **12** for durable auto-pay, credit-card past-due, and secured paid-ahead payment state. Migration is deterministic, RNG-neutral, and defaults old obligations to the prior automatic-payment behavior.

### CI validation

- Built from exact certified Run #101 expanded source `c498753acb67bbb0aa930e5f8bdb7b411b1e874c` and its certified Node dependency artifact.
- GitHub Actions Run #102 (`34707368374`) imported the overlay into expanded source `8b2a49fe76c5429cf55228a00a15b6103211a25b` and reproduced both TypeScript gates, Core 82/82, Credit & Banking 74/74, Asset Financing 77/77, Asset Delinquency 82/82, Payment & Asset Management 79/79, Integrated Long-Life 105/105, every established suite, and the 153-module production build.
- Canonical preflight reported **GREEN 4/4**, certified artifact `10302905490` was uploaded, and GitHub Pages deployment succeeded. The existing >700 kB main-chunk warning remains nonblocking.

## Phase 6B2 — Secured Delinquency & Collateral Consequences — CI Green Run #101 — 2026-09-12

### Added

- Added persistent, save-safe secured-loan delinquency state on existing `Loan` records: status, arrears, missed-payment count, and the age of the unresolved miss. Pre-6B2 schema-11 loans derive as current without mutation, so no save-schema bump is required.
- Added explicit player curing for delinquent car loans and mortgages. Assets → Money shows the collateral, past-due amount, next-Age-Up consequence, and a touch-friendly **Cure** action that uses Cash only.
- Added vehicle repossession for uncured financed cars and strengthened mortgage foreclosure to use the same loan/collateral/credit authorities. Missed secured payments create durable timeline warnings and existing CreditSystem derogatories; repossession creates a credit default and foreclosure preserves the established foreclosure history.
- Added `assetDelinquencyRegression.ts` with 82 targeted checks covering current servicing, missed-payment accounting, cure success/failure, cure payoff, car repossession, foreclosure, deficiencies/surplus recovery, secured-payment priority, voluntary underwater sales, net-worth accounting, and schema-11 round trips.

### Changed

- Annual finance no longer reduces a secured-loan balance when the year cannot actually fund that payment. The skipped payment becomes arrears, the contractual term is not falsely consumed, and the player gets until the next Age Up to cure it.
- Same-year secured shortfall allocation protects housing by allowing a vehicle payment to fail before a mortgage when one skipped payment is enough to close the cash gap. Deeper insolvency can make both obligations delinquent.
- Unrecovered collateral balances become ordinary unsecured deficiency debt instead of disappearing. Involuntary foreclosure equity first reconciles existing unsecured shortfall debt before any remainder returns as cash.
- Voluntarily selling an underwater financed home now preserves the unpaid deficiency as unsecured debt, closing the prior debt-erasure exploit.
- Financed home/vehicle cards expose outstanding financed balance and at-risk state directly on the owned asset.

### Candidate validation

- Local canonical preflight from the certified Run #100 source/dependency artifact passes **4/4**: engine TypeScript, test TypeScript, complete regression wall, and production build.
- Core remains 82/82; Credit & Banking 74/74; Asset Financing 77/77; new Asset Delinquency 82/82; Dynasty Transition 63/63; Family Topology 40/40; NPC Asset Ownership 82/82; Timeline Scaling 11/11; Action VFX 46/46; Integrated Long-Life 105/105; every established dedicated suite is green locally.
- Production build succeeds at 151 transformed modules. The existing >700 kB main-chunk warning remains nonblocking.
- GitHub Actions Run #101 reproduced Asset Delinquency 82/82, every established regression, both TypeScript gates, the 151-module production build, certified-baseline artifact creation, and Pages deployment. Expanded certified source is `c498753acb67bbb0aa930e5f8bdb7b411b1e874c`; Phase 6B2 is CI Green.

## Phase 6B1 — Asset Financing Foundation — CI Green Run #100 — 2026-09-12

### Added

- Added a reusable, data-driven `AssetFinancingSystem` plus six fictional vehicle/home lender programs. Asset underwriting consumes `CreditSystem.getCreditUnderwritingSnapshot()` for the existing derived credit profile, real income, installment/revolving payment burden, inquiries, and bankruptcy recovery instead of inventing a second score model.
- Added deterministic, read-only lender quotes for appropriate vehicles and homes with visible APR, term, down payment, amount financed, annual payment, monthly equivalent, finance charge, full-term total cost, projected payment burden, and human-readable approval/decline reasons.
- Added a mobile **Buy Outright | Finance** purchase sheet for property and vehicles. Browsing does not create an inquiry; signing re-underwrites current state and then records the approved financing inquiry.
- Added persistent `car` and `mortgage` liabilities using the existing `Loan` authority, including collateral `assetId` links, annual-finance servicing, net-worth accounting, estate debt treatment, schema-11 save persistence, and durable timeline/history context.
- Added `assetFinancingRegression.ts` with 77 targeted checks covering deterministic browsing, lender requirements, down-payment effects, stale-quote revalidation, preview→signed parity, shared application limits, cash-vs-credit separation, vehicle/home outright and finance paths, accounting identity, annual servicing, estates, saves, and CreditSystem authority reuse.

### Changed

- Replaced the legacy hard-coded home-mortgage approval math inside `PropertySystem` with the shared financing authority. Vehicle financing now uses that same authority; asset screens contain no independent creditworthiness calculation.
- Asset liabilities now show APR, authoritative annual payment, and remaining years. Credit & Banking history resolves asset-financing inquiries to their lender/program names.
- Outright vehicle purchases now create a durable asset timeline entry so a material life purchase is not invisible. Credit Available remains revolving borrowing capacity only and is never treated as purchase cash or wealth.

### CI validation

- GitHub Actions Run #100 reproduced both TypeScript gates, Core 82/82, Asset Financing 77/77, Credit & Banking 74/74, every established dedicated regression, Integrated Long-Life 105/105, and the production build.
- The canonical preflight reported GREEN 4/4, the certified baseline artifact was uploaded, and GitHub Pages deployed successfully.
- Expanded certified source is `819d223aa9a0d5f9109c705f16213c43ddcaeb31`; Phase 6B1 is CI Green.

## Phase 6A — Credit & Banking Foundation — CI Green Run #99 — 2026-09-12

### Added

- Added bounded schema-11 player credit state plus `CreditSystem` for revolving accounts, available credit, refundable secured deposits, statement/minimum/payment history, interest/fees, formal inquiries, derogatories, deterministic creditworthiness, account closure, bankruptcy discharge, and bounded history repair.
- Added six original fictional banking institutions/products spanning age-16 secured starter cards through established/premium unsecured offers. Browsing is read-only; formal applications are bounded and record understandable approval/decline reasons.
- Added Life-page **Cash** + **Credit Available** presentation and a mobile **Credit & Banking** hub with Overview, Accounts, Offers/contracts, and History. Contract review exposes line, APR, annual fee, late fee, deposit, and minimum-payment terms before acceptance.
- Added manual card payments, representative card purchases, secured-deposit refunds, current-year/recent transaction history, and durable timeline consequences for material credit events.
- Added `creditBankingRegression.ts`, now 74/74.

### Changed

- Net worth/wealth breakdown now treats secured deposits as represented assets and revolving balances as liabilities; Credit Available never counts as cash or wealth.
- Estate obligations include revolving debt while refundable secured deposits remain estate value. Existing insolvency/bankruptcy now discharges active cards through the credit authority and persists default/bankruptcy credit history.
- Descendant continuation initializes the newly controlled protagonist's player credit state without inventing an unsupported NPC consumer-credit history.
- Save schema advances from 10 to 11 with deterministic, RNG-neutral, idempotent migration.

### Predeployment validation

- Credit & Banking 74/74; Core 82/82; Dynasty Transition 63/63; Family Topology 40/40; NPC Asset Ownership 82/82; Timeline Scaling 11/11; Action VFX 46/46; Integrated Long-Life 105/105; every established dedicated regression remains green.
- Both TypeScript gates pass. Production build passes at 148 transformed modules; existing >700 kB main-chunk warning remains nonblocking.
- 80-year direct card-use benchmark completed in ~5 ms in the hosted workspace, retained 20 recent transactions after bounded pruning, serialized the full fixture at ~18 KB, and returned zero invariant errors.
- GitHub Actions Run #99 reproduced the Phase 6A regression wall and certified expanded source `6eb2b7876203d47dcc1ad5c48f1098bf359182cd`; Phase 6A is CI Green.

## Phase 5E — Dynasty Transition / End-of-Life Agency — CI Green Run #98 — 2026-09-12

### Added

- Added read-only `DynastyTransitionSystem` projection over the existing EstateSystem and NPC biography/asset authorities. The death UI no longer performs or mirrors inheritance math independently.
- Rebuilt the death flow into an intentional mobile sequence: completed-life review → estate outcome → successor selection → detailed successor inspection → explicit continuation confirmation.
- Successor inspection now surfaces existing education/career, partner/children, health/happiness, fame/reputation, debt, own net worth, own property/businesses, projected inheritance, inherited named assets, and protected-minor trust timing.
- Estate review now names forced-sale assets and explains whether each sale was caused by estate obligations or by fair division among heirs.
- Added durable post-handoff timeline entries for estate obligations/forced sales, inherited named assets/trusts, and the value distributed to other family heirs.
- Added `dynastyTransitionRegression.ts`, currently 63/63.

### Changed

- A descendant card no longer immediately switches protagonists. Selecting a child is read-only; a separate confirmation button performs the real `continueAsChild()` action.
- Protagonist-switch confirmation explicitly disables ordinary delta-derived action VFX so cash/stress/relationship differences between two different people are not misrepresented as an action consequence.
- Heir, successor, and forced-sale lists use 24-row progressive disclosure to keep extreme dynasty death screens bounded without deleting authoritative data.
- Added the cross-phase architecture rule that material protagonist-facing consequences must be visible/understandable through gameplay surfaces and, where meaningful agency exists, presented before commitment from the same authoritative system that applies the result.
- Save schema remains 10; no transition snapshot or second estate database was introduced.

### Predeployment validation

- Dynasty Transition: 63/63. Core 82/82; Estate Planning 46/46; Estate Administration 63/63; NPC Asset Ownership 82/82; Family Topology 40/40; Action VFX 46/46; Integrated Long-Life 105/105; every established dedicated regression remains green.
- Both TypeScript gates pass. Production build passes at 145 transformed modules; existing >700 kB main-chunk warning remains nonblocking.
- Twelve sequential reviewed handoffs with hundreds of background NPCs preserve 7,212 archived life-history entries, unique completed-life IDs, state invariants, and bounded linear historical-cast growth.
- GitHub Actions Run #98 reproduced canonical preflight 4/4, Dynasty Transition 63/63, every established regression, the 145-module production build, certified artifact creation, and Pages deployment on expanded source `5aa1c4338be4edc934b867f4e5a710d0e116aaa2`; Phase 5 is closed.

## Phase 5D — Broader Family Topology — CI Green Run #97 — 2026-09-11

### Added

- Added indexed `FamilyTopologySystem` derivation for aunt/uncle and cousin relationships plus reconciliation of the existing close-family taxonomy from authoritative parent/child/partner graph truth.
- Integrated expanded kinship into People/Threadspace labels and folders, generic family event targeting, delayed family-favor continuity, relevant special-career family targeting, save-load backfill, and descendant continuation.
- Added `familyTopologyRegression.ts`, now 40/40, including deterministic/idempotent derivation, no synthetic NPC creation, RNG/ID neutrality, extended-family simulation-tier bounds, event eligibility, generation handoff, migration/backfill, romantic-history preservation, UI labels, and a hundreds-relative scale fixture.

### Changed

- Extended kin stay background-tier unless individually meaningful; aunt/uncle/cousin births do not automatically become full-simulation branches or guaranteed player timeline entries.
- Save load now repairs state invariants before final family-topology synchronization so derived stepfamily/kinship uses repaired authoritative pointers.
- Threadspace person cards use the shared human-readable relationship label formatter (`aunt / uncle`, `niece / nephew`).
- Save schema remains 10; no new persisted family database was introduced.

### Predeployment validation

- Family Topology: 40/40. Core 82/82; Action VFX 46/46; Timeline Scaling 11/11; NPC Asset Ownership 82/82; Integrated Long-Life 105/105; every established dedicated regression remains green.
- Both TypeScript gates pass and production build passes at 144 transformed modules. Existing >700 kB main-chunk warning remains nonblocking.
- Explicit large-dynasty benchmark: 1,082 starting NPCs arranged as 180 aunts/uncles + 900 cousins synchronized in ~4.5 ms locally; six simulated years completed in ~362 ms, normal autonomy grew the cast to 1,182, no extended relative was forced full-tier, and validation produced zero errors.
- GitHub Actions Run #97 reproduced canonical preflight 4/4, Family Topology 40/40, every established regression, the 144-module production build, certified artifact creation, and Pages deployment on expanded source `8e5394d0488d1c760072590ffa5c06eadfdac9f6`.

## Post-Run95 playtest hotfix — CI Green Run #96 — 2026-09-11

- Fixed Life → Your Story failing to show Age Up timeline entries until navigation/refresh. Root cause was `Timeline` memoizing a bounded window by an array reference that Everthread intentionally mutates in place; the bounded window now recomputes on each render.
- Fixed Threadspace NPC interaction VFX disappearing at relationship score caps. Action VFX snapshots now record timeline length and derive semantic relationship gain/loss from only the new `relationshipDelta` entries created by the current action when before/after stored scores cannot move past 0/100.
- Added real capped positive/adverse `interactWithNpc()` regression coverage and same-reference timeline append coverage. Action VFX is now 46/46; Timeline Scaling is 11/11 locally.
- GitHub Actions Run #96 reproduced canonical preflight 4/4, Action VFX 46/46, Timeline Scaling 11/11, every established regression, the 142-module production build, certified artifact creation, and Pages deployment on expanded source `3b58f04827ddc88a33c61b3cdf0d50f1e7584161`.

## Phase 5C — Persistent NPC Asset Ownership — CI Green Run #95 — 2026-09-10

### Added

- Save schema v10 with lean persisted NPC property/business portfolios. Existing v9 aggregate NPC property migrates deterministically into stable explicit ownership without consuming the player RNG stream.
- Bounded NPC asset rules and a dedicated asset progression substream. Meaningful NPCs can own and modestly grow property/business interests; background-tier NPCs retain cheaper simulation, do not seed new explicit property at creation, and do not organically accumulate new portfolios.
- Explicit NPC estate settlement for retained property/business inheritance, adult/minor NPC heirs, player heirs, protected trusts, mortgage carryover, and idempotent source-estate clearing.
- Descendant continuation now converts the selected NPC's own property/business holdings into playable assets and separates mortgage debt from unsecured personal debt.
- People detail sheets now show NPC liquid wealth, property, businesses, debt, estimated net worth, and named holdings.
- Dedicated `npcAssetOwnershipRegression.ts` with 82/82 checks, including protected-trust caps/overflow reconciliation and a 600-background-NPC + 3,000-entry 12-year scale fixture.
- `timelineWindow.ts` plus a 10/10 Timeline Scaling regression: the authoritative timeline remains complete while the Life page initially renders the newest 120 entries and reveals older history in 120-entry increments.

### Changed

- `NpcLifeState.finance.propertyValue` is now a projection of explicit NPC property holdings instead of a second independent property-value authority. `npc.wealth` remains liquid wealth.
- NPC annual finance incorporates explicit business profit/loss and mortgage progression while keeping asset growth bounded and deterministic.
- Player estate settlement gives offscreen heirs retained property/businesses as real holdings instead of converting the full allocation into aggregate wealth. Minor NPC heirs retain those assets in trust until adulthood.
- NPC-parent inheritance can pass retained assets directly to the player; minor player inheritance remains protected until age 18 and is counted once when released.
- Adult NPC portfolios and minor NPC inheritance trusts share hard 6-property / 4-business caps. Overflow liquidates to equity/value rather than disappearing or growing the save without bound.
- NPC asset definition lookups now use precomputed maps and legacy property migration chooses the nearest definition in a linear scan instead of sorting a copied catalog for each migration.

### Predeployment validation

- Engine TypeScript and test TypeScript gates pass.
- NPC Asset Ownership: 82/82.
- Timeline Scaling: 10/10.
- Core 82/82; Estate Planning 46/46; Estate Administration 63/63; Action VFX 42/42; Integrated Long-Life 105/105; every established dedicated regression remains green in bounded local batches.
- Content audit remains unchanged and clean.
- Earlier 50-life family-policy bulk sanity: zero anomalies, zero forced terminal deaths, max NPC peak 443.
- Scale fixture: 600 starting background NPCs + 3,000 timeline entries advanced 12 years with full history preserved, portfolio caps respected, zero organic explicit background holdings, and clean state validation.
- Ad-hoc hosted-sandbox benchmark: 1,000 starting background NPCs + 5,000 timeline entries advanced 20 years in ~1.1 s; world grew to ~1,200 NPCs through ordinary autonomy with zero organic explicit background holdings and zero validation errors.
- Production build passes with 142 transformed modules; main chunk ~981.03 kB minified / 278.92 kB gzip. Existing chunk-size warning remains nonblocking.
- GitHub Actions Run #95 reproduced canonical preflight, certified artifact creation, and Pages deployment on expanded source `62e28aafb190f8b46d10b73fb6dd00985beb724d`; Phase 5C is CI Green.

## Universal derived action VFX candidate — 2026-09-10

### Changed

- Derived consequence VFX are now enabled by default for every gameplay button result that reaches the shared `App.onResult` authority. A real cash decrease therefore emits Money Loss automatically without each screen opting in with `derive:true`; stress, follower, and relationship deltas receive the same systemic treatment.
- `derive:false` remains an explicit escape hatch for exceptional presentation-only cases, but there are currently no production call sites using it.
- Generic special-career Path buttons no longer turn derivation off when a path has no primary domain icon, closing the remaining Politics, Military, Royalty, and Film Directing coverage hole while preserving primary icons for Acting, Music, Sports, Combat, Modeling, Motorsport, and Organized Crime.

### Validation

- Action VFX regression expanded from 38/38 to 42/42, including plain successful spending, failed-but-executed spending, primary-only requests with automatic derived consequences, and explicit opt-out behavior.
- Engine TypeScript and test TypeScript gates pass.
- Core 82/82; every established dedicated regression remains green; Integrated Long-Life 105/105.
- Production build passes with 138 transformed modules. The hosted sandbox cannot finish the monolithic preflight wrapper before its command ceiling, so the same underlying preflight stages were executed in bounded chunks without removing or weakening any suite. GitHub CI remains the independent final authority.

## Visual feedback asset integration — CI Green Run #93 — 2026-09-10

### Added

- Mavyy-supplied Everthread action-feedback artwork is now integrated as a reusable mobile VFX system. Successful acting, music, professional sports, combat sports, modeling, motorsport, organized-crime, chemistry, follower, relationship, and stress-reduction outcomes can emit their matching icon from the actual press location.
- Adverse outcomes can emit supplied stress-increase, money-loss, and relationship-loss artwork from the same press-origin particle layer. Multiple real side effects may share one bounded burst.
- A supplied cash icon now sits beside Current Cash on the Life screen, and the supplied DECEASED stamp overlays dead NPC nodes in People Threadspace without blocking node interaction.
- Dedicated Action VFX regression coverage verifies career-to-icon mapping, supplied asset paths, static icon paths, state-delta derivation, failed-but-executed adverse feedback, success-only primary feedback, deduplication, and chemistry-specific suppression of a redundant relationship-gain icon.

### Changed

- `App` now owns one presentation-only action-feedback controller. Pointer presses capture their viewport origin before engine execution; keyboard activation falls back to the button center. The layer never mutates game state, save data, action economy, or simulation RNG.
- Reduced-motion users receive a short stationary fade/scale rather than the upward confetti motion. Particle counts and lifetime are bounded for mobile performance.
- Supplied artwork is stored as transparent, cropped, mobile-sized runtime derivatives; the heavier action VFX set is lazy/runtime cached while only the small Life cash icon joins the PWA shell precache. Service-worker cache generation advances to `everthread-shell-v8`.
- Build Chemistry uses the supplied person-plus artwork as its explicit primary feedback and suppresses a duplicate heart-plus burst; follower gains reuse the same person-plus artwork.

### Predeployment validation

- Engine TypeScript and test TypeScript gates pass.
- Action VFX regression: 38/38.
- Core: 82/82; every established dedicated regression remained green, including Estate Planning 46/46, Estate Administration 63/63, AI Interaction Testbench 41/41, and Integrated Long-Life 105/105.
- GitHub Actions Run #93 reproduced canonical preflight 4/4 on Node 22.23.2/Linux x64, built 138 modules, published the supplied runtime assets, created the certified preflight baseline, and deployed Pages successfully.
- CI-Green source commit: `de8f9af6a0212a0d90acecf9008afa77b042ac42`.

## Phase 5B — 2026-09-10 — Estate Administration & Settlement

### Added

- Fictional country-sensitive estate administration profiles derived from Everthread's simplified gameplay fiscal context, with protected administration allowances, capped administration costs, levy allowances, and modest settlement-levy rates. These values are explicitly game balance rules, not real-world tax/legal guidance.
- Estate preview breakdown for gross estate, debts, administration, settlement levy, eligible heirs, forced-sale pressure, and the active fictional rule profile.
- Dedicated Phase 5 estate-administration regression with country-rule coverage, read-only/RNG-neutral preview checks, debt-before-levy math, named-bequest protection, investment-before-protected-bequest liquidation, trusts, descendant continuation, and five-generation no-income anti-duplication stress.

### Changed

- Estate obligations now flow through one settlement authority: unsecured debt, administration, and levy are paid before heir allocation. Unassigned indivisible assets may be sold first; liquid investments are used before a specifically named bequest must be sacrificed.
- Smaller estates receive a protected administration allowance so modest specific bequests are not sold solely to fund trivial settlement overhead.
- Descendant-continuation history records settlement administration/levy costs when present. Save schema remains 9 because the new rules are computed rather than persisted.

### Predeployment validation

- Existing Estate Planning: 46/46.
- New Estate Administration: 63/63.
- Family Continuity: 18/18.
- Core: 82/82; AI Interaction Testbench: 41/41; Integrated Long-Life: 105/105; all established dedicated suites passed locally.
- Mixed 100-life bulk sanity: zero anomalies / zero forced terminal deaths, max NPC peak 480.
- Family-biased 100-life bulk sanity: zero anomalies / zero forced terminal deaths, max NPC peak 474.
- GitHub Actions Run #92 reproduced canonical preflight 4/4, all estate and legacy suites, production build, certified preflight artifact creation, and Pages deployment. Phase 5B is CI Green at `926da2fa3c74bac021776d9f1b4825a7a3e39797`.

## 0.12.0 — 2026-09-05 — Full NPC Life Simulation

### Added

- Save schema v9 with persistent `NpcLifeState` biographies covering education, career history, household/finance state, health conditions, legal incidents/custody, public life, housing/moves, and simulation cadence. Existing v8 NPCs initialize deterministically without consuming the player RNG stream.
- Dedicated `NpcLifeSystem` ownership for autonomous NPC education, careers, finance, health, legal status, fame, households, family formation, and death. `RelationshipSystem` retains player↔NPC interactions and relationship milestones instead of accumulating unrelated autonomy logic.
- Autonomous NPC education/credentials, career history, job loss/promotion/retirement, household cash flow, debt servicing, bounded home ownership/appreciation, health histories, legal incidents/imprisonment/release, fame/followers/reputation/scandals, and household relocation.
- Blended-family formation with incoming stepchildren, reciprocal stepfamily links, autonomous adoption for stable low-fertility couples, and bounded family-planning pressure for close-family households.
- Direct adult-descendant handoff of real NPC biography state. Education, career, health, legal, fame, debt/property context, spouse/children, and institutional history survive when an established descendant becomes playable.
- NPC life summaries in People detail sheets, exposing education, career, housing, income, property/debt, health, public/legal history, custody, and household moves.
- Eight-generation dynasty stress coverage plus NPC population metrics in the simulation harness.
- O(1) deterministic Mulberry32 counter jumps. Seeded RNG creation no longer replays every previously consumed random number; regression coverage proves direct jumps match sequential consumption through large counters.
- Deterministic household relocation substreams so considering a move cannot reshuffle unrelated marriage, fertility, health, career, or legal outcomes. Partners and dependent children relocate together.
- Bounded relationship progression for important close-family NPCs so unlucky RNG cannot leave romantic relatives permanently single, dating, or engaged without resolution.
- In-game Reduced Motion now explicitly routes timing minigames to the non-motion sequence mechanic, matching the existing OS reduced-motion behavior.

### Changed

- Background acquaintances retain cheaper autonomy cadence while meaningful family/friend/enemy/romantic relationships automatically receive full simulation, preserving long-life performance without deleting history.
- Memories and hidden opinions influence long-term relationship drift and make emotionally significant persistent NPCs more likely to surface in targeted events.
- NPC-owned housing follows bounded housing-market movement instead of accidental deterministic depreciation; scheduled debt service is included in annual household cash flow before wealth growth.
- Autonomous relocation is household-scoped rather than person-scoped. Current player spouses cannot autonomously move away, and a guardian cannot silently relocate a dependent player without a future player-facing family decision.
- Partner/family progression remains probabilistic in normal years but gains bounded pressure against decades of accidental RNG limbo.
- Simulation reporting now includes average/max lifetime NPC cast so future social systems can be held to a population-growth budget.

### Validation

- Engine TypeScript check passes.
- Test/harness TypeScript check passes.
- 82/82 regression cases pass.
- Eight-generation continuation stress test passes with valid lineage/history and bounded cast growth.
- Neutral 1,000-life bulk population: zero anomalies, zero forced terminal deaths, average/max lifetime NPC cast 116.2 / 176, average lifetime inheritance 125,559.
- Mixed-policy 1,000-life bulk population: zero anomalies, zero forced terminal deaths, average/max lifetime NPC cast 116.3 / 176, average lifetime inheritance 123,442.
- Identical 250-life benchmark improved from roughly 30.0 seconds to 8.3 seconds after deterministic RNG jump optimization with unchanged meaningful aggregate outcomes.
- Dependency-backed React/Vite production build remains the GitHub Actions deployment gate.

## 0.11.0 — 2026-09-04 — Persistent Workplaces

### Added

- Save schema v8 with persisted workplace-specific Social World state and real active/historical part-time employment records. Existing v7 careers reconstruct compatible workplace worlds during migration.
- Persistent full-time workplace rosters with managers, coworkers, departments, team groups, workplace morale/culture/tension/reputation, bounded turnover, and senior-character direct reports.
- Workplace actions for collaboration, networking, manager feedback, and formal coworker concerns, all classified through the central action-economy ledger.
- Real part-time jobs with age requirements, hourly pay, hours/week, performance, small persistent workplace rosters, annual income/tax integration, and shared weekly hour capacity around school/full-time commitments.
- Target-aware work events for credit disputes, manager reviews, rumors, team feuds, after-hours connection, formal workplace claims, and bonus pools.
- Regression coverage for employer archival, workplace migration, action limits, part-time capacity/income, evolving coworker relationships, targeted work events, and generation-safe social-world rebuilding.

### Changed

- Promotions within one employer preserve its workplace world; changing employers, resigning, being fired/laid off, or retiring archives the old workplace without deleting former coworkers.
- Work affiliation is independent from `Relationship.type`, so coworkers remain in People → Work after becoming friends, enemies, or romantic connections.
- Standard-career annual performance now responds to workplace morale/reputation/tension and manager relationship; low performance can demote before termination, while eligible performance can produce bonuses.
- Layoffs are distinct from performance firing and respond to employer morale and broader business-demand conditions.
- Retirement closes both full-time and active part-time employment and archives the associated workplaces.
- Generational continuation clears the former protagonist's institutional worlds and reconstructs only the newly controlled descendant's relevant worlds, preventing social-world leakage across generations.
- Work events may treat active part-time employment as valid employment and bind exact affiliated NPC/world payloads.

### Validation

- Engine TypeScript check passes.
- Test/harness TypeScript check passes.
- 71/71 regression cases pass.
- Content audit: 691 events total, including 90 work/career events.
- Neutral 1,000-life bulk population: zero anomalies and zero forced terminal deaths.
- Mixed-policy 1,000-life bulk population: zero anomalies and zero forced terminal deaths.
- Long-process profiling reached 1,000 sequential lives with bounded memory and stable per-life runtime.
- Dependency-backed React/Vite production build remains the GitHub Actions deployment gate.

## 0.10.0 — 2026-09-04 — Persistent School Social Worlds

### Added

- Save schema v7 with a persisted generic `SocialWorld` layer for schools now and workplaces/organizations later. Existing v6 education history reconstructs compatible archived/current school contexts during migration.
- Country-profile school progression with varied stage start/transition ages and simplified minimum school-leaving ages while preserving the established primary/middle/secondary education record taxonomy.
- Persistent school rosters with classmates, teachers, coaches, and school leadership stored as ordinary NPCs with memories, relationship state, aging, careers, and later-life continuity.
- School clubs, teams, service groups, arts, academic organizations, social groups, and leadership paths tied to recurring roster NPCs.
- Persistent attendance, conduct, social standing, honors, disciplinary history, academic-shortcut consequences, and school volunteering.
- Admissions profiles that combine academics, intelligence, discipline, conduct, involvement, reputation, school standing, and honors; scholarships can cover different proportions of tuition.
- Target-aware school events for recurring classmates and school authorities. Event effects and memories bind to the same NPC shown in the event copy.
- Shared-world history in People sheets so former classmates remain identifiable by the institution/role through which the player knew them.
- Background NPC simulation tier for ordinary school acquaintances; meaningful friends, rivals, romantic relationships, and family automatically receive the full annual autonomy pass.
- Explicit simulation seed prefixes for independent population batches plus streaming simulation aggregation to avoid retaining complete result objects for every finished life.
- Regression coverage for school-world migration, country school profiles, persistent rosters, bounded group activity, conduct/attendance, admissions weighting, compulsory-school leaving rules, and school-friend romance age safety.

### Changed

- School affiliation is no longer encoded solely by `Relationship.type`. A former classmate can become a friend, enemy, partner, or spouse and still remain discoverable in People → School through persisted institutional membership.
- Childhood education transitions are profile-driven rather than one global 5→11→14→18 schedule.
- Compulsory school cannot be dropped before the profile's minimum leaving age; post-secondary programs remain voluntarily leaveable.
- Teen/adult relationship milestone validation now applies to existing school friends too, closing a path that could bypass the normal dating-age rules.
- School activity effort uses the centralized action ledger, preventing join/participation/academic-risk reroll spam.

### Validation

- Engine TypeScript check passes.
- Test/harness TypeScript check passes.
- 64/64 regression cases pass.
- 72 TS/TSX source files pass syntax transpilation in the dependency-limited workspace.
- Two distinct 500-life neutral batches (1,000 unique lives total): zero anomalies and zero forced terminal deaths.
- Two distinct 500-life mixed-policy batches (1,000 unique lives total): zero anomalies and zero forced terminal deaths.
- Additional final 500-life mixed-policy sanity batch after age-boundary fixes: zero anomalies and zero forced terminal deaths.
- Dependency-backed React/Vite production build remains the GitHub Actions deployment gate.

## 0.9.9 — 2026-09-04 — Life Saves & Dynamic Family Legacy

### Added

- Real multi-slot life saves backed by the existing IndexedDB/local fallback store. Independent new lives no longer overwrite `slot-1`.
- Account-level active-save tracking so Everthread reopens the last selected life and safely falls back to another surviving slot when needed.
- `Life Saves` tab with an expandable Ongoing Lives folder for switching between independent lives and deleting saved lineages, plus an account-level Past Lives folder aggregated from surviving saves.
- Dynamic Family Legacy showcase that ranks living and completed lives using a bounded legacy score across longevity, primary stats, logarithmic wealth, fame, family, career, and major milestones.
- Completed-life generation metadata for new deaths, with index-based generation inference for older saves.
- Regression coverage for collision-free slot allocation, earlier-generation legacy selection, and automatic best-life fallback when the featured save is removed.

### Changed

- The former `Past Lives` meta tab is now `Life Saves`.
- Creating a custom or random independent life allocates a separate save slot and preserves account-level settings.
- Switching saves flushes pending writes and saves the current life before loading the target slot.
- Imported JSON is installed as a new independent life save instead of silently overwriting an existing slot ID.
- Deleting the only remaining life save is blocked; create another life first so the runtime always retains one authoritative state.
- The Family Legacy card keeps its existing visual role but can feature any surviving generation, including an earlier completed generation when that life scores better than the current protagonist.

### Validation

- Engine TypeScript check passes.
- Test/harness TypeScript check passes.
- 57/57 regression cases pass.
- Neutral 1,000-life bulk run: median lifespan 81, median net worth 637,451, millionaire rate 40.5%, zero anomalies and zero forced terminal deaths.
- Mixed-policy 1,000-life bulk run: median lifespan 82, median net worth 840,742, millionaire rate 45.3%, zero anomalies and zero forced terminal deaths.
- Dependency-backed React/Vite production build remains the GitHub Actions deployment gate.

Everthread is pre-release. Versions below are development milestones, not public release promises.

## 0.9.8 — 2026-09-04 — Relationship Trees & First Playable Minigames

### Added

- Relationship folders in the People tab: Player Family, Relatives, Friends & Social, Romantic History, School, and Work.
- Mobile relationship-tree view rooted on the player, with persisted NPC parent/child/partner edges and direct fallback edges only when a folder member would otherwise be disconnected.
- Known connection details in NPC sheets so parent, child, and partner links are visible outside the tree.
- Reusable full-screen minigame overlay with timing, sequence-memory, grid-memory, and decision challenge mechanics.
- Interactive minigame integration for acting auditions, professional-sports attempts, combat bouts, motorsport races, and prison escape.
- Character-skill accessibility resolution for minigames and license tests when the minigame preference is disabled.
- Regression coverage for folder classification, non-invented NPC graph edges, extended-family tree linkage, minigame outcome direction, and seeded accessibility resolution.

### Changed

- People search remains global, while the default People surface now prioritizes relationship folders over one long flat list.
- Minigame scores are bounded modifiers to existing simulation formulas; character skill, circumstances, and seeded RNG still resolve final outcomes.
- Timing challenges fall back to sequence-memory play when the device reports a reduced-motion preference.
- Career-screen job/program derivation is recalculated on each engine render instead of being memoized against mutable `GameState` identity.

### Validation

- Engine TypeScript check passes.
- Test/harness TypeScript check passes.
- 55/55 regression cases pass.
- React/TSX source passes a shimmed TypeScript UI compile in the dependency-limited workspace; the dependency-backed Vite production build remains the GitHub Actions deployment gate.
- Neutral 1,000-life bulk run: median lifespan 81, median net worth 637,451, millionaire rate 40.5%, zero anomalies and zero forced terminal deaths.
- Mixed-policy 1,000-life bulk run: median lifespan 82, median net worth 840,742, millionaire rate 45.3%, zero anomalies and zero forced terminal deaths.

## 0.9.7 — 2026-09-04 — Childhood Eligibility & Dependent Finances

### Added

- Explicit age eligibility for investment trading, travel, structured wellness, pet adoption, and collectible-market purchases at both engine and mobile-UI layers.
- Childhood wellness unlocks by activity: walking at 3, running at 5, martial arts/meditation at 6, intentional diet activity at 10, and gym at 13.
- Regression coverage for newborn investment/travel blocking, age-staged wellness unlocks, dependent-minor finance, and guardian-supported shortfalls.

### Changed

- Investment buying and selling now require age 18. Pet adoption unlocks at age 5, and collectible-market purchases at age 12.
- Independent vacations now require age 18. Family trips become available at age 5, require a living parent/stepparent/grandparent while under 18, and draw the trip cost from the guardian's simulated household wealth rather than the child's personal cash.
- Dependent minors no longer pay ordinary baseline living, lifestyle, child, pet, property, vehicle, or debt-service costs from personal cash. Taxes still apply to actual taxable teen income.
- Negative cash while under 18 is normalized through tracked guardian support instead of being converted into an unsecured personal loan.
- Student or other explicit liabilities can still exist in state, but ordinary annual debt payments do not begin while the player is a dependent minor.

### Fixed

- Newborn characters could buy and sell securities.
- Newborn characters could initiate vacations and family trips.
- Newborns could use gym/running/walking/meditation/diet/martial-arts actions before any age eligibility existed.
- Newborns could also initiate pet adoption and collectible-market purchases if starting household cash happened to be high enough.
- A dependent child could reach adulthood already carrying ordinary personal insolvency debt because year-end shortfall handling treated minors like independent adults.

### Validation

- Engine TypeScript check passes.
- Test/harness TypeScript check passes.
- 51/51 regression cases pass.
- Neutral 1,000-life bulk run: median lifespan 81, median net worth 637,451, millionaire rate 40.5%, zero anomalies and zero forced terminal deaths.
- Mixed-policy 1,000-life bulk run: median lifespan 82, median net worth 840,742, millionaire rate 45.3%, zero anomalies and zero forced terminal deaths.

## 0.9.6 — 2026-09-04 — Action Economy & Exploit Hardening

### Added

- Central persisted action ledger with data-defined per-age limits and multi-year cooldowns. A single action can claim multiple limits atomically, such as both a yearly application budget and a one-attempt-per-listing rule.
- Save schema v6 with v5→v6 migration. Existing annual career/family action markers are preserved in the new ledger so updating a save cannot refresh already-used attempts.
- Read-only action-gate queries for React so mobile buttons can disable when their meaningful yearly opportunity has been spent, while the engine remains the authoritative enforcement layer.
- Anti-reroll regression coverage for job applications, wellness/stat grinding, NPC interaction grinding, publicity income, business launches/products, property renovation, collectible hunting, action-ledger migration, and failed-outcome engine notifications.

### Changed

- Job applications are limited to five serious attempts per age and one attempt per exact listing; a failed interview consumes the attempt instead of allowing infinite RNG retries.
- Freelance work, school effort, enrollment, wellness, treatment, rehab, risky habits, meeting people, NPC interactions, relationship milestones, fame posts/opportunities, travel, licenses, crime/prison actions, pet care, collectible hunting, business founding/product launches, and major special-career actions now use explicit yearly opportunity budgets or cooldowns.
- Time-intensive special-career actions now model annual opportunity cost: training, auditions, music releases/tours, pro-contract attempts, fights, campaigns, political moves, royal duties, modeling work, races, films, criminal-organization work, and specialized-organization decisions are bounded at the simulation layer.
- Major property renovations now have a two-age cooldown and improve condition without creating guaranteed immediate net-worth arbitrage.
- Business founding is limited to one company per age and each business can complete one major product launch per age.
- Collectible hunting is limited to four major acquisitions per age and one attempt per exact collectible definition.
- Relationship marriage/reconciliation milestone counters now live in `RelationshipSystem`, not the UI-facing engine wrapper, so headless/system callers cannot bypass them.
- Acting lessons now check adult affordability before consuming the yearly training opportunity; already-represented actors and already-committed sports paths reject duplicate setup actions.
- GameEngine now emits/autosaves failed outcomes when RNG, deterministic IDs, or the action ledger changed. A rejection, loss, failed audition, failed crime, or other consumed attempt therefore persists instead of silently becoming rerollable after a render/save boundary.
- React external-store subscriptions now use a private engine revision snapshot instead of mutable `GameState` object identity, so engine emissions reliably trigger UI updates even without an unrelated local React state change.
- Career, education, People, Activities, Assets, pet, business, collectible, and special-career mobile controls visually disable when the central engine policy says their opportunity is exhausted.

### Validation

- Engine TypeScript check passes.
- Test/harness TypeScript check passes.
- 47/47 regression cases pass.
- All 66 TypeScript/TSX source files pass a TypeScript syntax/transpile parse; the dependency-backed React/Vite build remains a GitHub Actions deployment gate.
- Neutral 1,000-life bulk run: median lifespan 81, median net worth 655,640, millionaire rate 40.7%, zero anomalies and zero forced terminal deaths.
- Mixed-policy 1,000-life bulk run: median lifespan 82, median net worth 823,294, millionaire rate 44.5%, zero anomalies and zero forced terminal deaths.

## 0.9.5 — 2026-09-04 — First Mobile Playtest Hardening

### Added

- Save schema v5 with migration support for family-planning state and targeted repair of the pre-0.9.5 runaway salary exploit.
- One-year pregnancy state for biological parenting; successful conception resolves into birth after the next Age Up rather than creating a child instantly.
- Compact mobile money formatting for million, billion, trillion and quadrillion-scale values.
- Regression coverage for senior-career experience gates, annual career-action limits, pregnancy timing, v4 exploit-save repair and extreme mobile money formatting.

### Changed

- Higher-level standard jobs now require actual relevant industry experience before they appear as qualified listings.
- A successful new hire prevents another job start in the same age.
- `Work harder` and `Ask for raise` are each annual-focus actions and cannot be spammed repeatedly within one age.
- Standard-career salary growth and raises respect a role-market ceiling instead of compounding without bound.
- Sibling first names avoid duplicates while unused regional names are available.
- PWA navigation uses network-first loading with cached offline fallback; service-worker registration explicitly checks for updates.

### Fixed

- Players can no longer become level-six executives at age 18–20 with no relevant work history simply by passing a difficult interview.
- Repeated same-year raise requests can no longer turn ordinary salaries into trillion/quadrillion-scale compensation.
- Repeated same-year `Work harder` actions can no longer instantly max performance/stress.
- Repeated family taps can no longer generate many independent births in the same year.
- Existing v4 saves that clearly match the runaway-compensation exploit are repaired on load: salary and impossible role level are normalized and the identifiable exploit-year net cash windfall is reverted. Existing children are never deleted by migration.
- Extreme money values no longer overflow the Life, Career and Assets mobile cards.

### Validation

- Engine TypeScript check passes.
- Test/harness TypeScript check passes.
- 37/37 regression cases pass.
- Neutral 1,000-life bulk run: median lifespan 81, median net worth 651,017, millionaire rate 40.7%, zero anomalies and zero forced terminal deaths.
- Mixed-policy 1,000-life bulk run: median lifespan 82, median net worth 819,767, millionaire rate 44.6%, zero anomalies and zero forced terminal deaths.

## 0.9.4 — 2026-09-04 — Estate Threads & Economic Calibration

### Added

- Multi-heir estate settlement with normalized living beneficiary shares, non-mortgage debt settlement, proportional investment division, deterministic retained-asset allocation, and fairness-driven liquidation of indivisible assets when necessary.
- Offscreen sibling inheritance accounting so NPC heirs receive their share instead of the controlled descendant inheriting every retained asset.
- Player inheritance from wealthy NPC parents, including lifetime inheritance and inheritance-count tracking.
- Continued-descendant preservation for established standard careers, spouses/partners, children and deeper derived family relationships such as grandparents and grandchildren.
- Wealth-source diagnostics for cash, property equity, investments, businesses, vehicles, collectibles and debt.
- Investment diagnostics for lifetime contributions, withdrawals, held cost basis and held market gain.
- Three-generation continuation regression and exact wealth-source reconciliation regression.

### Changed

- Fictional security long-run drifts and market-regime central tendency were reduced to fit Everthread's bounded relative economy. Volatility, bubbles and crashes remain intentionally meaningful.
- Annual finance processing now includes modest after-tax-income-scaled discretionary lifestyle spending for ordinary recurring consumption not represented by explicit purchases.
- Underwater property equity is reported as negative equity instead of being hidden at zero in balance diagnostics.
- A deceased player's NPC record now preserves its own parent links, allowing the next protagonist to derive grandparents after a generation handoff.

### Fixed

- Selected descendants no longer receive 100% of retained investments, properties, businesses and collectibles while siblings divide only cash.
- Wealthy NPC parents no longer skip the player when distributing inheritance simply because the player is not stored inside the NPC map.
- Adult descendants no longer lose an existing standard career when control passes to them.
- Generation handoffs no longer flatten deeper supported family relationships out of the playable relationship view.

### Validation

- Engine TypeScript check passes.
- Test/harness TypeScript check passes.
- 32/32 regression cases pass.
- Three sequential generation handoffs preserve lineage and pass state invariants in regression.
- Neutral 1,000-life bulk run: median lifespan 82, median net worth 686,454, millionaire rate 41.1%, zero anomalies and zero forced terminal deaths.
- Mixed-policy 1,000-life bulk run: median lifespan 82, median net worth 853,976, millionaire rate 45.6%, zero anomalies and zero forced terminal deaths.
- On the same neutral seeds, average held investment gain fell from roughly 1.54M before market calibration to roughly 257k after calibration; average lifetime inheritance is roughly 133k, confirming inheritance was not the primary wealth distortion.

## 0.9.3 — 2026-09-04 — Deterministic Replay & Balance Policies

### Added

- Save-persisted state-scoped runtime ID generation keyed by the life seed and a monotonic `idCounter`.
- Save schema v4 with explicit v3→v4 migration for deterministic ID state.
- Legacy rewind snapshots are migrated before restoration, including the new ID counter.
- Exact-history replay regression: two independent 50-year runs with the same seed/actions must serialize identically, including generated IDs and NPC/event history.
- Runtime-ID uniqueness regression across long generated lives.
- Six independent simulation decision policies: neutral, conservative, reckless, social, family-focused, and career-focused.
- Mixed-policy population simulation separate from life aspiration profiles such as academic, creative, athletic, entrepreneurial, and criminal.
- Wealth percentile reporting at p10/p25/p75/p90/p99.

### Changed

- Replaced all 71 wall-clock runtime ID creation sites in simulation systems with deterministic state-scoped IDs.
- Neutral simulation job selection no longer sorts primarily by maximum salary; career-focused policy retains deliberate salary optimization while conservative policy favors lower stress/risk.
- Investment, property, education, relationship, wellness, event-choice, and family behavior now vary by simulation policy.

### Validation

- Engine TypeScript check passes.
- Test/harness TypeScript check passes.
- 27/27 regression cases pass.
- Replay-safe 1,000-life bulk run completes with zero anomalies and identical aggregate results to the pre-ID migration baseline.
- Neutral 1,000-life run: median lifespan 83, median net worth 865,919, millionaire rate 46.6%, marriage rate 52.2%, zero anomalies.
- Mixed-policy 1,000-life run: median lifespan 82, median net worth 1,094,138, millionaire rate 52.6%, marriage rate 54.5%, zero anomalies.

## 0.9.2 — 2026-09-04 — Living World & Delayed Consequences

### Added

- Autonomous close-family NPC career selection using real job IDs, promotion/loss/retirement progression, wealth drift, linked partners, marriage/divorce/widowhood, bounded child generation, and inheritance to living children.
- Family-tree derivation for autonomous births, including niece/nephew and grandchild relationships where applicable.
- Bidirectional NPC-partner invariant checks and repair; player romantic partners are excluded from autonomous matchmaking.
- Delayed-event context payloads that can retain a specific NPC target and original decision age across future years.
- Persistent-target text templating for delayed consequences (`{NPC_NAME}`, `{NPC_FIRST}`, `{ORIGIN_AGE}`).
- Five first-class delayed-consequence chains: romantic secrecy, family financial favors, ignored health warnings, workplace shortcuts, and broken confidences.
- Four regression checks covering delayed target fidelity, cancellation when a required relationship disappears, origin-age context, and consequence-chain wiring.

### Changed

- Random/forced target-aware events can bind a persistent romantic, family, or friend NPC before the decision is shown, so prose and effects refer to the same person.
- Timeline entries generated by targeted events retain the affected NPC ID.
- Delayed relationship effects now explicitly resolve against the saved payload target rather than selecting another living relationship.

### Validation

- Engine TypeScript check passes.
- Test/harness TypeScript check passes.
- 24/24 regression cases pass.
- 1,000-life bulk run completed with zero detected structural anomalies and zero forced terminal-age deaths.
- Current audited content count: 679 event definitions, including 199 relationship-focused and 83 work/career events.

## 0.9.1 — 2026-09-03 — Verification & Simulation Hardening

### Added

- Deterministic regression suite with 18 core/integration checks.
- Headless multi-life simulation harness with full and bulk modes.
- 1,000-life bulk validation path and aggregate reporting for lifespan, wealth, education, career, marriage, children, crime, convictions, fame and death causes.
- Executable content audit.
- `DEVELOPMENT.md`, `CONTENT.md`, and `CHANGELOG.md` project continuity files.
- Economy-state fields for last cost/wage/housing index movement.
- Insolvency pressure handling: annual cash shortfalls become structured unsecured debt; sustained hardship can trigger foreclosure and bankruptcy.
- Mortgage affordability underwriting and a five-year post-bankruptcy mortgage restriction.

### Changed

- Event selection now uses category-indexed routine pools plus a small exact-probability rare-event pass instead of evaluating/rolling all 670 definitions every year.
- Economy indices now model bounded relative conditions instead of unbounded century-long nominal inflation.
- Existing standard-career salaries follow wage-index movement so long-held jobs do not become economically frozen.
- Achievement evaluation no longer runs redundantly twice on ordinary no-event age-ups; progress lookup and metric evaluation are cached per pass.
- Bulk simulations may suppress achievement/challenge evaluation and truncate timeline history for performance; full mode remains the correctness reference.

### Fixed

- Adult player dating generation can no longer create a minor potential partner.
- Biological-child action now validates the minimum parenting age of both participants.
- Duplicate active spouses are repaired by state invariants.
- Descendant continuation no longer pays retained asset value again as full liquid inheritance.
- Mortgages on retained inherited properties now remain in the descendant's liabilities.
- Descendant relationship reconstruction preserves parents, siblings, partners/spouses and children instead of flattening most surviving NPCs into friends.
- Annual business owner distributions are not credited a second time in finance processing.
- Death timeline ordering and legacy simulated-year double-counting issues identified in the foundation pass remain corrected.
- Foreclosure equity now offsets a cash shortfall exactly once and preserves any excess residual cash rather than double-consuming proceeds.

### Validation

- Engine TypeScript check passes.
- Test/harness TypeScript check passes.
- 18/18 regression cases pass.
- 1,000-life bulk run completed with zero detected state anomalies and no forced terminal-age deaths.

### Known follow-up

- Simulation policy over-optimizes investments and job selection, so its millionaire/career distributions are not yet neutral balance targets.
- Vehicle repossession, richer creditworthiness, and voluntary bankruptcy UI remain incomplete; engine-level shortfall debt, foreclosure, bankruptcy and mortgage underwriting now function.
- Exact replay is not yet guaranteed because generated object IDs still include wall-clock time.

## 0.9.0 — 2026-09-03 — Foundation Build

- Established Everthread: Life Unwritten branding and mobile application shell.
- Added authoritative `GameState`, seeded RNG, systems architecture, Age Up loop and timeline.
- Added character generation, relationships/family, education, standard careers, finances, health, crime/legal/prison, investments, businesses, property, pets, travel, fame and special-career foundations.
- Added death summaries, completed lives, legacy state and descendant continuation.
- Added IndexedDB persistence, settings persistence, save migration through schema version 3, JSON import/export, autosave and rewind-enabled snapshots.
- Added achievements/challenges, settings/past-life/sandbox sheets, mobile bottom navigation, event/death sheets, theme/accessibility controls and PWA scaffolding.
- Added large original content databases for events, careers, health, crimes, properties, pets, countries, achievements and challenges.

### Post-6C household finance / crisis UX correction candidate

- New lives now begin with $0 of personally owned cash while the generated two-parent household remains the source of ordinary childhood support.
- Ordinary living costs and debt service no longer attach to a household-supported player; age 18 now presents an explicit financial-independence decision before independent living costs begin. Purchasing a home establishes financial independence.
- Annual shortfalls still create transparent hardship debt for financially independent adults, but now immediately surface a Financial Pressure event with player-controlled response options. Existing due story events retain priority and defer the finance notice rather than being overwritten.
- Severe hardship no longer silently liquidates investments or auto-files bankruptcy. Bankruptcy remains an explicit player decision through the existing guarded bankruptcy authority.
- Legacy adult saves without the new support flag preserve prior independent-expense behavior. Save schema remains v12.
- Added 21 household-finance/crisis regression checks and updated insolvency regressions to protect player agency. Local engine/test TypeScript, full regression wall, and production build are green.
