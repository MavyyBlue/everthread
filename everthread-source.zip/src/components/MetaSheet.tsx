import { useEffect, useMemo, useRef, useState } from 'react';
import type { GameState } from '../types/game';
import { BottomSheet } from './BottomSheet';
import { SearchField } from './SearchField';
import { Avatar } from './Avatar';
import { SecretCodePad } from './SecretCodePad';
import { achievements, challenges } from '../data/achievements';
import { gameEngine } from '../stores/gameStore';
import { allocateSaveSlotId, deleteSave, exportSave, importSave, loadAllGames, loadGame, loadSettings, saveGame, setActiveSaveSlotId } from '../services/SaveSystem';
import { archivedLives, featuredLife } from '../systems/LifeSaveSystem';
import { netWorth } from '../systems/FinanceSystem';
import { formatMoney } from '../core/format';
import { buildSaveExportFilename } from '../core/exportFilename';
import { EVERTHREAD_DEFAULT_ACCENT, EVERTHREAD_FONT_OPTIONS, normalizeEverthreadFont } from '../core/visualIdentity';

export function MetaSheet({open,onClose,onNewLife,onLifeOpened}:{open:boolean;onClose:()=>void;onNewLife:()=>void;onLifeOpened:()=>void}){
  const state=gameEngine.getState();
  const[tab,setTab]=useState<'progress'|'lives'|'settings'|'debug'>('progress');
  const[q,setQ]=useState('');
  const fileRef=useRef<HTMLInputElement>(null);
  const[saveStates,setSaveStates]=useState<GameState[]>([]);
  const[livesBusy,setLivesBusy]=useState(false);
  const filteredAchievements=useMemo(()=>achievements.filter(a=>`${a.name} ${a.description} ${a.category}`.toLowerCase().includes(q.toLowerCase())),[q]);
  const filteredChallenges=useMemo(()=>challenges.filter(c=>`${c.title} ${c.description}`.toLowerCase().includes(q.toLowerCase())),[q]);
  const refreshLives=async()=>{setLivesBusy(true);try{await gameEngine.flushSaves();await saveGame(gameEngine.getState());setSaveStates(await loadAllGames());}finally{setLivesBusy(false);}};
  useEffect(()=>{if(open&&tab==='lives')void refreshLives();},[open,tab]);

  const download=()=>{
    const current=gameEngine.getState();
    const blob=new Blob([exportSave(current)],{type:'application/json'});
    const url=URL.createObjectURL(blob);
    const a=document.createElement('a');
    a.href=url;
    a.download=buildSaveExportFilename(current,new Date());
    a.click();
    URL.revokeObjectURL(url);
  };
  const upload=async(file?:File)=>{if(!file)return;try{const text=await file.text();const imported=importSave(text);imported.slotId=await allocateSaveSlotId();Object.assign(imported.settings,loadSettings());setActiveSaveSlotId(imported.slotId);gameEngine.replaceState(imported);await saveGame(imported);onLifeOpened();}catch(err){alert(err instanceof Error?err.message:'Could not import save.');}};
  const switchLife=async(slotId:string)=>{if(slotId===gameEngine.getState().slotId){onLifeOpened();return;}setLivesBusy(true);try{await gameEngine.flushSaves();await saveGame(gameEngine.getState());const target=await loadGame(slotId);if(!target)throw new Error('That life save could not be found.');Object.assign(target.settings,loadSettings());setActiveSaveSlotId(target.slotId);gameEngine.replaceState(target);onLifeOpened();}catch(err){alert(err instanceof Error?err.message:'Could not switch life saves.');}finally{setLivesBusy(false);}};
  const removeLife=async(slotId:string)=>{if(saveStates.length<=1){alert('Everthread needs at least one ongoing life save. Create another life before deleting this one.');return;}const target=saveStates.find(save=>save.slotId===slotId);if(!target)return;const name=`${target.character.firstName} ${target.character.lastName}`;if(!confirm(`Delete ${name}'s entire life save and lineage? This cannot be undone.`))return;setLivesBusy(true);try{await gameEngine.flushSaves();const deletingCurrent=slotId===gameEngine.getState().slotId;await deleteSave(slotId);if(deletingCurrent){const remaining=(await loadAllGames()).filter(save=>save.slotId!==slotId);const replacement=remaining[0];if(!replacement)throw new Error('No replacement life save is available.');Object.assign(replacement.settings,loadSettings());setActiveSaveSlotId(replacement.slotId);gameEngine.replaceState(replacement);onLifeOpened();return;}setSaveStates(await loadAllGames());}catch(err){alert(err instanceof Error?err.message:'Could not delete that life save.');}finally{setLivesBusy(false);}};

  const stored=saveStates.length?saveStates:[state];
  const best=featuredLife(stored);
  const past=archivedLives(saveStates);
  const currentSlot=state.slotId;

  return <BottomSheet open={open} title="Everthread" onClose={onClose} wide>
    <div className="segmented segmented--scroll"><button className={tab==='progress'?'active':''} onClick={()=>setTab('progress')}>Progress</button><button className={tab==='lives'?'active':''} onClick={()=>setTab('lives')}>Life Saves</button><button className={tab==='settings'?'active':''} onClick={()=>setTab('settings')}>Settings</button>{(state.flags.sandbox||state.flags.debugEnabled)&&<button className={tab==='debug'?'active':''} onClick={()=>setTab('debug')}>Sandbox</button>}</div>

    {tab==='progress'&&<>
      <SearchField value={q} onChange={setQ} placeholder="Search achievements & challenges"/>
      <section className="sheet-section"><div className="section-heading"><h3>Challenges</h3><span>{state.challenges.filter(c=>c.completed).length} complete</span></div><div className="progress-list">{filteredChallenges.map(c=>{const p=state.challenges.find(x=>x.id===c.id);return <article key={c.id} className={`progress-card ${p?.completed?'complete':''}`}><div><strong>{c.title}</strong><small>{c.description}</small><em>{c.difficulty} · reward: {c.reward}</em></div>{p?.completed?<b>✓</b>:p?.activated?<span>{Math.round((p.progress??0)*100)}%</span>:<button onClick={()=>gameEngine.activateChallenge(c.id)}>Start</button>}</article>})}</div></section>
      <section className="sheet-section"><div className="section-heading"><h3>Achievements</h3><span>{state.achievements.filter(a=>a.completed).length}/{achievements.length}</span></div><div className="progress-list">{filteredAchievements.map(a=>{const p=state.achievements.find(x=>x.id===a.id);return <article className={`progress-card ${p?.completed?'complete':''}`} key={a.id}><div><strong>{a.name}</strong><small>{a.description}</small><em>{a.category}</em></div><span>{p?.completed?'✓':`${Math.round((p?.progress??0)*100)}%`}</span></article>})}</div></section>
    </>}

    {tab==='lives'&&<div className="life-saves">
      <section className="legacy-card"><p className="eyebrow">Family legacy</p>{best?<><div className="legacy-feature-heading"><div><h2>Generation {best.generation}</h2><strong>{best.name}</strong><small>{best.completed?'Completed life':'Ongoing life'} · legacy score {best.score}</small></div><span className="legacy-crown" aria-hidden="true">◇</span></div><div className="finance-grid"><div><small>Years simulated</small><strong>{best.yearsSimulated}</strong></div><div><small>Peak family wealth</small><strong>{formatMoney(best.peakFamilyWealth)}</strong></div><div><small>Completed lives</small><strong>{best.completedLives}</strong></div><div><small>Legacy rewards</small><strong>{best.legacyRewards}</strong></div></div><p className="legacy-best-line">Best life · age {best.age} · {formatMoney(best.netWorth)} net worth · fame {Math.round(best.fame)}{best.career?` · ${best.career}`:''}</p></>:<p className="muted">No life saves are available yet.</p>}</section>
      <details className="life-save-folder" open><summary><span><strong>Ongoing Lives</strong><small>Independent resumable life saves</small></span><b>{saveStates.length}</b></summary><div className="save-folder-body">{livesBusy&&!saveStates.length?<p className="empty-card">Loading life saves…</p>:saveStates.map(save=>{const isCurrent=save.slotId===currentSlot;return <article className={`life-save-card ${isCurrent?'current':''}`} key={save.slotId}><div className="life-save-main"><Avatar character={save.character} size={46}/><div className="grow"><div className="life-save-name"><strong>{save.character.firstName} {save.character.lastName}</strong>{isCurrent&&<span>Current</span>}</div><small>{save.character.alive?`Age ${save.character.age}`:'Life ended · lineage can continue'} · Generation {save.legacy.generation}</small><small>{save.character.city} · {formatMoney(netWorth(save))} net worth</small></div></div><div className="life-save-actions"><button disabled={livesBusy} onClick={()=>void switchLife(save.slotId)}>{isCurrent?'Open':'Switch'}</button><button className="danger-soft" disabled={livesBusy||saveStates.length<=1} onClick={()=>void removeLife(save.slotId)}>Delete</button></div></article>})}{!livesBusy&&!saveStates.length&&<p className="empty-card">No stored life saves were found.</p>}<button className="full-button" onClick={onNewLife}>Create another life</button></div></details>
      <details className="life-save-folder"><summary><span><strong>Past Lives</strong><small>Completed lives inside surviving lineages</small></span><b>{past.length}</b></summary><div className="save-folder-body stack">{past.map(({slotId,lineageName,generation,life})=><details className="past-life" key={`${slotId}:${life.id}`}><summary><span><strong>{life.character.firstName} {life.character.lastName}</strong><small>Generation {generation} · age {life.ageAtDeath} · {life.career??'No primary career'}</small></span><b>{formatMoney(life.netWorth)}</b></summary><p>{life.epitaph}</p><p>Cause: {life.cause}</p><small>Stored in the {lineageName} life save.</small></details>)}{!past.length&&<p className="empty-card">No completed lives yet.</p>}</div></details>
    </div>}

    {tab==='settings'&&<Settings state={state} download={download} upload={()=>fileRef.current?.click()} onNewLife={onNewLife}/>}<input ref={fileRef} hidden type="file" accept="application/json,.json" onChange={e=>void upload(e.target.files?.[0])}/>
    {tab==='debug'&&<Debug state={state}/>} 
  </BottomSheet>;
}

function Settings({state,download,upload,onNewLife}:{state:GameState;download:()=>void;upload:()=>void;onNewLife:()=>void}){
  const set=(patch:Partial<GameState['settings']>)=>gameEngine.updateSettings(patch);
  const font=normalizeEverthreadFont(state.settings.fontFamily);
  const previewTextColor=state.settings.textColor??(state.settings.theme==='light'?'#17151e':'#f5f4fb');
  return <div className="settings-list">
    <section className="visual-settings-card"><div><p className="eyebrow">Everthread appearance</p><h3>Your colors, our design language</h3><small>The teal-and-gold framing stays recognizably Everthread while your preferred theme, jewel accent, typeface, and text color remain yours.</small></div></section>
    <label className="form-field"><span>Theme</span><select value={state.settings.theme} onChange={e=>set({theme:e.target.value as GameState['settings']['theme']})}><option value="system">System</option><option value="light">Light</option><option value="dark">Dark</option></select></label>
    <label className="form-field"><span>Accent / jewel color</span><div className="color-setting-row"><input type="color" value={state.settings.accent} onChange={e=>set({accent:e.target.value})}/><button type="button" onClick={()=>set({accent:EVERTHREAD_DEFAULT_ACCENT})}>Everthread teal</button></div></label>
    <label className="form-field"><span>Typeface</span><select value={font} onChange={e=>set({fontFamily:e.target.value as GameState['settings']['fontFamily']})}>{EVERTHREAD_FONT_OPTIONS.map(option=><option key={option.value} value={option.value}>{option.label}</option>)}</select></label>
    <label className="form-field"><span>Text color</span><div className="color-setting-row"><input type="color" value={previewTextColor} onChange={e=>set({textColor:e.target.value})}/><button type="button" className={!state.settings.textColor?'active':''} onClick={()=>set({textColor:null})}>{state.settings.textColor?'Use automatic':'Automatic'}</button></div><small>Automatic follows the selected light/dark appearance.</small></label>
    <label className="form-field"><span>Text size · {Math.round(state.settings.textScale*100)}%</span><input type="range" min="0.9" max="1.3" step="0.05" value={state.settings.textScale} onChange={e=>set({textScale:Number(e.target.value)})}/></label>
    {([['sound','Sound'],['haptics','Haptics'],['animations','Animations'],['minigames','Minigames'],['profanityFilter','Profanity filter'],['autoSave','Auto-save'],['highContrast','High contrast'],['reducedMotion','Reduced motion'],['notifications','Optional notifications']] as const).map(([key,label])=><label className="toggle-row" key={key}><span><strong>{label}</strong></span><input type="checkbox" checked={state.settings[key]} onChange={e=>set({[key]:e.target.checked})}/></label>)}
    <div className="sheet-section"><h3>Data</h3><div className="action-grid"><button onClick={download}>Export current life JSON</button><button onClick={upload}>Import as new life save</button><button onClick={onNewLife}>Create another life</button></div></div>
  </div>;
}

function Debug({state}:{state:GameState}){
  const[age,setAge]=useState(state.character.age);const[money,setMoney]=useState(state.finances.cash);const[codesOpen,setCodesOpen]=useState(false);
  return <div className="form-stack">
    <p className="warning-card">Sandbox tools deliberately mark this save as nonstandard. They are useful for testing systems and content.</p>
    <label className="form-field"><span>Age</span><input type="number" value={age} onChange={e=>setAge(Number(e.target.value))}/></label>
    <label className="form-field"><span>Cash</span><input type="number" value={money} onChange={e=>setMoney(Number(e.target.value))}/></label>
    <button onClick={()=>gameEngine.debugPatch({age,money})}>Apply values</button>
    <button onClick={()=>gameEngine.forceDeath()}>Force death</button>
    {state.flags.sandbox&&<section className="sheet-section"><h3>Secret Codes</h3><p className="muted">Some threads only appear when you know where to look.</p><button className="full-button" onClick={()=>setCodesOpen(open=>!open)} aria-expanded={codesOpen}>{codesOpen?'Close Number Pad':'Enter Secret Code'}</button>{codesOpen&&<SecretCodePad/>}</section>}
    <div className="code-card"><small>RNG seed</small><code>{state.seed}</code><small>RNG counter</small><code>{state.rngCounter}</code></div>
    {state.flags.rewindEnabled&&<><h3>Yearly snapshots</h3><div className="action-grid">{state.yearlySnapshots.slice(-10).reverse().map(s=><button key={s.age} onClick={()=>gameEngine.rewind(s.age)}>Age {s.age}</button>)}</div></>}
  </div>;
}
