"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.makeStateId = makeStateId;
function seedHash(seed) {
    let hash = 2166136261;
    for (let i = 0; i < seed.length; i++) {
        hash ^= seed.charCodeAt(i);
        hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(36);
}
function makeStateId(state, prefix = 'id') {
    state.idCounter = (Number.isFinite(state.idCounter) ? state.idCounter : 0) + 1;
    return `${prefix}-${seedHash(state.seed)}-${state.idCounter.toString(36)}`;
}
