"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.enforceStateInvariants = enforceStateInvariants;
exports.validateState = validateState;
const math_1 = require("./math");
function enforceStateInvariants(state) {
    state.character.age = Math.max(0, Math.floor(state.character.age));
    state.character.stats.health = (0, math_1.clamp)(state.character.stats.health);
    state.character.stats.happiness = (0, math_1.clamp)(state.character.stats.happiness);
    state.character.stats.intelligence = (0, math_1.clamp)(state.character.stats.intelligence);
    state.character.stats.appearance = (0, math_1.clamp)(state.character.stats.appearance);
    for (const [key, value] of Object.entries(state.character.secondary)) {
        if (key === 'karma')
            continue;
        state.character.secondary[key] = (0, math_1.clamp)(value);
    }
    state.finances.cash = Number.isFinite(state.finances.cash) ? state.finances.cash : 0;
    state.legal.sentenceRemaining = Math.max(0, state.legal.sentenceRemaining);
    state.fame.fame = (0, math_1.clamp)(state.fame.fame);
    state.fame.publicReputation = (0, math_1.clamp)(state.fame.publicReputation);
    const spouseRelations = state.relationships.filter(r => r.type === 'spouse' && !r.estranged);
    if (spouseRelations.length > 1) {
        for (const duplicate of spouseRelations.slice(1))
            duplicate.type = 'ex';
    }
    for (const rel of state.relationships) {
        rel.score = (0, math_1.clamp)(rel.score);
        rel.attraction = (0, math_1.clamp)(rel.attraction);
        rel.compatibility = (0, math_1.clamp)(rel.compatibility);
        if (!state.npcs[rel.npcId])
            rel.estranged = true;
    }
    for (const npc of Object.values(state.npcs)) {
        npc.age = Math.max(0, Math.floor(npc.age));
        npc.health = (0, math_1.clamp)(npc.health);
        npc.happiness = (0, math_1.clamp)(npc.happiness);
        npc.fertility = (0, math_1.clamp)(npc.fertility);
        npc.hiddenOpinion = (0, math_1.clamp)(npc.hiddenOpinion, -100, 100);
        if (!npc.alive) {
            npc.imprisoned = false;
            npc.partnerId = undefined;
        }
    }
    for (const npc of Object.values(state.npcs)) {
        if (!npc.partnerId)
            continue;
        const partner = state.npcs[npc.partnerId];
        if (!partner?.alive || partner.id === npc.id) {
            npc.partnerId = undefined;
            continue;
        }
        if (!partner.partnerId)
            partner.partnerId = npc.id;
        else if (partner.partnerId !== npc.id)
            npc.partnerId = undefined;
    }
    return state;
}
function validateState(state) {
    const errors = [];
    if (!state.character?.id)
        errors.push('Missing character id');
    if (state.character.age < 0)
        errors.push('Negative player age');
    if (state.saveVersion < 1)
        errors.push('Invalid save version');
    const spouses = state.relationships.filter(r => r.type === 'spouse' && !r.estranged);
    if (spouses.length > 1)
        errors.push('Multiple active spouses');
    if (state.relationships.some(r => !state.npcs[r.npcId]))
        errors.push('Relationship references missing NPC');
    if (state.legal.sentenceRemaining < 0)
        errors.push('Negative prison sentence');
    if (state.timeline.some(entry => entry.age < 0))
        errors.push('Timeline contains negative age');
    for (const npc of Object.values(state.npcs)) {
        if (!npc.partnerId)
            continue;
        if (npc.partnerId === npc.id)
            errors.push(`NPC ${npc.id} is partnered with self`);
        const partner = state.npcs[npc.partnerId];
        if (!partner)
            errors.push(`NPC ${npc.id} references missing partner ${npc.partnerId}`);
        else if (partner.partnerId !== npc.id)
            errors.push(`NPC partnership ${npc.id}/${partner.id} is asymmetric`);
    }
    return errors;
}
