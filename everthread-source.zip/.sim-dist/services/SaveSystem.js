"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SAVE_VERSION = void 0;
exports.migrateSave = migrateSave;
exports.saveGame = saveGame;
exports.loadGame = loadGame;
exports.listSaveSlots = listSaveSlots;
exports.deleteSave = deleteSave;
exports.exportSave = exportSave;
exports.importSave = importSave;
exports.saveSettings = saveSettings;
exports.loadSettings = loadSettings;
const invariants_1 = require("../core/invariants");
const DB_NAME = 'everthread';
const DB_VERSION = 1;
const STORE = 'saves';
exports.SAVE_VERSION = 4;
function canUseIndexedDb() { return typeof indexedDB !== 'undefined'; }
function openDb() { return new Promise((resolve, reject) => { const req = indexedDB.open(DB_NAME, DB_VERSION); req.onupgradeneeded = () => { const db = req.result; if (!db.objectStoreNames.contains(STORE))
    db.createObjectStore(STORE, { keyPath: 'slotId' }); }; req.onsuccess = () => resolve(req.result); req.onerror = () => reject(req.error); }); }
function stripRuntime(state) { const copy = structuredClone(state); delete copy.flags.ageUpLocked; return copy; }
function migrateSave(raw) {
    if (!raw || typeof raw !== 'object')
        throw new Error('Save is not an object');
    const state = structuredClone(raw);
    let version = Number(state.saveVersion ?? 1);
    if (version < 2) {
        state.travel = state.travel ?? { visitedCountries: [state.character.countryId], visitedCities: [state.character.city], emigrations: 0, licenses: { driving: false, boating: false, pilot: false } };
        version = 2;
    }
    if (version < 3) {
        state.inheritance = state.inheritance ?? { will: [], inheritBusinesses: true, inheritProperties: true };
        state.yearlySnapshots = state.yearlySnapshots ?? [];
        version = 3;
    }
    if (version < 4) {
        const entityCount = Object.keys(state.npcs ?? {}).length + (state.relationships?.length ?? 0) + (state.timeline?.length ?? 0) + (state.delayedEvents?.length ?? 0) + (state.businesses?.length ?? 0) + (state.pets?.length ?? 0) + (state.finances?.liabilities?.length ?? 0) + (state.health?.conditions?.length ?? 0);
        state.idCounter = 10000 + entityCount;
        version = 4;
    }
    if (version > exports.SAVE_VERSION)
        throw new Error(`Save version ${version} is newer than this build supports.`);
    state.saveVersion = exports.SAVE_VERSION;
    state.idCounter = Number.isFinite(state.idCounter) ? state.idCounter : 10000;
    state.achievements = state.achievements ?? [];
    state.challenges = state.challenges ?? [];
    state.completedLives = state.completedLives ?? [];
    state.specialCareers = state.specialCareers ?? {};
    state.flags = state.flags ?? { sandbox: false, rewindEnabled: false, debugEnabled: false };
    return (0, invariants_1.enforceStateInvariants)(state);
}
async function saveGame(state) { state.lastSavedAt = new Date().toISOString(); const clean = stripRuntime(state); if (!canUseIndexedDb()) {
    localStorage.setItem(`everthread-save-${state.slotId}`, JSON.stringify(clean));
    return;
} const db = await openDb(); await new Promise((resolve, reject) => { const tx = db.transaction(STORE, 'readwrite'); tx.objectStore(STORE).put(clean); tx.oncomplete = () => resolve(); tx.onerror = () => reject(tx.error); }); db.close(); }
async function loadGame(slotId = 'slot-1') { let raw; if (!canUseIndexedDb()) {
    const text = localStorage.getItem(`everthread-save-${slotId}`);
    raw = text ? JSON.parse(text) : undefined;
}
else {
    const db = await openDb();
    raw = await new Promise((resolve, reject) => { const tx = db.transaction(STORE, 'readonly'); const req = tx.objectStore(STORE).get(slotId); req.onsuccess = () => resolve(req.result); req.onerror = () => reject(req.error); });
    db.close();
} return raw ? migrateSave(raw) : undefined; }
async function listSaveSlots() { if (!canUseIndexedDb()) {
    return Object.keys(localStorage).filter(k => k.startsWith('everthread-save-')).map(k => JSON.parse(localStorage.getItem(k))).map(s => ({ slotId: s.slotId, name: `${s.character.firstName} ${s.character.lastName}`, age: s.character.age, alive: s.character.alive, lastSavedAt: s.lastSavedAt }));
} const db = await openDb(); const all = await new Promise((resolve, reject) => { const req = db.transaction(STORE, 'readonly').objectStore(STORE).getAll(); req.onsuccess = () => resolve(req.result); req.onerror = () => reject(req.error); }); db.close(); return all.map(s => ({ slotId: s.slotId, name: `${s.character.firstName} ${s.character.lastName}`, age: s.character.age, alive: s.character.alive, lastSavedAt: s.lastSavedAt })); }
async function deleteSave(slotId) { if (!canUseIndexedDb()) {
    localStorage.removeItem(`everthread-save-${slotId}`);
    return;
} const db = await openDb(); await new Promise((resolve, reject) => { const tx = db.transaction(STORE, 'readwrite'); tx.objectStore(STORE).delete(slotId); tx.oncomplete = () => resolve(); tx.onerror = () => reject(tx.error); }); db.close(); }
function exportSave(state) { return JSON.stringify(stripRuntime(state), null, 2); }
function importSave(json) { if (json.length > 15_000_000)
    throw new Error('Save file is too large.'); const raw = JSON.parse(json); const migrated = migrateSave(raw); const errors = (0, invariants_1.validateState)(migrated); if (errors.length)
    throw new Error(`Save validation failed: ${errors.join('; ')}`); return migrated; }
const SETTINGS_KEY = 'everthread-settings';
function saveSettings(settings) { if (typeof localStorage !== 'undefined')
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings)); }
function loadSettings() { if (typeof localStorage === 'undefined')
    return {}; try {
    return JSON.parse(localStorage.getItem(SETTINGS_KEY) ?? '{}');
}
catch {
    return {};
} }
