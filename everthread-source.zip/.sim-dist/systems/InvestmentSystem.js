"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.initializeMarket = initializeMarket;
exports.processMarketYear = processMarketYear;
exports.portfolioValue = portfolioValue;
exports.buySecurity = buySecurity;
exports.sellSecurity = sellSecurity;
const assets_1 = require("../data/assets");
const rng_1 = require("../core/rng");
const math_1 = require("../core/math");
function initializeMarket(state) {
    if (Object.keys(state.investments.prices).length)
        return;
    for (const security of assets_1.securities) {
        state.investments.prices[security.id] = security.basePrice;
        state.investments.history[security.id] = [security.basePrice];
    }
}
function processMarketYear(state) {
    initializeMarket(state);
    const rng = (0, rng_1.createRng)(`${state.seed}-market`, state.rngCounter);
    const regime = rng.weighted([
        { item: 'bull', weight: 28 }, { item: 'neutral', weight: 45 }, { item: 'bear', weight: 18 }, { item: 'bubble', weight: 6 }, { item: 'crash', weight: 3 }
    ]);
    state.investments.marketRegime = regime;
    const regimeDrift = { bull: .055, neutral: .005, bear: -.07, bubble: .15, crash: -.30 }[regime];
    for (const s of assets_1.securities) {
        const current = state.investments.prices[s.id] ?? s.basePrice;
        const noise = (rng.next() - .5) * 2 * s.volatility;
        const typeBias = s.type === 'bond' ? (regime === 'crash' ? .04 : 0) : s.type === 'speculative' ? (regime === 'bubble' ? .35 : regime === 'crash' ? -.25 : 0) : 0;
        const ret = Math.max(-.85, Math.min(1.8, s.drift + regimeDrift + noise + typeBias));
        const next = Math.max(.05, current * (1 + ret));
        state.investments.prices[s.id] = Math.round(next * 100) / 100;
        state.investments.history[s.id] = (state.investments.history[s.id] ?? []).slice(-39).concat(state.investments.prices[s.id]);
    }
    state.rngCounter = rng.counter();
}
function portfolioValue(state) { return state.investments.positions.reduce((sum, p) => sum + p.units * (state.investments.prices[p.securityId] ?? 0), 0); }
function buySecurity(state, securityId, amount) {
    initializeMarket(state);
    const sec = assets_1.securities.find(s => s.id === securityId);
    if (!sec)
        return { success: false, messages: [{ text: 'Unknown security.' }] };
    amount = Math.max(0, Math.min(state.finances.cash, amount));
    if (amount < 10)
        return { success: false, messages: [{ text: 'Choose an amount of at least 10 in game currency.' }] };
    const price = state.investments.prices[securityId];
    const units = amount / price;
    const existing = state.investments.positions.find(p => p.securityId === securityId);
    if (existing) {
        const oldValue = existing.units * existing.averageCost;
        existing.units += units;
        existing.averageCost = (oldValue + amount) / existing.units;
    }
    else
        state.investments.positions.push({ securityId, units, averageCost: price });
    state.finances.cash -= amount;
    state.flags.investmentContributions = Number(state.flags.investmentContributions ?? 0) + amount;
    return { success: true, messages: [{ text: `Invested ${amount.toLocaleString()} in ${sec.name} at ${price.toFixed(2)}.` }] };
}
function sellSecurity(state, securityId, units) {
    const pos = state.investments.positions.find(p => p.securityId === securityId);
    if (!pos)
        return { success: false, messages: [{ text: 'You do not own that security.' }] };
    const sellUnits = (0, math_1.clamp)(units ?? pos.units, 0, pos.units);
    const value = sellUnits * (state.investments.prices[securityId] ?? 0);
    pos.units -= sellUnits;
    state.finances.cash += value;
    state.flags.investmentWithdrawals = Number(state.flags.investmentWithdrawals ?? 0) + value;
    if (pos.units < .000001)
        state.investments.positions = state.investments.positions.filter(p => p !== pos);
    return { success: true, messages: [{ text: `Sold the position for ${Math.round(value).toLocaleString()}.` }] };
}
