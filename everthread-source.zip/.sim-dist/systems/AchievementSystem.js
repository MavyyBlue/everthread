"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.metricValue = metricValue;
exports.evaluateAchievements = evaluateAchievements;
exports.activateChallenge = activateChallenge;
exports.evaluateChallenges = evaluateChallenges;
const achievements_1 = require("../data/achievements");
const FinanceSystem_1 = require("./FinanceSystem");
const ids_1 = require("../core/ids");
const careerIndustries = (state) => new Set([...state.employment.history.map(h => h.jobId.split('_').slice(0, -1).join('_')), ...(state.employment.current ? [state.employment.current.jobId.split('_').slice(0, -1).join('_')] : [])]).size;
const r = (state, key, field) => { const value = state.specialCareers[key]?.[field]; return typeof value === 'number' ? value : value === true ? 1 : 0; };
function metricValue(state, metric) {
    const mappings = {
        age: () => state.character.age, health: () => state.character.stats.health, fitness: () => state.health.fitness, netWorth: () => (0, FinanceSystem_1.netWorth)(state), fame: () => state.fame.fame, publicReputation: () => state.fame.publicReputation, followers: () => state.fame.followers,
        careerCount: () => state.employment.history.length + (state.employment.current ? 1 : 0), careerYears: () => state.employment.history.reduce((s, h) => s + ((h.endAge ?? state.character.age) - h.startAge), 0) + (state.employment.current ? state.character.age - state.employment.current.startAge : 0), careerLevel: () => state.employment.current?.level ?? 0, retired: () => state.employment.retired ? 1 : 0, workPerformance: () => state.character.secondary.workPerformance,
        degrees: () => state.education.filter(e => e.graduated && ['university', 'community_college', 'graduate', 'professional', 'trade'].includes(e.stage)).length, scholarships: () => state.education.filter(e => e.scholarship && e.graduated).length, dropouts: () => state.education.filter(e => e.droppedOut).length, academicPerformance: () => state.character.secondary.academicPerformance,
        friendCount: () => state.relationships.filter(x => ['friend', 'best_friend'].includes(x.type) && state.npcs[x.npcId]?.alive).length, bestFriendCount: () => state.relationships.filter(x => x.type === 'best_friend').length, marriages: () => Number(state.flags.marriages ?? state.relationships.filter(x => x.type === 'spouse').length), reconciliations: () => Number(state.flags.reconciliations ?? 0), children: () => state.relationships.filter(x => x.type === 'child').length, grandchildren: () => state.relationships.filter(x => x.type === 'grandchild').length, generation: () => state.legacy.generation,
        crimes: () => state.legal.criminalRecord.length, convictions: () => state.legal.criminalRecord.filter(x => x.convicted).length, prisonYears: () => Number(state.flags.prisonYears ?? 0), escapes: () => state.flags.fugitive ? 1 : Number(state.flags.escapes ?? 0),
        properties: () => state.assets.properties.length, rentals: () => state.assets.properties.filter(p => p.rental).length, mansion: () => state.assets.properties.some(p => p.typeId.includes('mansion')) ? 1 : 0, island: () => state.assets.properties.some(p => p.typeId.includes('island')) ? 1 : 0, vehicles: () => state.assets.vehicles.length, vehiclesOwned: () => Number(state.flags.vehiclesOwned ?? state.assets.vehicles.length),
        businessesFounded: () => state.businesses.length, businessValuation: () => Math.max(0, ...state.businesses.map(b => b.valuation)), businessFailures: () => state.businesses.filter(b => b.bankrupt).length, investmentPositions: () => state.investments.positions.length, portfolioValue: () => state.investments.positions.reduce((s, p) => s + p.units * (state.investments.prices[p.securityId] ?? 0), 0),
        petsOwned: () => Number(state.flags.petsOwned ?? state.pets.length), livingPets: () => state.pets.filter(p => p.alive).length, destinations: () => state.travel.visitedCities.length, countriesVisited: () => state.travel.visitedCountries.length, emigrations: () => state.travel.emigrations,
        actingCredits: () => r(state, 'acting', 'credits'), leadRoles: () => r(state, 'acting', 'leadRoles'), actingAwards: () => r(state, 'acting', 'awards'), actingFame: () => r(state, 'acting', 'reputation'), songsReleased: () => r(state, 'music', 'songsReleased'), albumsReleased: () => r(state, 'music', 'albumsReleased'), musicAwards: () => r(state, 'music', 'awards'),
        proContracts: () => r(state, 'sports', 'pro'), championships: () => r(state, 'sports', 'titles'), fightWins: () => r(state, 'combat', 'wins'), combatTitles: () => r(state, 'combat', 'titles'), electionsWon: () => r(state, 'politics', 'electionsWon'), headOfGovernment: () => r(state, 'politics', 'office') >= 5 ? 1 : 0, nationalOffice: () => r(state, 'politics', 'office') >= 4 ? 1 : 0, militaryYears: () => r(state, 'military', 'years'), royalRank: () => r(state, 'royalty', 'rank'), royalRespect: () => r(state, 'royalty', 'respect'),
        modelJobs: () => r(state, 'modeling', 'jobs'), runwayCampaigns: () => r(state, 'modeling', 'runwayCampaigns'), filmsDirected: () => r(state, 'directing', 'filmsDirected'), boxOfficeBest: () => r(state, 'directing', 'boxOfficeBest'), racingSeasons: () => r(state, 'racing', 'seasons'), racingTitles: () => r(state, 'racing', 'titles'), museums: () => r(state, 'museum', 'active'), exhibits: () => r(state, 'museum', 'exhibits'), zoos: () => r(state, 'zoo', 'active'), casinos: () => r(state, 'casino', 'active'), agencies: () => r(state, 'secretAgency', 'active'), communes: () => r(state, 'commune', 'active'),
        collectibles: () => state.assets.collectibles.length, drivingLicense: () => state.travel.licenses.driving ? 1 : 0, boatLicense: () => state.travel.licenses.boating ? 1 : 0, pilotLicense: () => state.travel.licenses.pilot ? 1 : 0, scandals: () => state.fame.scandals.length, addictions: () => state.health.addictions.length, industriesWorked: () => careerIndustries(state),
        poorStart: () => state.character.familyWealthTier === 'poor' ? 1 : 0, propertiesEver: () => Number(state.flags.propertiesEver ?? state.assets.properties.length), bankruptcies: () => Number(state.flags.bankruptcies ?? 0), citiesLived: () => Number(state.flags.citiesLived ?? 1), lifeAchievements: () => state.achievements.filter(a => a.completed).length,
    };
    if (mappings[metric])
        return mappings[metric]();
    const flag = state.flags[metric];
    return typeof flag === 'number' ? flag : flag === true ? 1 : 0;
}
function evaluateAchievements(state) { if (state.flags.simulationBulk)
    return []; const unlocked = []; const progressById = new Map(state.achievements.map(progress => [progress.id, progress])); const metricCache = new Map(); for (const def of achievements_1.achievements) {
    const progress = progressById.get(def.id);
    if (!progress || progress.completed)
        continue;
    let value = metricCache.get(def.metric);
    if (value === undefined) {
        value = metricValue(state, def.metric);
        metricCache.set(def.metric, value);
    }
    progress.progress = Math.min(1, value / Math.max(1, def.target));
    if (value >= def.target) {
        progress.completed = true;
        progress.completedAge = state.character.age;
        unlocked.push(def.name);
        state.timeline.push({ id: (0, ids_1.makeStateId)(state, 'timeline'), year: state.currentYear, age: state.character.age, category: 'achievement', importance: 3, text: `Achievement unlocked: ${def.name}.`, achievementId: def.id });
    }
} return unlocked; }
function activateChallenge(state, challengeId) { const def = achievements_1.challenges.find(c => c.id === challengeId); if (!def)
    return false; if (!state.challenges.some(c => c.id === challengeId))
    state.challenges.push({ id: challengeId, completed: false, progress: 0, activated: true }); return true; }
function evaluateChallenges(state) { if (state.flags.simulationBulk)
    return; for (const p of state.challenges) {
    if (p.completed || !p.activated)
        continue;
    const def = achievements_1.challenges.find(c => c.id === p.id);
    if (!def)
        continue;
    const statuses = def.requirements.map(req => { const v = metricValue(state, req.metric); const pass = req.comparator === '==' ? v === req.target : req.comparator === '<=' ? v <= req.target : v >= req.target; const ratio = req.comparator === '<=' || req.comparator === '==' ? (pass ? 1 : 0) : Math.min(1, v / Math.max(1, req.target)); return { pass, ratio }; });
    p.progress = statuses.reduce((s, x) => s + x.ratio, 0) / statuses.length;
    if (statuses.every(x => x.pass)) {
        p.completed = true;
        state.timeline.push({ id: (0, ids_1.makeStateId)(state, 'timeline'), year: state.currentYear, age: state.character.age, category: 'achievement', importance: 3, text: `Challenge completed: ${def.title}. Reward: ${def.reward}.` });
        state.legacy.accountCollectibleIds.push(`reward-${def.id}`);
    }
} }
