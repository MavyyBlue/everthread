"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.travel = travel;
exports.emigrate = emigrate;
exports.takeLicenseTest = takeLicenseTest;
exports.randomDestination = randomDestination;
const countries_1 = require("../data/countries");
const rng_1 = require("../core/rng");
const math_1 = require("../core/math");
const ids_1 = require("../core/ids");
function travel(state, countryId, city, withFamily = false) { const country = countries_1.countryById[countryId]; if (!country)
    return { success: false, messages: [{ text: 'Destination not found.' }] }; const destination = city && country.cities.includes(city) ? city : country.cities[0]; const distancePremium = countryId === state.character.countryId ? 1 : 2.3; const cost = Math.round((700 + state.character.age * 8) * distancePremium * (withFamily ? 1.8 : 1)); if (state.finances.cash < cost)
    return { success: false, messages: [{ text: `This trip requires about ${cost.toLocaleString()} in game currency.` }] }; state.finances.cash -= cost; state.travel.visitedCountries = [...new Set([...state.travel.visitedCountries, countryId])]; state.travel.visitedCities = [...new Set([...state.travel.visitedCities, `${destination}, ${country.name}`])]; state.character.stats.happiness = (0, math_1.clamp)(state.character.stats.happiness + 6); state.character.secondary.stress = (0, math_1.clamp)(state.character.secondary.stress - 4); state.timeline.push({ id: (0, ids_1.makeStateId)(state, 'timeline'), year: state.currentYear, age: state.character.age, category: 'travel', importance: 2, text: `You traveled to ${destination}, ${country.name}${withFamily ? ' with family' : ''}.`, moneyDelta: -cost }); return { success: true, messages: [{ text: `Trip complete: ${destination}, ${country.name}.` }] }; }
function emigrate(state, countryId, city) { if (state.character.age < 18)
    return { success: false, messages: [{ text: 'You must be an adult to emigrate independently.' }] }; const country = countries_1.countryById[countryId]; if (!country)
    return { success: false, messages: [{ text: 'Country not found.' }] }; if (countryId === state.character.countryId)
    return { success: false, messages: [{ text: 'You already live in that country.' }] }; const convictions = state.legal.criminalRecord.filter(r => r.convicted).length; const eligibility = state.character.stats.intelligence * .25 + Math.min(30, state.finances.cash / 10000) + state.character.secondary.reputation * .2 - convictions * 15; if (eligibility < 30)
    return { success: false, messages: [{ text: 'Your current immigration eligibility is too low under the game’s simplified system.' }] }; const destination = city && country.cities.includes(city) ? city : country.cities[0]; state.character.countryId = countryId; state.character.city = destination; state.travel.emigrations += 1; state.travel.visitedCountries = [...new Set([...state.travel.visitedCountries, countryId])]; state.travel.visitedCities = [...new Set([...state.travel.visitedCities, `${destination}, ${country.name}`])]; state.timeline.push({ id: (0, ids_1.makeStateId)(state, 'timeline'), year: state.currentYear, age: state.character.age, category: 'travel', importance: 3, text: `You emigrated to ${destination}, ${country.name}.` }); return { success: true, messages: [{ text: `You now live in ${destination}. Salaries, taxes, education, and healthcare use ${country.name}'s game balance profile.` }] }; }
function takeLicenseTest(state, kind, score) { const minAge = { driving: 16, boating: 16, pilot: 18 }[kind]; if (state.character.age < minAge)
    return { success: false, messages: [{ text: `You must be at least ${minAge} for this license.` }] }; const rng = (0, rng_1.createRng)(`${state.seed}-${kind}-license`, state.rngCounter); const target = kind === 'pilot' ? 72 : kind === 'boating' ? 62 : 58; const effective = score + state.character.stats.intelligence * .12 + state.character.secondary.discipline * .08 + rng.int(-5, 5); const success = effective >= target; if (success) {
    state.travel.licenses[kind] = true;
    if (kind === 'driving')
        state.flags.drivingLicense = true;
    if (kind === 'boating')
        state.flags.boatLicense = true;
    if (kind === 'pilot')
        state.flags.pilotLicense = true;
} state.rngCounter = rng.counter(); return { success, messages: [{ text: success ? `You passed the ${kind} license test.` : `You did not pass the ${kind} license test this time.` }] }; }
function randomDestination(state) { const rng = (0, rng_1.createRng)(state.seed, state.rngCounter); return rng.pick(countries_1.countries); }
