"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deathProbability = deathProbability;
exports.checkDeath = checkDeath;
const rng_1 = require("../core/rng");
const math_1 = require("../core/math");
const ids_1 = require("../core/ids");
const FinanceSystem_1 = require("./FinanceSystem");
const illnesses_1 = require("../data/illnesses");
function deathProbability(state) {
    const age = state.character.age;
    const health = state.character.stats.health;
    const ageBase = age < 45 ? .00035 : age < 60 ? .0015 + (age - 45) * .00045 : age < 75 ? .009 + (age - 60) * .0015 : age < 90 ? .032 + (age - 75) * .004 : Math.min(.60, .10 + (age - 90) * .025);
    const healthFactor = health >= 75 ? .55 : health >= 50 ? 1 : health >= 25 ? 2.4 : 5.2;
    const illnessFactor = state.health.conditions.reduce((s, c) => s + (illnesses_1.illnessById[c.illnessId]?.mortalityFactor ?? 0) * (c.severity / 100), 0);
    const dangerous = (state.specialCareers.combat?.active ? 0.001 : 0) + (state.specialCareers.military?.active ? 0.0015 : 0) + (state.flags.fugitive ? 0.0025 : 0);
    return (0, math_1.clamp)((ageBase * healthFactor + illnessFactor + dangerous) * 100, 0, 82) / 100;
}
function determineCause(state, rng) {
    const severe = [...state.health.conditions].sort((a, b) => b.severity - a.severity)[0];
    if (severe && severe.severity > 58 && rng.chance(.62))
        return `complications related to ${severe.name}`;
    if (state.character.age >= 82 && rng.chance(.7))
        return 'old age';
    if (state.flags.fugitive && rng.chance(.35))
        return 'an incident while living as a fugitive';
    if (state.specialCareers.combat?.active && rng.chance(.18))
        return 'complications from accumulated sports injuries';
    const causes = ['a sudden illness', 'an unexpected accident', 'natural causes', 'a brief final illness'];
    return rng.pick(causes);
}
function epitaph(state, cause) {
    const nw = (0, FinanceSystem_1.netWorth)(state);
    const children = state.relationships.filter(r => r.type === 'child').length;
    const career = state.employment.current?.title ?? state.employment.history.at(-1)?.title;
    const options = [
        `${state.character.firstName} kept turning pages until the book finally closed.`,
        `${state.character.firstName} left behind ${children ? `${children} child${children === 1 ? '' : 'ren'}, ` : ''}${nw > 1000000 ? 'a formidable estate, ' : ''}and enough stories to argue about for years.`,
        `${state.character.firstName}${career ? `, once a ${career},` : ''} discovered that no life goes exactly to plan—and made a life of it anyway.`,
        `${state.character.firstName}'s final chapter ended with ${cause}. The footnotes are considerably stranger.`,
    ];
    return options[Math.abs(state.rngCounter) % options.length];
}
function checkDeath(state, force = false) {
    if (!state.character.alive)
        return true;
    const rng = (0, rng_1.createRng)(`${state.seed}-death`, state.rngCounter);
    const chance = deathProbability(state);
    if (!force && !rng.chance(chance)) {
        state.rngCounter = rng.counter();
        return false;
    }
    const cause = determineCause(state, rng);
    state.character.alive = false;
    state.character.causeOfDeath = cause;
    const value = (0, FinanceSystem_1.netWorth)(state);
    const children = state.relationships.filter(r => r.type === 'child').length;
    const spouseRel = state.relationships.find(r => r.type === 'spouse');
    const spouse = spouseRel ? state.npcs[spouseRel.npcId] : undefined;
    state.timeline.push({ id: (0, ids_1.makeStateId)(state, 'timeline'), year: state.currentYear, age: state.character.age, category: 'death', importance: 3, text: `You died at age ${state.character.age} from ${cause}.` });
    const milestones = state.timeline.filter(t => t.importance === 3).slice(-12).map(t => t.text);
    const life = { id: (0, ids_1.makeStateId)(state, 'life'), character: structuredClone(state.character), ageAtDeath: state.character.age, cause, netWorth: value, career: state.employment.current?.title ?? state.employment.history.at(-1)?.title, spouse: spouse ? `${spouse.firstName} ${spouse.lastName}` : undefined, children, fame: state.fame.fame, milestones, epitaph: epitaph(state, cause), timeline: structuredClone(state.timeline) };
    state.completedLives.push(life);
    state.legacy.completedLifeIds.push(life.id);
    state.rngCounter = rng.counter();
    return true;
}
