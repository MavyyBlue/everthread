"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ageUp = ageUp;
exports.finalizeAgeUp = finalizeAgeUp;
exports.rewindToAge = rewindToAge;
const invariants_1 = require("../core/invariants");
const ids_1 = require("../core/ids");
const SaveSystem_1 = require("../services/SaveSystem");
const EconomySystem_1 = require("./EconomySystem");
const HealthSystem_1 = require("./HealthSystem");
const RelationshipSystem_1 = require("./RelationshipSystem");
const EducationSystem_1 = require("./EducationSystem");
const CareerSystem_1 = require("./CareerSystem");
const InvestmentSystem_1 = require("./InvestmentSystem");
const BusinessSystem_1 = require("./BusinessSystem");
const PropertySystem_1 = require("./PropertySystem");
const PetSystem_1 = require("./PetSystem");
const FameSystem_1 = require("./FameSystem");
const CrimeSystem_1 = require("./CrimeSystem");
const SpecialCareerSystem_1 = require("./SpecialCareerSystem");
const FinanceSystem_1 = require("./FinanceSystem");
const EventSystem_1 = require("./EventSystem");
const AchievementSystem_1 = require("./AchievementSystem");
const DeathSystem_1 = require("./DeathSystem");
function snapshotForRewind(state) { if (!state.flags.rewindEnabled)
    return; const clone = structuredClone(state); clone.yearlySnapshots = []; const encoded = JSON.stringify(clone); state.yearlySnapshots.push({ age: state.character.age, state: encoded }); state.yearlySnapshots = state.yearlySnapshots.slice(-35); }
function ageUp(state) {
    if (!state.character.alive)
        return { success: false, messages: [{ text: 'This life has ended. Continue as a descendant or begin a new life.' }] };
    if (state.pendingEvent)
        return { success: false, messages: [{ text: 'Resolve the current event before aging again.' }] };
    if (state.flags.ageUpLocked)
        return { success: false, messages: [{ text: 'Aging is already being processed.' }] };
    state.flags.ageUpLocked = true;
    snapshotForRewind(state);
    try {
        state.character.age += 1;
        state.currentYear += 1;
        // World and economy state first; systems below consume the new-year indices.
        (0, EconomySystem_1.processEconomyYear)(state);
        (0, HealthSystem_1.processHealthYear)(state);
        (0, RelationshipSystem_1.ageNpcs)(state);
        (0, EducationSystem_1.processEducationYear)(state);
        (0, CareerSystem_1.processCareerYear)(state);
        (0, InvestmentSystem_1.processMarketYear)(state);
        (0, BusinessSystem_1.processBusinessesYear)(state);
        (0, PropertySystem_1.processPropertiesYear)(state);
        (0, PetSystem_1.processPetsYear)(state);
        (0, FameSystem_1.processFameYear)(state);
        (0, CrimeSystem_1.processLegalYear)(state);
        (0, SpecialCareerSystem_1.processSpecialCareersYear)(state);
        (0, FinanceSystem_1.processAnnualFinance)(state);
        if (state.legal.imprisoned)
            state.flags.prisonYears = Number(state.flags.prisonYears ?? 0) + 1;
        state.legacy.totalYearsSimulated += 1;
        state.timeline.push({ id: (0, ids_1.makeStateId)(state, 'timeline'), year: state.currentYear, age: state.character.age, category: 'random', importance: 1, text: `Age ${state.character.age} began.` });
        state.flags.pendingDeathCheck = true;
        const pending = (0, EventSystem_1.triggerRandomEvent)(state);
        (0, invariants_1.enforceStateInvariants)(state);
        if (!pending) {
            finalizeAgeUp(state);
        }
        return { success: true, messages: [{ text: `You are now ${state.character.age}.` }], events: pending ? [pending] : undefined, stateChanges: ['age', 'year', 'annualSystems'] };
    }
    finally {
        state.flags.ageUpLocked = false;
    }
}
function finalizeAgeUp(state) {
    if (!state.flags.pendingDeathCheck)
        return false;
    delete state.flags.pendingDeathCheck;
    const died = (0, DeathSystem_1.checkDeath)(state);
    (0, AchievementSystem_1.evaluateAchievements)(state);
    (0, AchievementSystem_1.evaluateChallenges)(state);
    (0, invariants_1.enforceStateInvariants)(state);
    return died;
}
function rewindToAge(state, age) { if (!state.flags.rewindEnabled)
    return { success: false, messages: [{ text: 'Rewind is disabled for this save.' }] }; const snap = [...state.yearlySnapshots].reverse().find(s => s.age === age); if (!snap)
    return { success: false, messages: [{ text: 'No yearly snapshot is available for that age.' }] }; const restored = (0, SaveSystem_1.migrateSave)(JSON.parse(snap.state)); const preservedSnapshots = state.yearlySnapshots.filter(s => s.age <= age); for (const key of Object.keys(state))
    delete state[key]; Object.assign(state, restored); state.yearlySnapshots = preservedSnapshots; state.flags.rewinds = Number(state.flags.rewinds ?? 0) + 1; return { success: true, messages: [{ text: `Rewound to age ${age}. This save remains marked as rewind-enabled.` }] }; }
