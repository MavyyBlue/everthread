"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.auditContent = auditContent;
exports.formatContentAudit = formatContentAudit;
const events_1 = require("../data/events");
const jobs_1 = require("../data/jobs");
const education_1 = require("../data/education");
const illnesses_1 = require("../data/illnesses");
const crimes_1 = require("../data/crimes");
const achievements_1 = require("../data/achievements");
const countries_1 = require("../data/countries");
const assets_1 = require("../data/assets");
function auditContent() {
    const eventCategories = {};
    for (const event of events_1.lifeEvents)
        eventCategories[event.category] = (eventCategories[event.category] ?? 0) + 1;
    const ladderRoots = new Set(jobs_1.jobs.map(job => job.id.replace(/_\d+$/, '')));
    return {
        events: events_1.lifeEvents.length, eventCategories, jobs: jobs_1.jobs.length, careerLadders: ladderRoots.size, educationPrograms: education_1.educationPrograms.length, illnesses: illnesses_1.illnesses.length,
        relationshipEvents: (eventCategories.friends ?? 0) + (eventCategories.family ?? 0) + (eventCategories.romance ?? 0) + (eventCategories.relationships ?? 0), careerEvents: eventCategories.work ?? 0,
        crimes: crimes_1.crimes.length, achievements: achievements_1.achievements.length, challenges: achievements_1.challenges.length, properties: assets_1.propertyDefinitions.length, pets: assets_1.petVariants.length,
        vehicles: assets_1.vehicleDefinitions.length + assets_1.luxuryVehicleDefinitions.length, securities: assets_1.securities.length, businessIndustries: assets_1.businessIndustries.length,
        businessProducts: assets_1.businessIndustries.reduce((sum, industry) => sum + industry.productNames.length, 0), collectibles: assets_1.collectibleDefinitions.length, countries: countries_1.countries.length,
        regionalNamePools: 7, firstNamesPerPool: 20, lastNamesPerPool: 20,
    };
}
function formatContentAudit(audit) {
    const lines = [
        `Events: ${audit.events}`,
        `Event categories: ${Object.entries(audit.eventCategories).sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k}=${v}`).join(', ')}`,
        `Career positions: ${audit.jobs} across ${audit.careerLadders} six-step ladders`,
        `Education programs: ${audit.educationPrograms}`,
        `Illness/health definitions: ${audit.illnesses}`,
        `Relationship-focused events: ${audit.relationshipEvents}`,
        `Career/work events: ${audit.careerEvents}`,
        `Crimes: ${audit.crimes}`,
        `Achievements: ${audit.achievements}`,
        `Challenges: ${audit.challenges}`,
        `Properties: ${audit.properties}`,
        `Pets: ${audit.pets}`,
        `Vehicles/boats/aircraft: ${audit.vehicles}`,
        `Fictional securities: ${audit.securities}`,
        `Business industries/products: ${audit.businessIndustries}/${audit.businessProducts}`,
        `Collectibles: ${audit.collectibles}`,
        `Countries: ${audit.countries}`,
        `Regional name pools: ${audit.regionalNamePools}; ${audit.firstNamesPerPool} first + ${audit.lastNamesPerPool} last names each`,
    ];
    return lines.join('\n');
}
