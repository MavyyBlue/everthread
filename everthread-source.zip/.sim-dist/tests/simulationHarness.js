"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.simulateLife = simulateLife;
exports.runSimulation = runSimulation;
exports.formatSimulationReport = formatSimulationReport;
const rng_1 = require("../core/rng");
const invariants_1 = require("../core/invariants");
const CharacterSystem_1 = require("../systems/CharacterSystem");
const AgingSystem_1 = require("../systems/AgingSystem");
const EventSystem_1 = require("../systems/EventSystem");
const EducationSystem_1 = require("../systems/EducationSystem");
const CareerSystem_1 = require("../systems/CareerSystem");
const RelationshipSystem_1 = require("../systems/RelationshipSystem");
const CrimeSystem_1 = require("../systems/CrimeSystem");
const HealthSystem_1 = require("../systems/HealthSystem");
const InvestmentSystem_1 = require("../systems/InvestmentSystem");
const PropertySystem_1 = require("../systems/PropertySystem");
const BusinessSystem_1 = require("../systems/BusinessSystem");
const FinanceSystem_1 = require("../systems/FinanceSystem");
const DeathSystem_1 = require("../systems/DeathSystem");
const assets_1 = require("../data/assets");
const jobs_1 = require("../data/jobs");
const Special = __importStar(require("../systems/SpecialCareerSystem"));
function bump(target, key) { target[key] = (target[key] ?? 0) + 1; }
function median(values) { if (!values.length)
    return 0; const sorted = [...values].sort((a, b) => a - b); const mid = Math.floor(sorted.length / 2); return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2; }
function percentile(values, p) { if (!values.length)
    return 0; const sorted = [...values].sort((a, b) => a - b); const index = (sorted.length - 1) * p; const low = Math.floor(index), high = Math.ceil(index); if (low === high)
    return sorted[low]; const weight = index - low; return sorted[low] * (1 - weight) + sorted[high] * weight; }
function activeSchool(state) { return state.education.some(record => !record.graduated && !record.droppedOut && !record.endAge); }
function chooseProfile(seed) {
    const rng = (0, rng_1.createRng)(`${seed}-profile`);
    return rng.weighted([
        { item: 'ordinary', weight: 45 }, { item: 'academic', weight: 18 }, { item: 'entrepreneur', weight: 10 },
        { item: 'creative', weight: 10 }, { item: 'athletic', weight: 9 }, { item: 'criminal', weight: 8 },
    ]);
}
function choosePolicy(seed, requested = 'mixed') {
    if (requested !== 'mixed')
        return requested;
    const rng = (0, rng_1.createRng)(`${seed}-policy`);
    return rng.weighted([
        { item: 'neutral', weight: 35 }, { item: 'conservative', weight: 15 }, { item: 'reckless', weight: 12 },
        { item: 'social', weight: 12 }, { item: 'family', weight: 14 }, { item: 'career', weight: 12 },
    ]);
}
function desiredChildren(seed, profile, policy) {
    const rng = (0, rng_1.createRng)(`${seed}-family-target-${policy}`);
    let base = profile === 'entrepreneur' ? rng.int(0, 2) : profile === 'criminal' ? rng.int(0, 2) : rng.int(0, 3);
    if (policy === 'family')
        base = Math.min(4, base + 1);
    if (policy === 'career')
        base = Math.min(base, 1);
    if (policy === 'reckless' && rng.chance(.25))
        base = Math.min(4, base + 1);
    return base;
}
function resolveEventAutomatically(state, profile, policy) {
    if (!state.pendingEvent)
        return;
    const choices = state.pendingEvent.choices;
    if (!choices.length) {
        state.pendingEvent = undefined;
        (0, AgingSystem_1.finalizeAgeUp)(state);
        return;
    }
    const rng = (0, rng_1.createRng)(`${state.seed}-sim-event-${state.character.age}-${state.pendingEvent.eventId}`);
    let choice = choices[0];
    if (policy === 'reckless' || profile === 'criminal' && policy !== 'conservative')
        choice = choices.at(-1) ?? choice;
    else if (policy === 'conservative' || policy === 'family')
        choice = choices[0];
    else if (policy === 'career' && choices.length > 1)
        choice = choices[Math.min(1, choices.length - 1)];
    else
        choice = rng.pick(choices);
    (0, EventSystem_1.resolvePendingEvent)(state, choice.id);
    (0, AgingSystem_1.finalizeAgeUp)(state);
}
function pursueEducation(state, profile, policy) {
    const age = state.character.age;
    if (activeSchool(state)) {
        const shouldStudy = profile === 'academic' || profile === 'ordinary' && age >= 14 || (0, rng_1.createRng)(`${state.seed}-study-${age}`).chance(.32);
        if (shouldStudy)
            (0, EducationSystem_1.studyHarder)(state);
        return;
    }
    if (age < 17 || age > 32)
        return;
    const postSecondary = state.education.filter(r => r.programId);
    const hasPostSecondary = postSecondary.length > 0;
    const hasDegree = postSecondary.some(r => r.graduated);
    const rng = (0, rng_1.createRng)(`${state.seed}-college-${age}`);
    let wantsCollege = profile === 'academic' ? 1 : profile === 'criminal' ? .18 : profile === 'athletic' ? .55 : profile === 'creative' ? .48 : profile === 'entrepreneur' ? .42 : .52;
    if (policy === 'career')
        wantsCollege = Math.min(1, wantsCollege + .18);
    if (policy === 'conservative')
        wantsCollege = Math.min(1, wantsCollege + .08);
    if (policy === 'reckless')
        wantsCollege = Math.max(.08, wantsCollege - .18);
    if (hasPostSecondary && !hasDegree)
        return;
    if (profile !== 'academic' && hasPostSecondary)
        return;
    if (profile === 'academic' && postSecondary.length >= 2)
        return;
    if (!rng.chance(typeof wantsCollege === 'number' ? wantsCollege : .5))
        return;
    const programs = (0, EducationSystem_1.availablePrograms)(state).filter(program => {
        const advanced = ['graduate', 'professional'].includes(program.kind);
        if (!hasPostSecondary)
            return !advanced;
        return profile === 'academic' && hasDegree && advanced;
    });
    if (!programs.length)
        return;
    const preferred = programs.filter(program => {
        if (profile === 'academic')
            return ['science', 'computer_science', 'engineering', 'mathematics', 'physics', 'medical_school', 'law_school', 'graduate_school'].some(tag => program.id.includes(tag));
        if (profile === 'creative')
            return ['art', 'music', 'communications', 'english'].some(tag => program.id.includes(tag));
        if (profile === 'entrepreneur')
            return ['business', 'finance', 'economics', 'computer_science'].some(tag => program.id.includes(tag));
        if (profile === 'athletic')
            return ['business', 'education', 'psychology'].some(tag => program.id.includes(tag));
        return true;
    });
    const pool = preferred.length ? preferred : programs;
    for (const program of rng.shuffle(pool).slice(0, 8))
        if ((0, EducationSystem_1.enrollProgram)(state, program.id).success)
            break;
}
function pursueCareer(state, profile, policy) {
    if (state.character.age < 16 || state.legal.imprisoned)
        return;
    const rng = (0, rng_1.createRng)(`${state.seed}-career-policy-${state.character.age}`);
    if (!state.employment.current && !activeSchool(state)) {
        const options = (0, CareerSystem_1.availableJobs)(state);
        const entry = options.filter(job => job.experienceRequirement === 0 || job.id.endsWith('_1'));
        const pool = entry.length ? entry : options;
        if (pool.length) {
            let candidates = rng.shuffle(pool);
            if (policy === 'career')
                candidates = [...pool].sort((a, b) => b.salaryRange[1] - a.salaryRange[1]);
            else if (policy === 'conservative')
                candidates = [...pool].sort((a, b) => (a.stress + a.healthRisk) - (b.stress + b.healthRisk) || b.salaryRange[0] - a.salaryRange[0]);
            else if (profile === 'creative') {
                const creative = pool.filter(job => job.famePotential >= 20);
                if (creative.length)
                    candidates = rng.shuffle(creative);
            }
            for (const job of candidates.slice(0, Math.min(policy === 'career' ? 6 : 10, candidates.length)))
                if ((0, CareerSystem_1.applyForJob)(state, job.id).success)
                    break;
        }
        if (!state.employment.current && rng.chance(.45))
            (0, CareerSystem_1.takeFreelanceGig)(state, profile === 'creative' ? 'design' : profile === 'academic' ? 'programming' : 'writing');
    }
    else if (state.employment.current && rng.chance(policy === 'career' ? .68 : policy === 'reckless' ? .18 : profile === 'academic' ? .52 : .32))
        (0, CareerSystem_1.workHarder)(state);
}
function pursueRelationships(state, profile, policy) {
    const age = state.character.age;
    if (age < 16 || age > 55)
        return;
    const rng = (0, rng_1.createRng)(`${state.seed}-relationships-policy-${age}`);
    const romantic = state.relationships.find(r => ['partner', 'fiance', 'spouse'].includes(r.type) && state.npcs[r.npcId]?.alive);
    const relationshipMultiplier = policy === 'social' ? 1.7 : policy === 'family' ? 1.55 : policy === 'career' ? .55 : policy === 'reckless' ? 1.2 : policy === 'conservative' ? .9 : 1;
    if (!romantic && rng.chance(Math.min(.8, (age < 35 ? .14 : .06) * relationshipMultiplier))) {
        const met = (0, RelationshipSystem_1.meetPotentialPartner)(state);
        if (met.success) {
            const candidate = [...state.relationships].reverse().find(r => r.type === 'friend' && state.npcs[r.npcId]?.alive);
            if (candidate) {
                (0, RelationshipSystem_1.interactWithNpc)(state, candidate.npcId, 'spend_time');
                if (candidate.score >= 45)
                    (0, RelationshipSystem_1.changeRelationshipType)(state, candidate.npcId, 'ask_out');
            }
        }
        return;
    }
    if (!romantic)
        return;
    if (romantic.score < 72 && rng.chance(Math.min(.9, .62 * relationshipMultiplier)))
        (0, RelationshipSystem_1.interactWithNpc)(state, romantic.npcId, 'spend_time');
    if (romantic.type === 'partner' && romantic.yearsKnown >= 2 && romantic.score >= 62 && age >= 20 && rng.chance(Math.min(.5, .15 * relationshipMultiplier)))
        (0, RelationshipSystem_1.changeRelationshipType)(state, romantic.npcId, 'propose');
    if (romantic.type === 'fiance' && rng.chance(Math.min(.75, .4 * relationshipMultiplier))) {
        const married = (0, RelationshipSystem_1.changeRelationshipType)(state, romantic.npcId, 'marry');
        if (married.success)
            state.flags.marriages = Number(state.flags.marriages ?? 0) + 1;
    }
    const target = desiredChildren(state.seed, profile, policy);
    const children = state.relationships.filter(r => r.type === 'child').length;
    if (['partner', 'fiance', 'spouse'].includes(romantic.type) && children < target && age >= 22 && age <= 42 && rng.chance(Math.min(.6, .24 * (policy === 'family' ? 1.7 : policy === 'career' ? .55 : 1))))
        (0, RelationshipSystem_1.haveChild)(state, romantic.npcId, false);
}
function pursueWealth(state, profile, policy) {
    if (state.character.age < 18 || state.legal.imprisoned)
        return;
    const age = state.character.age;
    const rng = (0, rng_1.createRng)(`${state.seed}-wealth-policy-${age}`);
    const investChance = policy === 'reckless' ? .24 : policy === 'conservative' ? .18 : policy === 'career' ? .18 : policy === 'family' ? .10 : policy === 'social' ? .08 : .12;
    if (state.finances.cash > 45000 && age >= 22 && rng.chance(investChance)) {
        const safe = assets_1.securities.filter(sec => sec.type === 'fund' || sec.type === 'bond');
        const aggressive = assets_1.securities.filter(sec => sec.type === 'stock' || sec.type === 'fund');
        const speculative = assets_1.securities.filter(sec => sec.type === 'speculative' || sec.type === 'stock');
        const pool = policy === 'reckless' ? (speculative.length ? speculative : aggressive) : policy === 'conservative' ? safe : profile === 'entrepreneur' ? aggressive : [...safe, ...assets_1.securities.filter(sec => sec.type === 'stock')];
        const fraction = policy === 'reckless' ? .2 : policy === 'conservative' ? .1 : .12;
        const amount = Math.min(state.finances.cash * fraction, 18000 + age * 550);
        (0, InvestmentSystem_1.buySecurity)(state, rng.pick(pool).id, amount);
    }
    const propertyChance = policy === 'conservative' ? .12 : policy === 'family' ? .11 : policy === 'reckless' ? .05 : .08;
    if (state.assets.properties.length === 0 && state.finances.cash > 30000 && age >= 25 && rng.chance(propertyChance)) {
        const affordable = assets_1.propertyDefinitions.filter(p => p.basePrice * state.economy.housingIndex * .2 < state.finances.cash * .75).sort((a, b) => a.basePrice - b.basePrice);
        if (affordable.length) {
            const result = (0, PropertySystem_1.buyProperty)(state, affordable[Math.min(affordable.length - 1, rng.int(0, Math.min(4, affordable.length - 1)))].id, true);
            if (result.success && profile === 'entrepreneur' && rng.chance(policy === 'career' ? .55 : .35))
                (0, PropertySystem_1.rentOutProperty)(state, state.assets.properties.at(-1).id);
        }
    }
    if (profile === 'entrepreneur' && state.businesses.length < 2) {
        const possible = assets_1.businessIndustries.filter(b => b.startupCapital < state.finances.cash * .65);
        if (possible.length && rng.chance(policy === 'career' ? .24 : policy === 'reckless' ? .22 : .14)) {
            const industry = rng.pick(possible);
            (0, BusinessSystem_1.startBusiness)(state, industry.id, `${state.character.lastName} ${industry.name}`);
        }
    }
    if (profile === 'entrepreneur')
        for (const business of state.businesses)
            if (!business.bankrupt && rng.chance(policy === 'career' ? .22 : .14))
                (0, BusinessSystem_1.addBusinessProduct)(state, business.id);
}
function pursueSpecialPath(state, profile, policy) {
    const age = state.character.age;
    const rng = (0, rng_1.createRng)(`${state.seed}-special-policy-${age}`);
    if (profile === 'creative' && age >= 13) {
        if (state.character.talents.music >= state.character.talents.acting) {
            Special.practiceMusic(state, 'vocals');
            if (age >= 16 && rng.chance(.36))
                Special.releaseMusic(state, rng.chance(.25) ? 'album' : 'song');
            if (rng.chance(.05))
                Special.tourMusic(state);
        }
        else {
            Special.takeActingLesson(state);
            if (age >= 18 && rng.chance(.4))
                Special.auditionActing(state);
            if (rng.chance(.12))
                Special.hireActingAgent(state);
        }
    }
    if (profile === 'athletic' && age >= 13 && age <= 42) {
        if (!state.specialCareers.sports?.active)
            Special.joinSportsPath(state, rng.pick(['basketball', 'soccer', 'tennis', 'baseball', 'hockey']));
        Special.trainSport(state);
        if (age >= 18 && rng.chance(.25))
            Special.pursueProSports(state);
    }
    if (profile === 'criminal' && age >= 14) {
        if (state.legal.imprisoned) {
            (0, CrimeSystem_1.prisonActivity)(state, rng.chance(.75) ? 'behave' : 'exercise');
            return;
        }
        if (state.flags.pendingCharge) {
            (0, CrimeSystem_1.resolveLegalCase)(state, state.finances.cash > 35000 ? 'elite' : state.finances.cash > 7500 ? 'experienced' : state.finances.cash > 900 ? 'budget' : 'public', rng.chance(.35) ? 'plead' : 'contest');
            return;
        }
        if (rng.chance(policy === 'reckless' ? .42 : policy === 'conservative' ? .16 : .28)) {
            const options = (0, CrimeSystem_1.availableCrimes)(state).filter(crime => crime.id !== 'escape_attempt' && crime.id !== 'prison_contraband');
            if (options.length)
                (0, CrimeSystem_1.commitCrime)(state, rng.pick(options).id);
            if (state.flags.pendingCharge)
                (0, CrimeSystem_1.resolveLegalCase)(state, state.finances.cash > 7500 ? 'experienced' : 'public', rng.chance(.45) ? 'plead' : 'contest');
        }
    }
}
function wellness(state, policy) {
    if (state.character.age < 10)
        return;
    const rng = (0, rng_1.createRng)(`${state.seed}-wellness-policy-${state.character.age}`);
    const routineChance = policy === 'conservative' ? .32 : policy === 'reckless' ? .1 : .2;
    if (state.character.stats.health < 60 || state.character.secondary.stress > 70 || rng.chance(routineChance))
        (0, HealthSystem_1.performWellnessActivity)(state, state.character.secondary.stress > 70 ? 'meditation' : rng.pick(['walking', 'running', 'gym']));
}
function annualPolicy(state, profile, policy) {
    if (!state.character.alive)
        return;
    if (state.pendingEvent)
        resolveEventAutomatically(state, profile, policy);
    pursueEducation(state, profile, policy);
    pursueCareer(state, profile, policy);
    pursueRelationships(state, profile, policy);
    pursueWealth(state, profile, policy);
    pursueSpecialPath(state, profile, policy);
    wellness(state, policy);
}
function highestEducation(state) {
    const completed = state.education.filter(r => r.graduated);
    if (!completed.length)
        return 'none';
    const rank = { primary: 1, middle: 2, secondary: 3, trade: 4, community_college: 4, university: 5, graduate: 6, professional: 7 };
    return [...completed].sort((a, b) => (rank[b.stage] ?? 0) - (rank[a.stage] ?? 0))[0].stage;
}
function collectAnomalies(state) {
    const errors = (0, invariants_1.validateState)(state);
    if (!Number.isFinite((0, FinanceSystem_1.netWorth)(state)))
        errors.push('Non-finite net worth');
    if (state.finances.liabilities.some(l => !Number.isFinite(l.balance) || l.balance < 0))
        errors.push('Invalid liability balance');
    if (state.assets.properties.some(p => p.marketValue < 0 || !Number.isFinite(p.marketValue)))
        errors.push('Invalid property value');
    if (state.businesses.some(b => ![b.revenue, b.expenses, b.profit, b.valuation, b.capital].every(Number.isFinite)))
        errors.push('Non-finite business value');
    const activePartners = state.relationships.filter(r => ['fiance', 'spouse'].includes(r.type) && !r.estranged);
    if (activePartners.length > 1)
        errors.push('Multiple committed partners');
    for (const npc of Object.values(state.npcs))
        for (const parentId of npc.parentIds) {
            const parent = state.npcs[parentId];
            if (parent?.alive && parent.age - npc.age < 16)
                errors.push(`Impossible living-family age gap: ${parent.id} age ${parent.age} / ${npc.id} age ${npc.age}`);
        }
    return [...new Set(errors)];
}
function simulateLife(seed, maxAge = 125, mode = 'full', requestedPolicy = 'mixed') {
    const profile = chooseProfile(seed);
    const policy = choosePolicy(seed, requestedPolicy);
    const state = (0, CharacterSystem_1.createNewGame)({ seed });
    if (mode === 'bulk') {
        state.flags.simulationBulk = true;
        state.achievements = [];
        state.challenges = [];
    }
    let peakFame = state.fame.fame;
    let forcedTerminalDeath = false;
    const annualAnomalies = new Set();
    while (state.character.alive && state.character.age < maxAge) {
        annualPolicy(state, profile, policy);
        if (state.flags.pendingCharge && !state.legal.imprisoned)
            (0, CrimeSystem_1.resolveLegalCase)(state, 'public', 'contest');
        const result = (0, AgingSystem_1.ageUp)(state);
        if (!result.success && state.pendingEvent)
            resolveEventAutomatically(state, profile, policy);
        else if (state.pendingEvent)
            resolveEventAutomatically(state, profile, policy);
        peakFame = Math.max(peakFame, state.fame.fame);
        if (!Number.isFinite(state.finances.cash))
            annualAnomalies.add('Non-finite cash during simulation');
        if (state.character.age < 0)
            annualAnomalies.add('Negative age during simulation');
        if (mode === 'bulk' && state.timeline.length > 40)
            state.timeline = state.timeline.slice(-40);
    }
    if (state.character.alive) {
        // The harness uses a terminal cap only to keep pathological balance bugs from hanging large runs.
        (0, DeathSystem_1.checkDeath)(state, true);
        forcedTerminalDeath = true;
    }
    for (const error of collectAnomalies(state))
        annualAnomalies.add(error);
    const career = state.employment.current ?? state.employment.history.at(-1);
    const job = career ? jobs_1.jobById[career.jobId] : undefined;
    const wealth = (0, FinanceSystem_1.wealthBreakdown)(state);
    return {
        seed, profile, policy, lifespan: state.character.age, netWorth: wealth.netWorth, cash: wealth.cash, assetValue: (0, FinanceSystem_1.assetValue)(state), liabilityValue: (0, FinanceSystem_1.liabilityValue)(state), propertyEquity: wealth.propertyEquity, vehicleValue: wealth.vehicles, collectibleValue: wealth.collectibles, investmentValue: wealth.investments, investmentCostBasis: wealth.investmentCostBasis, investmentGain: wealth.investmentGain, investmentContributions: Number(state.flags.investmentContributions ?? 0), investmentWithdrawals: Number(state.flags.investmentWithdrawals ?? 0), businessValue: wealth.businesses, otherLiabilities: wealth.otherLiabilities, lifetimeInheritance: Number(state.flags.lifetimeInheritance ?? 0), annualIncome: state.finances.annualIncome, annualExpenses: state.finances.annualExpenses, highestEducation: highestEducation(state),
        primaryCareer: career?.title ?? 'none', primaryIndustry: job?.industry ?? (state.businesses.some(b => !b.bankrupt) ? 'Business Owner' : 'none'),
        married: Number(state.flags.marriages ?? 0) > 0 || state.timeline.some(entry => entry.text.startsWith('You married ')), children: state.relationships.filter(r => r.type === 'child').length,
        committedCrime: state.legal.criminalRecord.length > 0, convictions: state.legal.criminalRecord.filter(r => r.convicted).length,
        imprisonedYears: Number(state.flags.prisonYears ?? 0), peakFame, causeOfDeath: state.character.causeOfDeath ?? 'unknown', forcedTerminalDeath,
        anomalies: [...annualAnomalies],
    };
}
function runSimulation(options) {
    const requested = Math.max(1, Math.floor(options.lives));
    const maxAge = options.maxAge ?? 125;
    const prefix = options.seedPrefix ?? 'everthread-sim';
    const sampleLimit = options.keepAnomalySamples ?? 12;
    const mode = options.mode ?? 'full';
    const results = [];
    const anomalySamples = [];
    const educationDistribution = {};
    const careerDistribution = {};
    const profileDistribution = {};
    const policyDistribution = {};
    const causeOfDeathDistribution = {};
    let anomalyCount = 0;
    for (let i = 0; i < requested; i++) {
        const result = simulateLife(`${prefix}-${i + 1}`, maxAge, mode, options.policy ?? 'mixed');
        results.push(result);
        bump(educationDistribution, result.highestEducation);
        bump(careerDistribution, result.primaryIndustry);
        bump(profileDistribution, result.profile);
        bump(policyDistribution, result.policy);
        bump(causeOfDeathDistribution, result.causeOfDeath);
        anomalyCount += result.anomalies.length;
        if (result.anomalies.length && anomalySamples.length < sampleLimit)
            anomalySamples.push(`${result.seed}: ${result.anomalies.join('; ')}`);
    }
    const lifespans = results.map(r => r.lifespan), wealth = results.map(r => r.netWorth);
    const convicted = results.filter(r => r.convictions > 0).length;
    const average = (pick) => results.reduce((sum, result) => sum + pick(result), 0) / results.length;
    return {
        requestedLives: requested, completedLives: results.length,
        averageLifespan: lifespans.reduce((a, b) => a + b, 0) / results.length, medianLifespan: median(lifespans),
        averageNetWorth: wealth.reduce((a, b) => a + b, 0) / results.length, medianNetWorth: median(wealth), wealthPercentiles: { p10: percentile(wealth, .10), p25: percentile(wealth, .25), p75: percentile(wealth, .75), p90: percentile(wealth, .90), p99: percentile(wealth, .99) }, millionaireRate: results.filter(r => r.netWorth >= 1_000_000).length / results.length,
        marriageRate: results.filter(r => r.married).length / results.length, averageChildren: results.reduce((sum, r) => sum + r.children, 0) / results.length,
        crimeRate: results.filter(r => r.committedCrime).length / results.length, convictionRate: convicted / results.length, fameRate: results.filter(r => r.peakFame >= 25).length / results.length,
        forcedTerminalDeaths: results.filter(r => r.forcedTerminalDeath).length, anomalyCount, anomalySamples,
        educationDistribution, careerDistribution, profileDistribution, policyDistribution, causeOfDeathDistribution,
        averageWealthSources: { cash: average(r => r.cash), propertyEquity: average(r => r.propertyEquity), vehicles: average(r => r.vehicleValue), collectibles: average(r => r.collectibleValue), investments: average(r => r.investmentValue), investmentCostBasis: average(r => r.investmentCostBasis), investmentGain: average(r => r.investmentGain), investmentContributions: average(r => r.investmentContributions), investmentWithdrawals: average(r => r.investmentWithdrawals), businesses: average(r => r.businessValue), otherLiabilities: average(r => r.otherLiabilities), lifetimeInheritance: average(r => r.lifetimeInheritance) },
        inheritanceRate: results.filter(r => r.lifetimeInheritance > 0).length / results.length,
    };
}
function percent(value) { return `${(value * 100).toFixed(1)}%`; }
function topEntries(record, limit = 12) { return Object.entries(record).sort((a, b) => b[1] - a[1]).slice(0, limit).map(([key, value]) => `${key}: ${value}`).join(', '); }
function formatSimulationReport(report) {
    return [
        `Everthread simulation — ${report.completedLives.toLocaleString()} lives`,
        `Lifespan avg/median: ${report.averageLifespan.toFixed(1)} / ${report.medianLifespan.toFixed(1)}`,
        `Net worth avg/median: ${Math.round(report.averageNetWorth).toLocaleString()} / ${Math.round(report.medianNetWorth).toLocaleString()}`,
        `Wealth p10/p25/p75/p90/p99: ${Math.round(report.wealthPercentiles.p10).toLocaleString()} / ${Math.round(report.wealthPercentiles.p25).toLocaleString()} / ${Math.round(report.wealthPercentiles.p75).toLocaleString()} / ${Math.round(report.wealthPercentiles.p90).toLocaleString()} / ${Math.round(report.wealthPercentiles.p99).toLocaleString()}`,
        `Millionaires: ${percent(report.millionaireRate)} | Married: ${percent(report.marriageRate)} | Children avg: ${report.averageChildren.toFixed(2)}`,
        `Crime: ${percent(report.crimeRate)} | Convicted: ${percent(report.convictionRate)} | Fame 25+: ${percent(report.fameRate)}`,
        `Forced terminal deaths: ${report.forcedTerminalDeaths} | Anomalies: ${report.anomalyCount}`,
        `Avg wealth sources — cash ${Math.round(report.averageWealthSources.cash).toLocaleString()} | property equity ${Math.round(report.averageWealthSources.propertyEquity).toLocaleString()} | investments ${Math.round(report.averageWealthSources.investments).toLocaleString()} | businesses ${Math.round(report.averageWealthSources.businesses).toLocaleString()} | vehicles ${Math.round(report.averageWealthSources.vehicles).toLocaleString()} | collectibles ${Math.round(report.averageWealthSources.collectibles).toLocaleString()} | other debt ${Math.round(report.averageWealthSources.otherLiabilities).toLocaleString()}`,
        `Investing avg — contributed ${Math.round(report.averageWealthSources.investmentContributions).toLocaleString()} | withdrawn ${Math.round(report.averageWealthSources.investmentWithdrawals).toLocaleString()} | held cost basis ${Math.round(report.averageWealthSources.investmentCostBasis).toLocaleString()} | held gain ${Math.round(report.averageWealthSources.investmentGain).toLocaleString()}`,
        `Inheritance: ${percent(report.inheritanceRate)} of lives | avg lifetime received ${Math.round(report.averageWealthSources.lifetimeInheritance).toLocaleString()}`,
        `Profiles: ${topEntries(report.profileDistribution)}`,
        `Policies: ${topEntries(report.policyDistribution)}`,
        `Education: ${topEntries(report.educationDistribution)}`,
        `Careers: ${topEntries(report.careerDistribution)}`,
        `Death causes: ${topEntries(report.causeOfDeathDistribution)}`,
        ...(report.anomalySamples.length ? [`Anomaly samples:`, ...report.anomalySamples] : []),
    ].join('\n');
}
