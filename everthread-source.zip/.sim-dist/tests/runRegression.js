"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const regressionSuite_1 = require("./regressionSuite");
const report = (0, regressionSuite_1.runRegressionSuite)();
console.log((0, regressionSuite_1.formatRegressionReport)(report));
if (report.failed)
    process.exitCode = 1;
