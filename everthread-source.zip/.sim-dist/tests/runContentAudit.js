"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const contentAudit_1 = require("./contentAudit");
console.log((0, contentAudit_1.formatContentAudit)((0, contentAudit_1.auditContent)()));
